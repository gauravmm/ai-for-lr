"""Course intake datasets generator (CONTACTS.md "Data products").

Builds, deterministically from a fixed dataset seed, the offline extraction
fixtures the course grades against:

- report.schema.json    public participant report schema (+ one worked example)
- contacts_labeled.jsonl   envelope + rendered text + expected extraction
- contacts_unlabeled.jsonl envelope + text only (Day 1 labeling exercise)
- manifest.json            dataset seed and renderer/schema revisions

The claim corpus is generated programmatically across the three packaged maps'
public building names, source types, tones, and locations. There is no hidden
world truth in the labeled fixture: the expected extraction is the expressed
claim projected to the report schema, and the reported location is copied from
the envelope. Contradiction and duplicate pairs are emitted explicitly so those
relationships are present without being resolved.
"""
from __future__ import annotations

import json
import random
from importlib import resources
from pathlib import Path

from .domain.contacts import public_source_type
from .domain.language import RENDERER_REVISION, LanguageRenderer, RenderInput

DATASET_SEED = 20260720
SCHEMA_REVISION = "1"
MAPS = ("londone", "stockhome", "feeladelphia")
N_LABELED = 180
N_UNLABELED = 300

_SOURCE_RELIABILITY = {
    "direct_call": "medium",
    "panicked_call": "medium-low",
    "incomplete_call": "low",
    "automatic_alarm": "high",
    "responder_update": "high",
    "false_alarm_report": "medium",
    "red_herring_call": "medium",
}


class _Loc:
    def __init__(self, kind, building_id=None, coordinates=None):
        self.kind = kind
        self.building_id = building_id
        self.coordinates = coordinates


class _P:
    def __init__(self, x, y):
        self.x, self.y = x, y


class _Claim:
    def __init__(self, incident_type, severity=None, headcount=None, event_time=None,
                 source_reliability=None, evidence=(), negations=(), language_plan=None):
        self.incident_type = incident_type
        self.severity = severity
        self.headcount = headcount
        self.event_time = event_time
        self.source_reliability = source_reliability
        self.evidence = tuple(evidence)
        self.negations = tuple(negations)
        self.language_plan = language_plan


def _load_map(map_id: str) -> dict:
    base = resources.files("hadr_engine.data.maps").joinpath(map_id)
    manifest = json.loads(base.joinpath("manifest.json").read_text())
    meta = json.loads(base.joinpath("map.json").read_text())["meta"]
    ox, oy = meta["origin"]
    sw, sh = meta["screen"]
    z = meta["zoom"]
    names = {b["building_id"]: {"name": b.get("name", ""), "address": b.get("address", ""),
                                "aliases": list(b.get("aliases", ()))}
             for b in manifest["buildings"]}
    return {
        "map_id": map_id,
        "buildings": manifest["buildings"],
        "names": names,
        "bounds": ((ox, oy), (ox + sw / z, oy + sh / z)),
    }


# Each archetype produces a claim given a seeded Random. Evidence tokens are
# shared across archetypes where semantically valid (smoke appears for real and
# ambiguous incidents), and openers are keyed by tone (not incident type), so no
# template/first-token maps to a single incident label.
_SEVERITY = ("low", "medium", "high")
_AMBIGUOUS = ("bbq_smoke", "burnt_toast", "steam", "backfire", "dust", "light_smoke")
_RED_HERRING = ("cat_in_tree", "neighbour_dispute", "lockout", "noise_complaint", "water_leak")
_FIRE_EVIDENCE = ("smoke", "heavy_smoke", "flames", "burning_smell", "sparks", "shouting")


# Tone pools deliberately cross incident types so no opener/first-token maps to a
# single incident label (panicked cat owners, terse alarms, urgent responders).
_TONE_POOLS = {
    "direct_call": ("neutral", "urgent"),
    "panicked_call": ("panicked", "urgent"),
    "incomplete_call": ("terse", "neutral", "panicked"),
    "automatic_alarm": ("flat", "terse"),
    "responder_update": ("flat", "terse", "urgent"),
    "false_alarm_report": ("neutral", "urgent", "panicked"),
    "red_herring_call": ("neutral", "urgent", "panicked", "terse"),
}


def _tone_for(r: random.Random, source_type: str) -> str:
    return r.choice(_TONE_POOLS[source_type])


def _tone_plan(r: random.Random, tone: str, order_pool) -> dict:
    order = list(order_pool)
    r.shuffle(order)
    disfluency = r.choice(["none", "light", "light", "heavy"] if tone == "panicked"
                          else ["none", "none", "light"])
    return {"tone": tone, "detail_order": order, "disfluency": disfluency}


def _maybe(r: random.Random, p: float) -> bool:
    return r.random() < p


def _severity(r: random.Random, bias_high: bool = False) -> dict:
    value = r.choice(("high", "high", "medium") if bias_high else _SEVERITY)
    return {"value": value, "confidence": round(r.uniform(0.4, 0.9), 2)}


def _headcount(r: random.Random) -> dict:
    qualifier = r.choice(("possibly_trapped", "confirmed_trapped", "all_out", "unknown"))
    value = 0 if qualifier == "all_out" else r.randint(1, 6)
    return {"value": value, "qualifier": qualifier, "confidence": round(r.uniform(0.3, 0.8), 2)}


def _event_time(r: random.Random, tick: int) -> dict:
    return {"tick": tick, "confidence": round(r.uniform(0.4, 0.9), 2)}


def _archetype(r: random.Random, source_type: str, occurred: int) -> _Claim:
    sr = _SOURCE_RELIABILITY[source_type]
    tone = _tone_for(r, source_type)
    if source_type == "panicked_call":
        return _Claim("fire", severity=_severity(r, bias_high=True),
                      headcount=_headcount(r), event_time=_event_time(r, occurred),
                      source_reliability=sr, evidence=r.sample(_FIRE_EVIDENCE, 2),
                      language_plan=_tone_plan(r, tone,
                                               ["location", "evidence", "headcount", "severity"]))
    if source_type == "direct_call":
        ev = r.sample(_FIRE_EVIDENCE, r.randint(1, 2))
        return _Claim("fire", severity=_severity(r),
                      headcount=_headcount(r) if _maybe(r, 0.5) else None,
                      event_time=_event_time(r, occurred) if _maybe(r, 0.6) else None,
                      source_reliability=sr, evidence=ev,
                      language_plan=_tone_plan(
                          r, tone, ["location", "incident_type", "evidence", "severity"]))
    if source_type == "incomplete_call":
        ev = r.sample(_FIRE_EVIDENCE, 1) if _maybe(r, 0.4) else ()
        return _Claim("unknown", source_reliability=sr, evidence=ev,
                      language_plan=_tone_plan(r, tone, ["location", "incident_type"]))
    if source_type == "automatic_alarm":
        return _Claim("unknown", source_reliability=sr, evidence=("alarm",),
                      event_time=_event_time(r, occurred),
                      language_plan=_tone_plan(r, tone, ["location", "evidence"]))
    if source_type == "responder_update":
        neg = ("casualties",) if _maybe(r, 0.5) else ()
        hc = {"value": 0, "qualifier": "all_out", "confidence": 0.8} if neg else _headcount(r)
        return _Claim("fire", severity=_severity(r, bias_high=True), headcount=hc,
                      source_reliability=sr, evidence=r.sample(_FIRE_EVIDENCE, 1), negations=neg,
                      language_plan=_tone_plan(r, tone, ["location", "incident_type", "severity"]))
    if source_type == "false_alarm_report":
        if _maybe(r, 0.5):  # explicit benign cause -> none
            return _Claim("none", source_reliability=sr, evidence=(r.choice(_AMBIGUOUS),),
                          negations=("fire",),
                          language_plan=_tone_plan(
                              r, tone, ["location", "incident_type", "evidence"]))
        return _Claim("unknown", source_reliability=sr, evidence=(r.choice(_AMBIGUOUS),),
                      language_plan=_tone_plan(r, tone, ["location", "evidence", "incident_type"]))
    # red_herring_call
    return _Claim("none", source_reliability=sr, evidence=(r.choice(_RED_HERRING),),
                  language_plan=_tone_plan(r, tone, ["location", "incident_type", "evidence"]))


_CYCLE = ("direct_call", "panicked_call", "incomplete_call", "automatic_alarm",
          "responder_update", "false_alarm_report", "red_herring_call")


def _location(r: random.Random, building) -> _Loc:
    bid = building["building_id"]
    if _maybe(r, 0.25):  # coordinate report near the building point
        p = building["point"]
        return _Loc("coordinates",
                    coordinates=_P(round(p["x"] + r.uniform(-15, 15), 1),
                                   round(p["y"] + r.uniform(-15, 15), 1)))
    return _Loc("building_id", building_id=bid)


def _reported_location_dict(loc: _Loc) -> dict:
    if loc.kind == "building_id":
        return {"kind": "building_id", "building_id": loc.building_id}
    assert loc.coordinates is not None  # kind == "coordinates" implies coordinates set
    return {"kind": "coordinates",
            "coordinates": {"x": loc.coordinates.x, "y": loc.coordinates.y}}


def _report(contact_id: str, loc: _Loc, claim: _Claim) -> dict:
    return {
        "contact_id": contact_id,
        "reported_location": _reported_location_dict(loc),
        "incident_type": claim.incident_type,
        "severity": claim.severity,
        "headcount": claim.headcount,
        "event_time": claim.event_time,
        "notes": "",
    }


def _envelope(contact_id: str, source_type: str, occurred: int, delivered: int,
              loc: _Loc, text: str) -> dict:
    return {
        "contact_id": contact_id,
        "source_type": public_source_type(source_type),
        "occurred_at": occurred,
        "delivered_at": delivered,
        "reported_location": _reported_location_dict(loc),
        "payload_type": "human_text",
        "payload": {"text": text},
    }


def _render(renderer: LanguageRenderer, mp: dict, contact_id: str, source_type: str,
            loc: _Loc, claim: _Claim, occurred: int, delivered: int, index: int) -> str:
    ri = RenderInput(
        claim=claim, reported_location=loc, source_type=source_type,
        public_map_names=mp["names"],
        seed_material={"seed": DATASET_SEED, "contact_id": contact_id,
                       "occurred_at": occurred, "delivered_at": delivered,
                       "occurrence_index": index},
    )
    return renderer.render(ri).text


def _build_corpus(n: int, id_prefix: str, seed_salt: int):
    """Yield (envelope, expected) tuples deterministically."""
    renderer = LanguageRenderer()
    maps = [_load_map(m) for m in MAPS]
    records = []

    # Explicit relationship pairs first, so duplicate/contradiction/delay always
    # appear regardless of n. Both share one building; neither is resolved.
    mp0 = maps[0]
    b0 = mp0["buildings"][0]
    rels = _relationship_pairs(renderer, mp0, b0, id_prefix)
    records.extend(rels)

    r = random.Random(DATASET_SEED + seed_salt)
    idx = len(records)
    while len(records) < n:
        mp = maps[idx % len(maps)]
        building = mp["buildings"][(idx * 7) % len(mp["buildings"])]
        source_type = _CYCLE[idx % len(_CYCLE)]
        occurred = r.randint(0, 30)
        delay = r.choice([0, 1, 1, 2, 4, 6])  # exercises delay phrasing
        delivered = occurred + delay
        loc = _location(r, building)
        cid = f"{id_prefix}-{idx:04d}"
        claim = _archetype(r, source_type, occurred)
        text = _render(renderer, mp, cid, source_type, loc, claim, occurred, delivered, idx)
        records.append((_envelope(cid, source_type, occurred, delivered, loc, text),
                        _report(cid, loc, claim)))
        idx += 1
    return records[:n]


def _relationship_pairs(renderer, mp, building, id_prefix):
    """A delayed duplicate pair and a contradictory headcount pair on one building."""
    out = []
    loc = _Loc("building_id", building_id=building["building_id"])

    # Duplicate: same fire, two phrasings/sources, one delayed.
    for i, (stype, occ, deliv) in enumerate(
            [("direct_call", 3, 4), ("panicked_call", 3, 8)]):
        cid = f"{id_prefix}-dup-{i}"
        claim = _Claim("fire", severity={"value": "high", "confidence": 0.7},
                       event_time={"tick": occ, "confidence": 0.7},
                       source_reliability=_SOURCE_RELIABILITY[stype],
                       evidence=("smoke", "flames") if i == 0 else ("heavy_smoke",),
                       language_plan={"tone": "urgent" if i == 0 else "panicked",
                                      "detail_order": ["location", "evidence", "severity"],
                                      "disfluency": "none" if i == 0 else "light"})
        text = _render(renderer, mp, cid, stype, loc, claim, occ, deliv, 900 + i)
        out.append((_envelope(cid, stype, occ, deliv, loc, text), _report(cid, loc, claim)))

    # Contradiction: everyone out vs two still inside.
    for i, (stype, hc) in enumerate(
            [("responder_update", {"value": 0, "qualifier": "all_out", "confidence": 0.8}),
             ("direct_call", {"value": 2, "qualifier": "confirmed_trapped", "confidence": 0.6})]):
        cid = f"{id_prefix}-con-{i}"
        claim = _Claim("fire", severity={"value": "high", "confidence": 0.8}, headcount=hc,
                       source_reliability=_SOURCE_RELIABILITY[stype], evidence=("smoke",),
                       language_plan={"tone": "flat" if i == 0 else "urgent",
                                      "detail_order": ["location", "headcount", "severity"],
                                      "disfluency": "none"})
        text = _render(renderer, mp, cid, stype, loc, claim, 5, 6, 910 + i)
        out.append((_envelope(cid, stype, 5, 6, loc, text), _report(cid, loc, claim)))
    return out


def report_schema() -> dict:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "https://dsta-class/hadr/report.schema.json",
        "title": "HADR participant report",
        "description": "Public structured report a participant's intake produces per human "
                       "contact. Extraction is graded offline against this schema; the engine "
                       "never sees it.",
        "type": "object",
        "additionalProperties": False,
        "required": ["contact_id", "reported_location", "incident_type"],
        "properties": {
            "contact_id": {"type": "string"},
            "reported_location": {
                "description": "Copied or deterministically normalized from the contact "
                               "envelope; a building ID or its exact public point.",
                "oneOf": [
                    {"type": "object", "additionalProperties": False,
                     "required": ["kind", "building_id"],
                     "properties": {"kind": {"const": "building_id"},
                                    "building_id": {"type": "string", "pattern": "^l[0-9]+$"}}},
                    {"type": "object", "additionalProperties": False,
                     "required": ["kind", "coordinates"],
                     "properties": {"kind": {"const": "coordinates"},
                                    "coordinates": {"type": "object", "additionalProperties": False,
                                                    "required": ["x", "y"],
                                                    "properties": {"x": {"type": "number"},
                                                                   "y": {"type": "number"}}}}},
                ],
            },
            "incident_type": {"enum": ["fire", "none", "unknown"]},
            "severity": {"oneOf": [
                {"type": "null"},
                {"type": "object", "additionalProperties": False, "required": ["value"],
                 "properties": {"value": {"enum": ["low", "medium", "high"]},
                                "confidence": {"type": "number", "minimum": 0, "maximum": 1}}}]},
            "headcount": {"oneOf": [
                {"type": "null"},
                {"type": "object", "additionalProperties": False, "required": ["value"],
                 "properties": {"value": {"type": "integer", "minimum": 0},
                                "qualifier": {"enum": ["possibly_trapped", "confirmed_trapped",
                                                       "all_out", "unknown"]},
                                "confidence": {"type": "number", "minimum": 0, "maximum": 1}}}]},
            "event_time": {"oneOf": [
                {"type": "null"},
                {"type": "object", "additionalProperties": False, "required": ["tick"],
                 "properties": {"tick": {"type": "integer", "minimum": 0},
                                "confidence": {"type": "number", "minimum": 0, "maximum": 1}}}]},
            "notes": {"type": "string"},
        },
    }


def report_example() -> dict:
    return {
        "contact_id": "contact-017",
        "reported_location": {"kind": "building_id", "building_id": "l41"},
        "incident_type": "unknown",
        "severity": {"value": "high", "confidence": 0.7},
        "headcount": {"value": 2, "qualifier": "possibly_trapped", "confidence": 0.4},
        "event_time": {"tick": 4, "confidence": 0.8},
        "notes": "Thick smoke reported; source could not confirm flames.",
    }


def generate(out_dir: Path, include_labels: bool = False) -> dict:
    """Write the unlabeled corpus; with include_labels, also the instructor
    labels, report schema, and worked example (Day 2 grading artifacts -
    withheld by default so schema discovery stays a student exercise)."""
    out_dir.mkdir(parents=True, exist_ok=True)
    unlabeled = _build_corpus(N_UNLABELED, "unlabeled", seed_salt=101)

    with (out_dir / "contacts_unlabeled.jsonl").open("w") as f:
        for env, _expected in unlabeled:
            f.write(json.dumps({"contact": env}, sort_keys=True) + "\n")

    counts = {"unlabeled": len(unlabeled)}
    files = ["contacts_unlabeled.jsonl"]
    if include_labels:
        labeled = _build_corpus(N_LABELED, "labeled", seed_salt=0)
        (out_dir / "report.schema.json").write_text(
            json.dumps(report_schema(), indent=2, sort_keys=True) + "\n")
        (out_dir / "report.example.json").write_text(
            json.dumps(report_example(), indent=2, sort_keys=True) + "\n")
        with (out_dir / "contacts_labeled.jsonl").open("w") as f:
            for env, expected in labeled:
                f.write(json.dumps({"contact": env, "expected": expected}, sort_keys=True) + "\n")
        counts = {"labeled": len(labeled), "unlabeled": len(unlabeled)}
        files = ["report.schema.json", "report.example.json",
                 "contacts_labeled.jsonl", "contacts_unlabeled.jsonl"]

    manifest = {
        "dataset_seed": DATASET_SEED,
        "renderer_revision": RENDERER_REVISION,
        "schema_revision": SCHEMA_REVISION,
        "maps": list(MAPS),
        "counts": counts,
        "files": files,
        "note": "Generated by `hadr-engine gen-datasets`; no hidden world truth. "
                "Labels are candidates until rubric/simulator/human validation.",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return manifest
