"""Public request/response models at the trust boundary (API.md).

These are the shared source for the MCP tool schemas. Rules:
- snake_case fields, explicit {x, y} points (never two-item arrays).
- Requests reject unknown fields and bound ID/rationale lengths.
- Response models are structurally incapable of carrying occupants, hidden fire
  state (intensity/growth/ignited), canonical labels, future events, casualties,
  or live metrics while running: there is simply no field for them. Terminal
  status adds the three outcome fields; `tokens` is always null and marked as
  participant-reported.

Redaction here is by construction. `from_domain` constructors copy only the
allowlisted public fields out of the domain objects.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .domain import model as m
from .domain import tick as tickmod
from .domain.contacts import public_source_type

API_VERSION = 1

ID_MAX = 128
INCIDENT_ID_MAX = 256
RATIONALE_MAX = 2000

TOKENS_NOTE = "participant-reported; the engine never measures tokens"


# --------------------------------------------------------------- primitives

class _Req(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PointModel(_Req):
    x: float
    y: float

    @classmethod
    def of(cls, p: m.Point) -> PointModel:
        return cls(x=p.x, y=p.y)


def _nonblank(value: str, name: str, max_len: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a nonblank string")
    if len(value) > max_len:
        raise ValueError(f"{name} exceeds maximum length {max_len}")
    return value


# ------------------------------------------------------------------ requests

class ListScenariosRequest(_Req):
    pass


class StatusRequest(_Req):
    pass


class StartEpisodeRequest(_Req):
    scenario_id: str
    seed: int | None = None

    @field_validator("scenario_id")
    @classmethod
    def _v_scenario(cls, v):
        return _nonblank(v, "scenario_id", ID_MAX)


class BuildingToCoordsRequest(_Req):
    building_id: str

    @field_validator("building_id")
    @classmethod
    def _v_building(cls, v):
        return _nonblank(v, "building_id", ID_MAX)


class TravelEndpoint(_Req):
    vehicle_id: str | None = None
    point: PointModel | None = None

    @model_validator(mode="after")
    def _exactly_one(self):
        has_vehicle = self.vehicle_id is not None
        has_point = self.point is not None
        if has_vehicle == has_point:
            raise ValueError("endpoint must set exactly one of vehicle_id or point")
        if has_vehicle:
            assert self.vehicle_id is not None  # has_vehicle == (vehicle_id is not None)
            _nonblank(self.vehicle_id, "vehicle_id", ID_MAX)
        return self


class TravelTimeRequest(_Req):
    from_: TravelEndpoint = Field(alias="from")
    to: TravelEndpoint

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class DispatchRequest(_Req):
    expected_tick: int = Field(ge=0)
    vehicle_id: str
    incident_id: str
    destination: PointModel
    rationale: str

    @field_validator("vehicle_id")
    @classmethod
    def _v_vehicle(cls, v):
        return _nonblank(v, "vehicle_id", ID_MAX)

    @field_validator("incident_id")
    @classmethod
    def _v_incident(cls, v):
        return _nonblank(v, "incident_id", INCIDENT_ID_MAX)

    @field_validator("rationale")
    @classmethod
    def _v_rationale(cls, v):
        return _nonblank(v, "rationale", RATIONALE_MAX)


class EndTickRequest(_Req):
    expected_tick: int = Field(ge=0)
    # Optional and display-only; see TokenReport. Omitted by every caller that
    # is not an automated runner, and omitting it is always valid.
    tokens: TokenReport | None = None


# ----------------------------------------------------------- response pieces

class RouteSummary(BaseModel):
    remaining: float
    total: float
    eta_ticks: int
    edges: list[str]
    polyline: list[PointModel] | None = None

    @classmethod
    def of(cls, route: m.Route, speed: float) -> RouteSummary:
        return cls(
            remaining=route.remaining,
            total=route.total,
            eta_ticks=tickmod.travel_time(route, speed),
            edges=list(route.edges),
            polyline=[PointModel.of(p) for p in route.polyline],
        )


class DestinationModel(BaseModel):
    requested: PointModel
    snapped: PointModel

    @classmethod
    def of(cls, d: m.Destination) -> DestinationModel:
        return cls(requested=PointModel.of(d.requested), snapped=PointModel.of(d.snapped))


class VehiclePublic(BaseModel):
    vehicle_id: str
    label: str
    position: PointModel
    status: str
    route: RouteSummary | None = None
    destination: DestinationModel | None = None
    incident_id: str | None = None
    last_rationale: str | None = None

    @classmethod
    def of(cls, v: m.VehicleState, speed: float) -> VehiclePublic:
        return cls(
            vehicle_id=v.vehicle_id,
            label=v.label,
            position=PointModel.of(v.position),
            status=v.status.value,
            route=RouteSummary.of(v.route, speed) if v.route is not None else None,
            destination=DestinationModel.of(v.destination) if v.destination is not None else None,
            incident_id=v.incident_id,
            last_rationale=v.last_rationale,
        )


class ReportedLocationModel(BaseModel):
    kind: str
    building_id: str | None = None
    coordinates: PointModel | None = None

    @classmethod
    def of(cls, loc: m.ReportedLocation) -> ReportedLocationModel:
        return cls(
            kind=loc.kind,
            building_id=loc.building_id,
            coordinates=PointModel.of(loc.coordinates) if loc.coordinates is not None else None,
        )


class ObservedBuildingModel(BaseModel):
    building_id: str
    status: str
    # Derived tick countdowns for burning buildings; null otherwise.
    ticks_to_extinguish: int | None = None
    ticks_to_collapse: int | None = None


class TruckObservationModel(BaseModel):
    observer_id: str
    observer_position: PointModel
    tick: int
    radius: float
    buildings: list[ObservedBuildingModel]

    @classmethod
    def of(cls, p: m.TruckObservationPayload) -> TruckObservationModel:
        return cls(
            observer_id=p.observer_id,
            observer_position=PointModel.of(p.observer_position),
            tick=p.tick,
            radius=p.radius,
            buildings=[ObservedBuildingModel(building_id=b.building_id, status=b.status.value,
                                             ticks_to_extinguish=b.ticks_to_extinguish,
                                             ticks_to_collapse=b.ticks_to_collapse)
                       for b in p.buildings],
        )


class ClaimModel(BaseModel):
    """Canonical expressed claim as delivered to the participant. Carries the
    participant-facing structured claim only; the renderer's `language_plan` and
    private relation tags never reach this model."""
    incident_type: str
    severity: dict | None = None
    headcount: dict | None = None
    event_time: dict | None = None
    source_reliability: str | None = None
    evidence: list[str] = Field(default_factory=list)
    negations: list[str] = Field(default_factory=list)

    @classmethod
    def of(cls, c: m.ExpressedClaim) -> ClaimModel:
        return cls(
            incident_type=c.incident_type,
            severity=c.severity,
            headcount=c.headcount,
            event_time=c.event_time,
            source_reliability=c.source_reliability,
            evidence=list(c.evidence),
            negations=list(c.negations),
        )


class StructuredReportModel(BaseModel):
    claim: ClaimModel


class HumanTextModel(BaseModel):
    text: str


class ContactPublic(BaseModel):
    contact_id: str
    source_type: str
    occurred_at: int
    delivered_at: int
    reported_location: ReportedLocationModel | None = None
    payload_type: str
    payload: TruckObservationModel | StructuredReportModel | HumanTextModel

    @classmethod
    def of(cls, c: m.Contact) -> ContactPublic:
        if c.payload_type == "truck_observation":
            assert isinstance(c.payload, m.TruckObservationPayload)
            payload: object = TruckObservationModel.of(c.payload)
        elif c.payload_type == "structured_report":
            assert isinstance(c.payload, m.StructuredReportPayload)
            payload = StructuredReportModel(claim=ClaimModel.of(c.payload.claim))
        else:
            payload = HumanTextModel(text=getattr(c.payload, "text", ""))
        loc = ReportedLocationModel.of(c.reported_location) if c.reported_location else None
        return cls(
            contact_id=c.contact_id,
            source_type=public_source_type(c.source_type),
            occurred_at=c.occurred_at,
            delivered_at=c.delivered_at,
            reported_location=loc,
            payload_type=c.payload_type,
            payload=payload,
        )


class ObservationPublic(BaseModel):
    observation_id: str
    tick: int
    lifecycle: str
    tick_limit: int
    terminal_reason: str | None = None
    contacts: list[ContactPublic]
    vehicles: list[VehiclePublic]

    @classmethod
    def of(cls, obs: m.Observation, speed: float) -> ObservationPublic:
        return cls(
            observation_id=obs.observation_id,
            tick=obs.tick,
            lifecycle=obs.lifecycle.value,
            tick_limit=obs.tick_limit,
            terminal_reason=obs.terminal_reason.value if obs.terminal_reason else None,
            contacts=[ContactPublic.of(c) for c in obs.contacts],
            vehicles=[VehiclePublic.of(v, speed) for v in obs.vehicles],
        )


class PendingCommandSummary(BaseModel):
    command_id: str
    vehicle_id: str
    incident_id: str
    rationale: str
    destination: DestinationModel
    eta_ticks: int
    status: str
    superseded_by: str | None = None

    @classmethod
    def of(cls, c: m.PendingCommand, speed: float) -> PendingCommandSummary:
        return cls(
            command_id=c.command_id,
            vehicle_id=c.vehicle_id,
            incident_id=c.incident_id,
            rationale=c.rationale,
            destination=DestinationModel.of(c.destination),
            eta_ticks=tickmod.travel_time(c.route, speed),
            status=c.status.value,
            superseded_by=c.superseded_by,
        )


class PublicEventModel(BaseModel):
    """Arrivals and public vehicle changes only. Suppression, intensity, collapse,
    ignition, and sensor events stay in the run log."""
    type: str
    vehicle_id: str | None = None


class TerminalOutcome(BaseModel):
    terminal_reason: str
    casualties: int
    buildings_lost: int
    tokens: None = None
    tokens_note: str = TOKENS_NOTE

    @classmethod
    def of(cls, state: m.EpisodeState) -> TerminalOutcome:
        return cls(
            terminal_reason=state.terminal_reason.value if state.terminal_reason else "aborted",
            casualties=state.casualties,
            buildings_lost=state.buildings_lost,
        )


# --------------------------------------------------------------- result types

class ResultBase(BaseModel):
    api_version: int = API_VERSION
    lifecycle: str
    run_id: str | None = None
    tick: int | None = None


class ScenarioCatalogueEntry(BaseModel):
    scenario_id: str
    title: str
    difficulty_stage: int
    map_id: str
    tick_limit: int
    default_seed: int
    public_description: str


class ListScenariosResult(ResultBase):
    scenarios: list[ScenarioCatalogueEntry]


class StartEpisodeResult(ResultBase):
    observation: ObservationPublic


class StatusResult(ResultBase):
    tick_limit: int | None = None
    scenario_id: str | None = None
    map_id: str | None = None
    terminal_reason: str | None = None
    observation: ObservationPublic | None = None
    pending: list[PendingCommandSummary] = Field(default_factory=list)
    outcome: TerminalOutcome | None = None


class BuildingToCoordsResult(ResultBase):
    building_id: str
    point: PointModel


class TravelTimeResult(ResultBase):
    distance: float
    eta_ticks: int
    edges: list[str]
    polyline: list[PointModel] | None = None


class DispatchCommand(BaseModel):
    command_id: str
    vehicle_id: str
    incident_id: str
    rationale: str
    requested: PointModel
    snapped: PointModel
    route: RouteSummary


class DispatchResult(ResultBase):
    accepted: bool
    command: DispatchCommand
    pending: list[PendingCommandSummary] = Field(default_factory=list)
    superseded: list[str] = Field(default_factory=list)


class EndTickResult(ResultBase):
    committed_commands: list[PendingCommandSummary] = Field(default_factory=list)
    events: list[PublicEventModel] = Field(default_factory=list)
    observation: ObservationPublic
    terminal_reason: str | None = None
    outcome: TerminalOutcome | None = None


class RoleTokens(_Req):
    """One role's running provider-reported totals. Bounded so a typo cannot
    wedge the display layout; absent counters default to zero."""

    read: int = Field(default=0, ge=0, le=10**9)
    write: int = Field(default=0, ge=0, le=10**9)
    cache_read: int = Field(default=0, ge=0, le=10**9)


class TokenReport(_Req):
    """Participant-reported running token totals, for the display scoreboard.

    NOT FOR INTERACTIVE AGENT USE. This exists for the participant's automated
    outer runner, which knows its own provider-reported usage. If you are an
    agent playing the game by hand through these tools, you have no such number
    and MUST omit this field entirely - do not estimate it, and never invent
    one. Omitting it changes nothing about the tick.

    Split by role because the two models are chosen and tuned separately: a
    cheap intake model and an expensive dispatch model spend very differently,
    and one aggregate hides which one is costing you.

    The engine measures nothing and verifies nothing here: it stores what it is
    told and shows it.
    """

    intake: RoleTokens = Field(default_factory=RoleTokens)
    dispatch: RoleTokens = Field(default_factory=RoleTokens)
