"""The greedy baseline dispatcher and a headless GameService policy driver.

The baseline is the deterministic, no-LLM reference from SCENARIOS.md "Greedy
baseline": it has perfect literal access to canonical expressed claims (never
truth or private relation tags), treats every positive/unknown fire claim at face
value with no reconciliation, and for each idle truck picks the highest claimed
severity, breaking ties by earliest delivery, nearest travel time, then stable
IDs. It dispatches the nearest idle truck to the claimed public coordinates and
never redirects a moving/firefighting truck. Opaque incident IDs are
``baseline:<contact_id>``.

Both the baseline and the acceptance good-policy oracle run headlessly through the
real GameService command/tick path via ``drive_policy`` below.
"""
from __future__ import annotations

import asyncio
import math
from collections.abc import Callable
from dataclasses import dataclass, field

from .. import catalogue, schemas
from ..maps.repository import Map
from ..persistence import runlog
from .contacts import public_contact_ids
from .model import Point
from .scenario import Scenario

# Published ordinal severity mapping and missing-value rule (SCENARIOS.md: a
# "highest severity" baseline requires an explicit ordinal mapping). Missing or
# unrecognized severity ranks below every stated severity.
SEVERITY_ORDINAL = {"high": 3, "medium": 2, "low": 1}
MISSING_SEVERITY = 0
BASELINE_REVISION = "1"

# Fire-bearing claims the baseline acts on; it queues nothing for explicit `none`.
_ACTIONABLE = frozenset({"fire", "unknown"})


def severity_ordinal(claim) -> int:
    sev = getattr(claim, "severity", None) if claim is not None else None
    if not sev:
        return MISSING_SEVERITY
    return SEVERITY_ORDINAL.get(sev.get("value"), MISSING_SEVERITY)


@dataclass
class SeenContact:
    contact_id: str
    source_type: str
    delivered_at: int
    reported_location: schemas.ReportedLocationModel | None
    claim: object  # canonical ExpressedClaim (baseline/good-policy privilege)


@dataclass
class Dispatch:
    vehicle_id: str
    incident_id: str
    destination: Point
    rationale: str


@dataclass
class PolicyContext:
    tick: int
    map_: Map
    scenario: Scenario
    speed: float
    vehicles: list  # schemas.VehiclePublic
    seen: dict[str, SeenContact]  # accumulated human contacts by contact_id
    vision: dict[str, str]  # building_id -> observed status this tick (truck vision)
    state: dict  # policy-owned persistent scratch


def target_coords(loc: schemas.ReportedLocationModel, map_: Map) -> Point:
    if loc.kind == "building_id":
        assert loc.building_id is not None  # kind == "building_id" implies building_id set
        return map_.building_to_coords(loc.building_id)
    assert loc.coordinates is not None  # otherwise kind == "coordinates" implies coordinates set
    return Point(loc.coordinates.x, loc.coordinates.y)


def _travel(map_: Map, src: Point, dst: Point, speed: float) -> float:
    try:
        return map_.route(src, dst).total / speed
    except Exception:
        return math.inf


def baseline_commands(ctx: PolicyContext) -> list[Dispatch]:
    """One tick of greedy baseline dispatch. Mutates ctx.state['assigned'] (the
    minimal per-run assignment memory that stops re-dispatching the same idle truck
    to a claim it already served)."""
    assigned: set[str] = ctx.state.setdefault("assigned", set())
    idle = [v for v in ctx.vehicles if v.status == "idle"]
    idle.sort(key=lambda v: v.vehicle_id)

    # Face-value targets: every positive/unknown fire claim not yet served. No
    # dedup, no contradiction memory, no source-confidence reasoning.
    targets = [c for c in ctx.seen.values()
               if getattr(c.claim, "incident_type", None) in _ACTIONABLE
               and c.contact_id not in assigned
               and c.reported_location is not None]

    out: list[Dispatch] = []
    for truck in idle:
        if not targets:
            break
        pos = Point(truck.position.x, truck.position.y)

        def rank(c, _pos=pos):
            coords = target_coords(c.reported_location, ctx.map_)
            return (-severity_ordinal(c.claim), c.delivered_at,
                    _travel(ctx.map_, _pos, coords, ctx.speed), c.contact_id)

        best = min(targets, key=rank)
        assert best.reported_location is not None  # targets are pre-filtered to non-None locations
        coords = target_coords(best.reported_location, ctx.map_)
        out.append(Dispatch(truck.vehicle_id, f"baseline:{best.contact_id}", coords,
                            f"greedy: highest claimed severity ({best.contact_id})"))
        assigned.add(best.contact_id)
        targets.remove(best)
    return out


@dataclass
class RunResult:
    scenario_id: str
    seed: int
    run_id: str
    terminal_reason: str
    casualties: int
    buildings_lost: int
    ticks: int
    trace_hash: str
    commands: list[dict] = field(default_factory=list)  # (tick, vehicle, incident, x, y)


async def _drive_async(scenario_id: str, policy: Callable[[PolicyContext], list[Dispatch]],
                       seed: int | None) -> RunResult:
    from ..service import GameService

    scenario, map_, _raw = catalogue.load(scenario_id)
    speed = scenario.settings.truck_speed
    effective_seed = scenario.default_seed if seed is None else seed
    # Keyed by public id: the observation carries opaque ids and the aliased
    # channel; the oracle joins back to the authored claim and fine-grained kind.
    pub = public_contact_ids(scenario.human_contacts)
    claims = {pub[c.contact_id]: c.claim for c in scenario.human_contacts}
    true_sources = {pub[c.contact_id]: c.source_type for c in scenario.human_contacts}

    svc = GameService()
    cid = await svc.acquire_controller()
    start = await svc.start_episode(cid, schemas.StartEpisodeRequest(
        scenario_id=scenario_id, seed=seed))
    run_id = start.run_id
    assert run_id is not None  # a freshly started episode always has a run_id
    seen: dict[str, SeenContact] = {}
    pstate: dict = {}
    commands: list[dict] = []

    def observe(obs: schemas.ObservationPublic | None) -> None:
        if obs is None:
            return
        for c in obs.contacts:
            if c.payload_type == "truck_observation" or c.contact_id in seen:
                continue
            seen[c.contact_id] = SeenContact(
                contact_id=c.contact_id,
                source_type=true_sources.get(c.contact_id, c.source_type),
                delivered_at=c.delivered_at, reported_location=c.reported_location,
                claim=claims.get(c.contact_id))

    observe(start.observation)
    outcome = None
    last_tick = start.observation.tick
    for _ in range(scenario.tick_limit + 5):
        st = await svc.status(cid)
        assert st.tick is not None  # status always reports a tick
        if st.lifecycle != "running":
            outcome = st.outcome
            last_tick = st.tick
            break
        assert st.observation is not None  # a running episode always carries an observation
        vision: dict[str, str] = {}
        for c in st.observation.contacts:
            if c.payload_type == "truck_observation":
                assert isinstance(c.payload, schemas.TruckObservationModel)
                for b in c.payload.buildings:
                    vision[b.building_id] = b.status
        ctx = PolicyContext(tick=st.tick, map_=map_, scenario=scenario, speed=speed,
                            vehicles=list(st.observation.vehicles), seen=seen,
                            vision=vision, state=pstate)
        for d in policy(ctx):
            await svc.dispatch(cid, schemas.DispatchRequest(
                expected_tick=st.tick, vehicle_id=d.vehicle_id, incident_id=d.incident_id,
                destination=schemas.PointModel.of(d.destination), rationale=d.rationale))
            commands.append({"tick": st.tick, "vehicle_id": d.vehicle_id,
                             "incident_id": d.incident_id,
                             "x": round(d.destination.x, 3), "y": round(d.destination.y, 3)})
        res = await svc.end_tick(cid, schemas.EndTickRequest(expected_tick=st.tick))
        observe(res.observation)
        last_tick = res.observation.tick
        if res.lifecycle != "running":
            outcome = res.outcome
            break

    records = runlog.read_records(runlog.state_dir() / f"{run_id}.jsonl")
    return RunResult(
        scenario_id=scenario_id, seed=effective_seed, run_id=run_id,
        terminal_reason=outcome.terminal_reason if outcome else "aborted",
        casualties=outcome.casualties if outcome else -1,
        buildings_lost=outcome.buildings_lost if outcome else -1,
        ticks=last_tick, trace_hash=runlog.trace_hash(records), commands=commands)


def drive_policy(scenario_id: str, policy: Callable[[PolicyContext], list[Dispatch]],
                 seed: int | None = None) -> RunResult:
    """Run ``policy`` headlessly through GameService to terminal. Synchronous."""
    return asyncio.run(_drive_async(scenario_id, policy, seed))


def run_baseline(scenario_id: str, seed: int | None = None) -> RunResult:
    return drive_policy(scenario_id, baseline_commands, seed)
