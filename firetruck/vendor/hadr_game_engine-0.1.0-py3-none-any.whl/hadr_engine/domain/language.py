"""Deterministic, offline English renderer for human contacts (CONTACTS.md).

Curated JSON phrase catalogue plus standard-library combinators; no LLM, no
network, no credentials. Every surface choice is a domain-keyed deterministic
draw (rng.py) keyed by effective seed, contact id, renderer revision, slot name,
and occurrence index, so reruns of the same claim/seed produce identical text and
adding a phrase never shifts fire spread or location perturbation.

Structural redaction: this module imports only `rng` and the standard library.
It never imports a world-state module (scenario, tick, service, maps, episode
state). `render` receives a redacted RenderInput (claim, reported_location,
source_type, public_map_names, seed_material) and cannot reach hidden truth.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from importlib import resources
from typing import Any

from . import rng

RENDERER_REVISION = "1"
MAX_LENGTH = 400

# Source types whose default tone/opener register when the claim carries no plan.
_DEFAULT_TONE = {
    "direct_call": "neutral",
    "panicked_call": "panicked",
    "incomplete_call": "terse",
    "automatic_alarm": "flat",
    "responder_update": "flat",
    "false_alarm_report": "neutral",
    "red_herring_call": "neutral",
}


class RenderError(ValueError):
    """A claim could not be validated/rendered; scenario validation must fail."""


@dataclass(frozen=True)
class RenderInput:
    """Redacted renderer input. No world/scenario object is referenced.

    - claim: canonical expressed claim (duck-typed: incident_type, severity,
      headcount, event_time, source_reliability, evidence, negations,
      language_plan).
    - reported_location: the already-typed public location authority
      (duck-typed: kind, building_id, coordinates.x/.y).
    - source_type: public envelope source type, for frame/tone selection.
    - public_map_names: {building_id: {name, address, aliases:[...]}} public map
      names only; the renderer reads only the reported building's entry.
    - seed_material: {seed, contact_id, occurred_at, delivered_at,
      occurrence_index}.
    """
    claim: Any
    reported_location: Any
    source_type: str
    public_map_names: dict
    seed_material: dict


@dataclass
class RenderResult:
    text: str
    trace: dict = field(default_factory=dict)


_CATALOGUE: dict | None = None


def catalogue() -> dict:
    global _CATALOGUE  # noqa: PLW0603  module-level lazy singleton cache
    if _CATALOGUE is None:
        raw = resources.files("hadr_engine.data.language").joinpath("en.json").read_text()
        _CATALOGUE = json.loads(raw)
    assert _CATALOGUE is not None  # populated by the lazy init above
    return _CATALOGUE


def format_coord(x: float, y: float) -> str:
    """Canonical coordinate tag body. Used for the tag and for tag equality."""
    return f"{x:.1f}, {y:.1f}"


def canonical_tag(reported_location: Any) -> str:
    """The mandatory angle-bracket tag for a typed reported location."""
    if reported_location.kind == "building_id":
        return f"<{reported_location.building_id}>"
    c = reported_location.coordinates
    return f"<{format_coord(c.x, c.y)}>"


class LanguageRenderer:
    def __init__(self) -> None:
        self.cat = catalogue()
        self.revision = RENDERER_REVISION

    # ---- deterministic draws -------------------------------------------

    def _u(self, sm: dict, slot: str) -> float:
        return rng.uniform(
            sm["seed"], rng.DOMAIN_LANGUAGE, sm["occurrence_index"],
            (sm["contact_id"], self.revision), slot)

    def _pick(self, seq, sm: dict, slot: str):
        if not seq:
            return None
        return seq[int(self._u(sm, slot) * len(seq))]

    # ---- validation ----------------------------------------------------

    def validate(self, claim: Any) -> None:
        itype = getattr(claim, "incident_type", None)
        if itype not in ("fire", "none", "unknown"):
            raise RenderError(f"incident_type must be fire/none/unknown, got {itype!r}")
        sev = getattr(claim, "severity", None)
        if sev is not None and "value" not in sev:
            raise RenderError("severity present without a value")
        if sev is not None and sev["value"] not in self.cat["clauses"]["severity"]:
            raise RenderError(f"unknown severity value {sev['value']!r}")
        for token in getattr(claim, "evidence", ()) or ():
            if token not in self.cat["clauses"]["evidence"]:
                raise RenderError(f"unknown evidence token {token!r}")
        for token in getattr(claim, "negations", ()) or ():
            if token not in self.cat["clauses"]["negation"]:
                raise RenderError(f"unknown negation token {token!r}")

    # ---- clause builders ----------------------------------------------

    def _tone(self, claim: Any, source_type: str) -> str:
        plan = getattr(claim, "language_plan", None) or {}
        tone = plan.get("tone")
        if isinstance(tone, str) and tone in self.cat["openers"]:
            return tone
        return _DEFAULT_TONE.get(source_type, "neutral")

    def _disfluency(self, claim: Any) -> str:
        plan = getattr(claim, "language_plan", None) or {}
        level = plan.get("disfluency", "none")
        return level if level in self.cat["disfluency"] else "none"

    def _location_clause(self, ri: RenderInput, trace: dict) -> str:
        loc = ri.reported_location
        sm = ri.seed_material
        tag = canonical_tag(loc)
        if loc.kind == "coordinates":
            lead = self._pick(self.cat["coordinate_lead"], sm, "coordinate_lead")
            trace["location"] = {"kind": "coordinates", "lead": lead, "flavor": "none"}
            return f"{lead} {tag}"
        # Building report: optional public flavor precedes the mandatory tag.
        names = ri.public_map_names.get(loc.building_id, {})
        available = ["none"]
        if names.get("name"):
            available.append("name")
        if names.get("address"):
            available.append("address")
        if names.get("aliases"):
            available.append("alias")
        flavor_kind = self._pick(available, sm, "flavor_kind")
        lead = self._pick(self.cat["building_lead"], sm, "building_lead")
        trace["location"] = {"kind": "building_id", "lead": lead, "flavor": flavor_kind}
        if flavor_kind == "name":
            return f"{lead} the {names['name']} {tag}"
        if flavor_kind == "address":
            return f"{lead} {names['address']} {tag}"
        if flavor_kind == "alias":
            alias = self._pick(list(names["aliases"]), sm, "alias")
            return f"{lead} the {alias} {tag}"
        return f"{lead} {tag}"

    def _incident_clause(self, claim: Any, sm: dict, trace: dict) -> str:
        options = self.cat["clauses"]["incident_type"][claim.incident_type]
        idx = int(self._u(sm, "incident_type") * len(options))
        trace["incident_type"] = idx
        return options[idx]

    def _evidence_clauses(self, claim: Any, sm: dict, trace: dict) -> list[str]:
        out, ids = [], []
        table = self.cat["clauses"]["evidence"]
        for token in claim.evidence or ():
            options = table[token]
            idx = int(self._u(sm, f"evidence:{token}") * len(options))
            out.append(options[idx])
            ids.append({"token": token, "phrase": idx})
        if ids:
            trace["evidence"] = ids
        return out

    def _severity_clause(self, claim: Any, sm: dict, trace: dict) -> str | None:
        sev = claim.severity
        if not sev:
            return None
        options = self.cat["clauses"]["severity"][sev["value"]]
        idx = int(self._u(sm, "severity") * len(options))
        trace["severity"] = {"value": sev["value"], "phrase": idx}
        return options[idx]

    def _headcount_clause(self, claim: Any, sm: dict, trace: dict) -> str | None:
        hc = claim.headcount
        if not hc:
            return None
        qualifier = hc.get("qualifier", "unknown")
        q_table = self.cat["clauses"]["headcount_qualifier"]
        q_options = q_table.get(qualifier, q_table["unknown"])
        q_idx = int(self._u(sm, "headcount_qualifier") * len(q_options))
        q_text = q_options[q_idx]
        value = hc.get("value")
        number, num_style = None, "none"
        if value is not None and qualifier != "all_out":
            num_style, number = self._number(value, sm)
        trace["headcount"] = {"qualifier": qualifier, "phrase": q_idx,
                              "value": value, "number_style": num_style}
        if number is not None:
            noun = "person" if value == 1 else "people"
            return f"{number} {noun} {q_text}"
        return q_text

    def _number(self, value: int, sm: dict) -> tuple[str, str]:
        words = self.cat["numeric"]["words"]
        approx = self.cat["numeric"]["approx"]
        styles = ["digit", "approx_digit"]
        if str(value) in words:
            styles.append("word")
        style = styles[int(self._u(sm, "number_style") * len(styles))]
        if style == "word":
            return "word", words[str(value)]
        if style == "approx_digit":
            a = approx[int(self._u(sm, "number_approx") * len(approx))]
            return "approx_digit", f"{a} {value}"
        return "digit", str(value)

    def _time_clause(self, claim: Any, sm: dict, trace: dict) -> str:
        delay = sm["delivered_at"] - sm["occurred_at"]
        # Some callers state a precise tick count ("2 ticks ago"); others stay vague
        # ("a short while ago"). Seeded per contact so the pool mixes both styles.
        if delay > 0 and self._u(sm, "time_style") < 0.5:
            options = self.cat["clauses"]["time"]["precise"]
            idx = int(self._u(sm, "time") * len(options))
            unit = "tick" if delay == 1 else "ticks"
            trace["event_time"] = {"style": "precise", "phrase": idx, "delay": delay}
            return options[idx].format(n=delay, unit=unit)
        bucket = "just_now" if delay <= 0 else "recent" if delay <= 3 else "delayed"
        options = self.cat["clauses"]["time"][bucket]
        idx = int(self._u(sm, "time") * len(options))
        trace["event_time"] = {"style": "vague", "bucket": bucket, "phrase": idx, "delay": delay}
        return options[idx]

    def _negation_clauses(self, claim: Any, sm: dict, trace: dict) -> list[str]:
        out, ids = [], []
        table = self.cat["clauses"]["negation"]
        for token in claim.negations or ():
            options = table[token]
            idx = int(self._u(sm, f"negation:{token}") * len(options))
            out.append(options[idx])
            ids.append({"token": token, "phrase": idx})
        if ids:
            trace["negations"] = ids
        return out

    # ---- assembly ------------------------------------------------------

    def _assemble(self, ri: RenderInput, compact: bool) -> tuple[str, dict]:
        claim, sm = ri.claim, ri.seed_material
        trace: dict = {"revision": self.revision, "compact": compact, "fields": []}

        tone = self._tone(claim, ri.source_type)
        disfluency = "none" if compact else self._disfluency(claim)
        trace["tone"] = tone
        trace["disfluency"] = disfluency

        location = self._location_clause(ri, trace)
        if compact and trace["location"]["flavor"] != "none":
            location = self._bare_location(ri, trace)
        trace["fields"].append("location")

        clause_map: dict[str, Any] = {"location": location}
        clause_map["incident_type"] = self._incident_clause(claim, sm, trace)
        trace["fields"].append("incident_type")

        ev = self._evidence_clauses(claim, sm, trace)
        if ev:
            clause_map["evidence"] = ev
            trace["fields"].append("evidence")
        sev = self._severity_clause(claim, sm, trace)
        if sev:
            clause_map["severity"] = sev
            trace["fields"].append("severity")
        hc = self._headcount_clause(claim, sm, trace)
        if hc:
            clause_map["headcount"] = hc
            trace["fields"].append("headcount")
        neg = self._negation_clauses(claim, sm, trace)
        if neg:
            clause_map["negation"] = neg
            trace["fields"].append("negations")
        if getattr(claim, "event_time", None) is not None:
            clause_map["time"] = self._time_clause(claim, sm, trace)
            trace["fields"].append("event_time")

        order = self._order(claim, clause_map)
        trace["order"] = order

        parts: list[str] = []
        for slot in order:
            v = clause_map[slot]
            if isinstance(v, list):
                parts.extend(v)
            else:
                parts.append(v)

        opener = self._opener(tone, sm, compact, trace)
        body = self._join(parts, sm, compact)
        if disfluency != "none":
            body = self._insert_disfluency(body, disfluency, sm)
        text = f"{opener} {body}"
        text = self._normalize(text, tone, compact)
        return text, trace

    def _bare_location(self, ri: RenderInput, trace: dict) -> str:
        tag = canonical_tag(ri.reported_location)
        lead = trace["location"]["lead"]
        trace["location"]["flavor"] = "none"
        return f"{lead} {tag}"

    def _order(self, claim: Any, clause_map: dict) -> list[str]:
        plan = getattr(claim, "language_plan", None) or {}
        requested = [s for s in plan.get("detail_order", []) if s in clause_map]
        rest = [s for s in ("location", "incident_type", "evidence", "severity",
                            "headcount", "negation", "time")
                if s in clause_map and s not in requested]
        return requested + rest

    def _opener(self, tone: str, sm: dict, compact: bool, trace: dict) -> str:
        pool = self.cat["compact_openers"] if compact else self.cat["openers"][tone]
        idx = int(self._u(sm, "opener") * len(pool))
        trace["opener"] = {"pool": "compact" if compact else tone, "phrase": idx}
        return pool[idx]

    def _join(self, parts: list[str], sm: dict, compact: bool) -> str:
        if compact:
            return "; ".join(parts)
        connectors = self.cat["connectors"]
        out = parts[0]
        for i, p in enumerate(parts[1:], start=1):
            c = connectors[int(self._u(sm, f"connector:{i}") * len(connectors))]
            out = f"{out}{c}{p}"
        return out

    def _insert_disfluency(self, body: str, level: str, sm: dict) -> str:
        pool = self.cat["disfluency"][level]
        marker = pool[int(self._u(sm, "disfluency") * len(pool))]
        return f"{marker} {body}"

    def _normalize(self, text: str, tone: str, compact: bool) -> str:
        text = re.sub(r"\s+", " ", text).strip()
        text = re.sub(r"\s+([,.;])", r"\1", text)
        text = re.sub(r"([,;])(?=\S)", r"\1 ", text)
        # Capitalize the first letter of every sentence.
        text = re.sub(r"(^|[.!?]\s+)([a-z])",
                      lambda m: m.group(1) + m.group(2).upper(), text)
        if not text.endswith((".", "!", "?")):
            text += "!" if (tone == "panicked" and not compact) else "."
        return text

    # ---- public entry --------------------------------------------------

    def render(self, ri: RenderInput) -> RenderResult:
        self.validate(ri.claim)
        text, trace = self._assemble(ri, compact=False)
        if len(text) > MAX_LENGTH:
            text, trace = self._assemble(ri, compact=True)
        return RenderResult(text=text, trace=trace)


_SINGLETON: LanguageRenderer | None = None


def renderer() -> LanguageRenderer:
    global _SINGLETON  # noqa: PLW0603  module-level lazy singleton cache
    if _SINGLETON is None:
        _SINGLETON = LanguageRenderer()
    return _SINGLETON
