"""Required invariants (DOMAIN.md). Cheap enough to call after scenario load and
after every tick in dev/test builds. Raises InvariantError on any violation.
"""
from __future__ import annotations

import math

from ..maps.repository import Map
from .model import BuildingStatus, EpisodeState, VehicleStatus


class InvariantError(AssertionError):
    """A required domain invariant was violated."""


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise InvariantError(msg)


def check_invariants(state: EpisodeState, map_: Map) -> None:
    fire_by_building: dict[str, int] = {}
    for f in state.fires:
        fire_by_building[f.building_id] = fire_by_building.get(f.building_id, 0) + 1
        # Active fire intensity strictly inside (0, 100).
        _require(0.0 < f.intensity < 100.0,
                 f"fire {f.fire_id} intensity {f.intensity} not strictly in (0, 100)")

    # At most one active fire per building.
    for bid, count in fire_by_building.items():
        _require(count <= 1, f"building {bid} has {count} active fires")

    collapsed = 0
    casualty_sum = 0
    for b in state.buildings:
        if b.status == BuildingStatus.NORMAL:
            _require(b.building_id not in fire_by_building,
                     f"normal building {b.building_id} has an active fire")
            _require(b.casualties == 0, f"normal building {b.building_id} has casualties")
        elif b.status == BuildingStatus.BURNING:
            _require(fire_by_building.get(b.building_id, 0) == 1,
                     f"burning building {b.building_id} lacks exactly one active fire")
        elif b.status == BuildingStatus.COLLAPSED:
            collapsed += 1
            _require(b.building_id not in fire_by_building,
                     f"collapsed building {b.building_id} still has an active fire")
            _require(b.casualties == b.occupants,
                     f"collapsed building {b.building_id} casualties != occupants")
        else:
            raise InvariantError(f"building {b.building_id} has unknown status {b.status}")
        casualty_sum += b.casualties

    # Casualties equal occupants of collapsed buildings; buildings lost is the count.
    _require(state.casualties == casualty_sum,
             f"episode casualties {state.casualties} != sum {casualty_sum}")
    _require(state.buildings_lost == collapsed,
             f"buildings_lost {state.buildings_lost} != collapsed count {collapsed}")

    for v in state.vehicles:
        _require(v.status in (VehicleStatus.IDLE, VehicleStatus.MOVING, VehicleStatus.FIREFIGHTING),
                 f"vehicle {v.vehicle_id} has invalid status {v.status}")
        _require(math.isfinite(v.position.x) and math.isfinite(v.position.y),
                 f"vehicle {v.vehicle_id} position not finite")
        _require(map_.in_world_bounds(v.position),
                 f"vehicle {v.vehicle_id} position outside world bounds")
        if v.status == VehicleStatus.MOVING:
            _require(v.route is not None and v.route.remaining > 0,
                     f"moving vehicle {v.vehicle_id} lacks an active route")
        else:
            _require(v.route is None, f"stationary vehicle {v.vehicle_id} still has a route")
        if v.route is not None:
            _require(
                math.isfinite(v.route.cursor) and 0.0 <= v.route.cursor <= v.route.total + 1e-9,
                f"vehicle {v.vehicle_id} route cursor out of range")

    # Unique IDs in scope.
    _require(len({b.building_id for b in state.buildings}) == len(state.buildings),
             "duplicate building IDs")
    _require(len({f.fire_id for f in state.fires}) == len(state.fires), "duplicate fire IDs")
    _require(len({v.vehicle_id for v in state.vehicles}) == len(state.vehicles),
             "duplicate vehicle IDs")
    _require(len({c.command_id for c in state.command_log}) == len(state.command_log),
             "duplicate command IDs")
    contact_ids = [c.contact_id for c in state.observation.contacts]
    _require(len(set(contact_ids)) == len(contact_ids),
             "duplicate contact IDs in observation")

    # No scheduled truth event before tick zero.
    for e in state.scheduled_ignitions:
        _require(e.tick >= 1, f"scheduled ignition {e.event_id} tick precedes 1")


def check_firefighting_positions(state: EpisodeState, map_: Map, suppression_radius: float) -> None:
    """Separate check that needs the scenario suppression radius: a firefighting
    truck is stationary within suppression_radius of a burning building."""
    burning = {f.building_id for f in state.fires}
    for v in state.vehicles:
        if v.status != VehicleStatus.FIREFIGHTING:
            continue
        _require(v.route is None, f"firefighting vehicle {v.vehicle_id} has a route")
        near = False
        for bid in burning:
            p = map_.building_to_coords(bid)
            if math.hypot(v.position.x - p.x, v.position.y - p.y) <= suppression_radius + 1e-9:
                near = True
                break
        _require(
            near,
            f"firefighting vehicle {v.vehicle_id} not within radius of any burning building")
