"""Simulation domain: model, tick, contacts, language, scenario, baseline."""
