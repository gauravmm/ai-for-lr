"""Deterministic, domain-separated pseudo-random draws (DOMAIN.md "Determinism").

Every value derives from a stable blake2b hash of pipe-joined key parts:

    engine RNG revision | effective seed | domain | tick | stable object ids | draw name

BLAKE2 is fixed by definition and random.Random reproduces the same sequence for
the same seed, so both halves are version-stable. Adding a draw in one domain
never shifts another because the domain string is part of every key.
"""
from __future__ import annotations

import hashlib
import random

RNG_REVISION = "1"

# Named domains keep unrelated draws independent.
DOMAIN_LANGUAGE = "language"
DOMAIN_LOCATION = "location_perturbation"
DOMAIN_TIME = "time_perturbation"
DOMAIN_SPREAD = "spread"
# Build-time only: deterministic per-map selection in the scenario binder.
DOMAIN_BINDER = "binder"


def _digest(seed: int, domain: str, tick: int, object_ids: tuple, draw_name: str) -> bytes:
    parts = [RNG_REVISION, str(seed), domain, str(tick)]
    parts.extend(str(o) for o in object_ids)
    parts.append(draw_name)
    key = "|".join(parts).encode("utf-8")
    return hashlib.blake2b(key, digest_size=8).digest()


def uniform(seed: int, domain: str, tick: int, object_ids: tuple, draw_name: str) -> float:
    """One-shot uniform fraction in [0, 1)."""
    return int.from_bytes(_digest(seed, domain, tick, object_ids, draw_name), "big") / 2 ** 64


def rng(seed: int, domain: str, tick: int, object_ids: tuple, draw_name: str) -> random.Random:
    """Seeded random.Random for multi-draw domains."""
    return random.Random(int.from_bytes(_digest(seed, domain, tick, object_ids, draw_name), "big"))
