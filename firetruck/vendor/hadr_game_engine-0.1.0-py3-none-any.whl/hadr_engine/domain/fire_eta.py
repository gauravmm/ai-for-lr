"""Per-fire tick countdowns, shared by the display snapshot and truck observations.

Pure projection over committed post-tick state: given the fires, vehicles, and
settings, return one Eta per burning building. The tick suppression formula is
replicated exactly -- next = intensity + growth_rate - suppressors *
suppression_rate -- so the derived counts match what the tick will do. A fire is
out at <= 0 (ticks_to_extinguish) and collapses at >= 100 (ticks_to_collapse);
the bound the fire is not heading toward is null. Iteration is over sorted fires
and vehicles: the observation is hashed, so assignment must be deterministic.

Vision gating is NOT applied here -- callers filter as needed. Compute from
committed state, never from tick Phase-4 live counts.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

_COLLAPSE = 100.0


@dataclass(frozen=True)
class Eta:
    suppressors: int
    ticks_to_extinguish: int | None
    ticks_to_collapse: int | None


def fire_eta_table(fires, vehicles, settings, map_) -> dict[str, Eta]:
    """Map building_id -> Eta for every burning building, ignoring vision."""
    supp_rate = settings.suppression_rate
    supp_radius = settings.suppression_radius
    fires = sorted(fires, key=lambda f: f.fire_id)
    vehicles = sorted(vehicles, key=lambda v: v.vehicle_id)
    pts = {f.building_id: map_.building_to_coords(f.building_id) for f in fires}

    def dist(a, b):
        return math.hypot(a.x - b.x, a.y - b.y)

    # Suppressor count per building: replicate tick suppression -- a stationary
    # vehicle suppresses only its single nearest burning building within radius.
    counts: dict[str, int] = {}
    for v in vehicles:
        if v.route is not None:
            continue
        best = None
        for bid in sorted(pts):
            d = dist(v.position, pts[bid])
            if d <= supp_radius + 1e-9:
                cand = (d, bid)
                if best is None or cand < best:
                    best = cand
        if best is not None:
            counts[best[1]] = counts.get(best[1], 0) + 1

    out: dict[str, Eta] = {}
    for f in fires:
        n = counts.get(f.building_id, 0)
        net = f.growth_rate - n * supp_rate  # per-tick delta
        out[f.building_id] = Eta(
            suppressors=n,
            ticks_to_extinguish=math.ceil(f.intensity / -net) if net < 0 else None,
            ticks_to_collapse=math.ceil((_COLLAPSE - f.intensity) / net) if net > 0 else None,
        )
    return out
