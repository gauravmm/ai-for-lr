"""Immutable domain model for the fire-only simulation core.

Every runtime value is a frozen dataclass over tuples (never dict/set) so that
ordered output and equality are stable across processes. The tick function
never mutates these; it builds a brand-new EpisodeState. See DOMAIN.md
"State model" and "Frozen observation".
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum


class Lifecycle(str, Enum):
    LOBBY = "lobby"
    RUNNING = "running"
    TERMINAL = "terminal"
    ABORTED = "aborted"


class TerminalReason(str, Enum):
    RESOLVED = "resolved"
    TICK_LIMIT = "tick_limit"


class VehicleStatus(str, Enum):
    IDLE = "idle"
    MOVING = "moving"
    FIREFIGHTING = "firefighting"


class BuildingStatus(str, Enum):
    NORMAL = "normal"
    BURNING = "burning"
    COLLAPSED = "collapsed"


@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def as_tuple(self) -> tuple[float, float]:
        return (self.x, self.y)


@dataclass(frozen=True)
class BuildingTruth:
    building_id: str
    occupants: int
    status: BuildingStatus = BuildingStatus.NORMAL
    casualties: int = 0
    ever_burned: bool = False


@dataclass(frozen=True)
class FireTruth:
    fire_id: str
    building_id: str
    intensity: float
    growth_rate: float
    ignited_tick: int
    source_event_id: str | None = None


@dataclass(frozen=True)
class ScheduledIgnition:
    event_id: str
    tick: int
    building_id: str
    intensity: float
    growth_rate: float


@dataclass(frozen=True)
class Route:
    """Ordered world-space polyline plus a cursor distance along it."""
    polyline: tuple[Point, ...]
    cursor: float
    total: float
    edges: tuple[str, ...]

    @property
    def remaining(self) -> float:
        return max(0.0, self.total - self.cursor)


@dataclass(frozen=True)
class Destination:
    requested: Point
    snapped: Point


@dataclass(frozen=True)
class VehicleState:
    vehicle_id: str
    label: str
    position: Point
    status: VehicleStatus = VehicleStatus.IDLE
    route: Route | None = None
    destination: Destination | None = None
    incident_id: str | None = None
    last_rationale: str | None = None


@dataclass(frozen=True)
class ReportedLocation:
    """Tagged union: building_id xor coordinates (CONTACTS.md envelope)."""
    kind: str  # "building_id" | "coordinates"
    building_id: str | None = None
    coordinates: Point | None = None


@dataclass(frozen=True)
class ExpressedClaim:
    """Canonical human claim (CONTACTS.md), stored verbatim for the reveal,
    validation, and stage-1 structured delivery. Rendering happens elsewhere."""
    incident_type: str  # "fire" | "none" | "unknown"
    severity: dict | None = None
    headcount: dict | None = None
    event_time: dict | None = None
    source_reliability: str | None = None
    evidence: tuple[str, ...] = ()
    negations: tuple[str, ...] = ()
    language_plan: dict | None = None


@dataclass(frozen=True)
class ObservedBuilding:
    building_id: str
    status: BuildingStatus
    # Derived tick countdowns for burning buildings; null for non-burning and for
    # the bound the fire is not heading toward.
    ticks_to_extinguish: int | None = None
    ticks_to_collapse: int | None = None


@dataclass(frozen=True)
class TruckObservationPayload:
    observer_id: str
    observer_position: Point
    tick: int
    radius: float
    buildings: tuple[ObservedBuilding, ...]


@dataclass(frozen=True)
class StructuredReportPayload:
    claim: ExpressedClaim


@dataclass(frozen=True)
class HumanTextPayload:
    """Rendered public text plus the private render trace (template/phrase IDs).

    The public projection (schemas.ContactPublic) reads `text` only, so the trace
    stays out of control/display responses; run-log tick records serialize the
    whole payload, keeping traces in the debug log/terminal reveal."""
    text: str = ""
    trace: dict | None = None


@dataclass(frozen=True)
class Contact:
    contact_id: str
    source_type: str
    occurred_at: int
    delivered_at: int
    reported_location: ReportedLocation | None
    payload_type: str  # "structured_report" | "human_text" | "truck_observation"
    payload: object


class CommandStatus(str, Enum):
    ACCEPTED = "accepted"
    SUPERSEDED = "superseded"
    REJECTED = "rejected"


@dataclass(frozen=True)
class PendingCommand:
    command_id: str
    vehicle_id: str
    incident_id: str
    rationale: str
    destination: Destination
    route: Route
    tick: int
    status: CommandStatus = CommandStatus.ACCEPTED
    superseded_by: str | None = None


@dataclass(frozen=True)
class Observation:
    observation_id: str
    tick: int
    lifecycle: Lifecycle
    tick_limit: int
    terminal_reason: TerminalReason | None
    contacts: tuple[Contact, ...]
    vehicles: tuple[VehicleState, ...]


@dataclass(frozen=True)
class EpisodeState:
    run_id: str
    scenario_id: str
    schema_revision: int
    engine_revision: str
    rng_revision: str
    seed: int
    lifecycle: Lifecycle
    terminal_reason: TerminalReason | None
    current_tick: int
    tick_limit: int
    buildings: tuple[BuildingTruth, ...]  # sorted by building_id
    fires: tuple[FireTruth, ...]  # sorted by fire_id
    vehicles: tuple[VehicleState, ...]  # sorted by vehicle_id
    scheduled_ignitions: tuple[ScheduledIgnition, ...]  # sorted by (tick, event_id)
    human_contacts: tuple[Contact, ...]  # materialized at creation, sorted
    pending: tuple[PendingCommand, ...]  # effective, one per vehicle, by vehicle_id
    command_log: tuple[PendingCommand, ...]  # append-only, all accepted/superseded
    casualties: int
    buildings_lost: int
    observation: Observation
    next_command_seq: int = 1
    next_fire_seq: int = 1

    # --- lookup helpers (never expose mutable maps) ---

    def building(self, building_id: str) -> BuildingTruth:
        for b in self.buildings:
            if b.building_id == building_id:
                return b
        raise KeyError(building_id)

    def vehicle(self, vehicle_id: str) -> VehicleState:
        for v in self.vehicles:
            if v.vehicle_id == vehicle_id:
                return v
        raise KeyError(vehicle_id)

    def with_replacements(self, **changes) -> EpisodeState:
        return replace(self, **changes)
