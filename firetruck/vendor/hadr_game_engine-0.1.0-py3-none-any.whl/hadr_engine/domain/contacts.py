"""Contact construction: typed truck-vision sensors, location perturbation, and
human-contact materialization.

Truck vision is derived once on entry to a stable tick from world/vehicle state
(DOMAIN.md "Truck vision"): one truck_observation per truck when at least one
building is within the vision radius, buildings in (distance, building_id) order,
observed status only, exact and truthful. Sensors never pass through the language
renderer.

Human contacts are materialized from the validated scenario at episode creation:
the authored base location is first perturbed (domain-seeded, independent per
contact), the perturbed value becomes the public reported_location, and stage-2+
human_text contacts are then rendered from it. The render trace rides along in the
private HumanTextPayload.trace for the run log/terminal reveal only.
"""
from __future__ import annotations

import math
from dataclasses import replace

from ..maps.repository import Map
from . import rng
from .fire_eta import Eta
from .language import RenderInput, RenderResult, renderer
from .model import (
    BuildingStatus,
    Contact,
    HumanTextPayload,
    ObservedBuilding,
    Point,
    ReportedLocation,
    StructuredReportPayload,
    TruckObservationPayload,
    VehicleState,
)

# Source types whose reported location is authoritative and never perturbed.
_FORCE_NONE_SOURCES = frozenset({"automatic_alarm", "responder_update"})
PUBLIC_COORD_PRECISION = 1

# The fine-grained call kinds collapse to one public channel: believability must
# be assessed from the text, and kinds like false_alarm_report would leak the
# answer through metadata. Alias applies wherever a contact becomes public
# (MCP observation, display snapshot, offline datasets); scenario authoring,
# rendering, and the terminal reveal keep the fine-grained value.
_PUBLIC_SOURCE_ALIAS = {
    "direct_call": "public_call",
    "panicked_call": "public_call",
    "incomplete_call": "public_call",
    "false_alarm_report": "public_call",
    "red_herring_call": "public_call",
}


def public_source_type(source_type: str) -> str:
    return _PUBLIC_SOURCE_ALIAS.get(source_type, source_type)


def public_contact_ids(human_contacts) -> dict[str, str]:
    """Authored id -> opaque public id, numbered in the canonical
    (delivered_at, authored id) order the scenario stores. Authored ids encode
    truth (contact-fa, contact-rh, ...) so, like the source-type alias above,
    they never appear on a public surface; RNG and render seeds keep using the
    authored id so perturbations are stable under renumbering."""
    return {sc.contact_id: f"contact-{i:03d}"
            for i, sc in enumerate(human_contacts, 1)}


_MAX_OFFSET_TRIES = 2000


def _distance(a: Point, b: Point) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def truck_vision_contact(vehicle: VehicleState, tick: int, radius: float,
                         building_status: dict[str, object],
                         eta_table: dict[str, Eta], map_: Map) -> Contact | None:
    """One truck_observation for this vehicle at `tick`, or None if no building in range.

    `building_status` maps building_id -> BuildingStatus for the stable tick;
    `eta_table` maps building_id -> Eta for burning buildings (fire_eta_table).
    Burning buildings carry the derived tick countdowns; non-burning carry null.
    """
    observed: list[tuple[float, str, object]] = []
    for bid, building in map_.buildings.items():
        dist = _distance(vehicle.position, building.point)
        if dist <= radius:
            observed.append((dist, bid, building_status[bid]))
    if not observed:
        return None
    observed.sort(key=lambda t: (t[0], t[1]))

    def _observed(bid, status):
        eta = eta_table.get(bid) if status == BuildingStatus.BURNING else None
        if eta is None:
            return ObservedBuilding(bid, status)
        return ObservedBuilding(bid, status, eta.ticks_to_extinguish, eta.ticks_to_collapse)

    payload = TruckObservationPayload(
        observer_id=vehicle.vehicle_id,
        observer_position=vehicle.position,
        tick=tick,
        radius=radius,
        buildings=tuple(_observed(bid, status) for (_d, bid, status) in observed),
    )
    return Contact(
        contact_id=f"sensor-{tick}-{vehicle.vehicle_id}",
        source_type="truck_observation",
        occurred_at=tick,
        delivered_at=tick,
        reported_location=None,
        payload_type="truck_observation",
        payload=payload,
    )


def _round_coords(loc: ReportedLocation) -> ReportedLocation:
    if loc.kind != "coordinates":
        return loc
    p = loc.coordinates
    assert p is not None  # kind == "coordinates" implies coordinates set
    return ReportedLocation(
        kind="coordinates",
        coordinates=Point(round(p.x, PUBLIC_COORD_PRECISION), round(p.y, PUBLIC_COORD_PRECISION)),
    )


def perturb_location(sc, settings, map_: Map, seed: int) -> ReportedLocation:
    """Return the public reported_location after applying the contact's declared
    perturbation. Deterministic per (rng revision, seed, location domain, contact
    id); independent of language and of every other contact."""
    policy = getattr(sc, "location_perturbation", "none")
    if policy == "none" or sc.source_type in _FORCE_NONE_SOURCES:
        return _round_coords(sc.reported_location)

    r = rng.rng(seed, rng.DOMAIN_LOCATION, 0, (sc.contact_id,), policy)
    base = sc.reported_location
    if policy == "coordinate_offset":
        max_off = settings.location_perturbation.coordinate_offset_max
        for _ in range(_MAX_OFFSET_TRIES):
            dist = r.random() * max_off
            angle = r.random() * 2 * math.pi
            x = round(base.coordinates.x + dist * math.cos(angle), PUBLIC_COORD_PRECISION)
            y = round(base.coordinates.y + dist * math.sin(angle), PUBLIC_COORD_PRECISION)
            p = Point(x, y)
            if map_.in_world_bounds(p) and map_.snap_distance(p) <= map_.snap_bound:
                return ReportedLocation(kind="coordinates", coordinates=p)
        raise ValueError(f"contact {sc.contact_id}: no in-bounds coordinate offset found")

    if policy == "building_replacement":
        # Sorted declared set excluding the base: order is the authority, not the
        # authored list order, so the draw is stable.
        candidates = sorted(c for c in settings.location_perturbation.building_candidates
                            if c != base.building_id)
        chosen = candidates[r.randrange(len(candidates))]
        return ReportedLocation(kind="building_id", building_id=chosen)

    raise ValueError(f"contact {sc.contact_id}: unknown perturbation {policy!r}")


def perturb_time(sc, settings, seed: int) -> int:
    """Return the public reported occurred_at after applying the contact's time
    perturbation: the caller's mistaken sense of when the event started. Deterministic
    per (rng revision, seed, time domain, contact id); independent of location and
    language. Clamped to [0, delivered_at] -- a caller cannot place the event before
    tick 0 or after the call itself arrives. The authored occurred_at (truth) stays
    in the scenario definition."""
    policy = getattr(sc, "time_perturbation", "none")
    if policy == "none" or sc.source_type in _FORCE_NONE_SOURCES:
        return sc.occurred_at
    if policy == "tick_offset":
        max_off = settings.time_perturbation.max_offset_ticks
        if max_off <= 0:
            return sc.occurred_at
        r = rng.rng(seed, rng.DOMAIN_TIME, 0, (sc.contact_id,), policy)
        offset = r.randint(-max_off, max_off)
        return max(0, min(sc.delivered_at, sc.occurred_at + offset))
    raise ValueError(f"contact {sc.contact_id}: unknown time perturbation {policy!r}")


def public_map_names(map_: Map) -> dict:
    """Public building name/address/alias table for renderer flavor (no truth)."""
    return {bid: {"name": b.name, "address": b.address, "aliases": list(b.aliases)}
            for bid, b in map_.buildings.items()}


def materialize_human_contact(sc, scenario, map_: Map, seed: int,
                              public_id: str) -> Contact:
    """Turn a validated ScenarioContact into a public Contact envelope carrying
    `public_id` (from public_contact_ids) instead of the authored id.

    Perturbation precedes rendering; the perturbed value is the public authority
    and the rendered canonical tag equals it. Stage-1 structured_report contacts
    carry the canonical claim directly; stage-2+ human_text contacts carry only
    rendered text (plus a private trace)."""
    reported = perturb_location(sc, scenario.settings, map_, seed)
    reported_occurred = perturb_time(sc, scenario.settings, seed)
    if sc.payload_type == "structured_report":
        claim = sc.claim
        if reported_occurred != sc.occurred_at and claim.event_time is not None:
            # Keep the structured claim's stated time consistent with the (drifted)
            # public envelope, so a stage-1 agent sees one coherent mistaken time.
            claim = replace(claim, event_time={**claim.event_time, "tick": reported_occurred})
        payload: object = StructuredReportPayload(claim=claim)
    else:
        result: RenderResult = renderer().render(RenderInput(
            claim=sc.claim,
            reported_location=reported,
            source_type=sc.source_type,
            public_map_names=public_map_names(map_),
            seed_material={
                "seed": seed,
                "contact_id": sc.contact_id,
                # occurred_at drives the spoken/derived delay -> the caller's mistaken
                # time. occurrence_index stays authored so other wording draws are
                # unaffected by time perturbation.
                "occurred_at": reported_occurred,
                "delivered_at": sc.delivered_at,
                "occurrence_index": sc.occurred_at,
            },
        ))
        payload = HumanTextPayload(text=result.text, trace=result.trace)
    return Contact(
        contact_id=public_id,
        source_type=sc.source_type,
        occurred_at=reported_occurred,
        delivered_at=sc.delivered_at,
        reported_location=reported,
        payload_type=sc.payload_type,
        payload=payload,
    )
