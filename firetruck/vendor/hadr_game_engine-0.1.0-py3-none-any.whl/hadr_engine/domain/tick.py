"""Pure tick transition, episode construction, and command queueing.

The transition is a pure function of the stable episode state plus its pending
effective commands. It returns a new immutable EpisodeState and an ordered list
of domain events. No global mutable RNG, no clocks, no IO. Phases follow
DOMAIN.md "Tick transition" 1-10 exactly.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, replace

from ..maps.repository import Map
from ..maps.routing import RoutingError
from . import rng
from .contacts import materialize_human_contact, public_contact_ids, truck_vision_contact
from .fire_eta import fire_eta_table
from .model import (
    BuildingStatus,
    BuildingTruth,
    CommandStatus,
    Contact,
    Destination,
    EpisodeState,
    FireTruth,
    Lifecycle,
    Observation,
    PendingCommand,
    Point,
    Route,
    ScheduledIgnition,
    TerminalReason,
    VehicleState,
    VehicleStatus,
)
from .scenario import Scenario

EPS = 1e-9
ENGINE_REVISION = "1"


class CommandError(ValueError):
    """A dispatch could not be accepted (unroutable or missing fields)."""


@dataclass(frozen=True)
class Event:
    tick: int
    type: str
    data: dict


def _distance(a: Point, b: Point) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def travel_time(route: Route, speed: float) -> int:
    """ceil(remaining / speed): a route shorter than one speed unit is one tick
    unless it has zero length (already there), in which case zero (DOMAIN.md)."""
    if route.remaining <= EPS:
        return 0
    return math.ceil(route.remaining / speed)


def position_at(polyline: tuple[Point, ...], cursor: float) -> Point:
    """Linear interpolation along an ordered polyline at a cursor distance."""
    if not polyline:
        raise ValueError("empty polyline")
    if cursor <= 0:
        return polyline[0]
    remaining = cursor
    for a, b in itertools.pairwise(polyline):
        seg = _distance(a, b)
        if seg <= EPS:
            continue
        if remaining <= seg:
            t = remaining / seg
            return Point(a.x + t * (b.x - a.x), a.y + t * (b.y - a.y))
        remaining -= seg
    return polyline[-1]


@dataclass
class _V:
    vehicle_id: str
    label: str
    position: Point
    status: VehicleStatus
    route: Route | None
    destination: Destination | None
    incident_id: str | None
    last_rationale: str | None


@dataclass
class _F:
    fire_id: str
    building_id: str
    intensity: float
    growth_rate: float
    ignited_tick: int
    source_event_id: str | None


@dataclass
class _B:
    building_id: str
    occupants: int
    status: BuildingStatus
    casualties: int
    ever_burned: bool


def create_episode(scenario: Scenario, map_: Map, run_id: str,
                   seed: int | None = None) -> EpisodeState:
    """Build the tick-0 stable state from a validated scenario."""
    effective_seed = scenario.default_seed if seed is None else seed

    fire_buildings = {f.building_id for f in scenario.initial_fires}
    buildings = tuple(sorted(
        (BuildingTruth(
            building_id=b.building_id,
            occupants=b.occupants,
            status=(
                BuildingStatus.BURNING if b.building_id in fire_buildings else BuildingStatus.NORMAL
            ),
            casualties=0,
            ever_burned=b.building_id in fire_buildings,
        ) for b in map_.buildings.values()),
        key=lambda x: x.building_id,
    ))
    fires = tuple(sorted(
        (FireTruth(f.fire_id, f.building_id, f.intensity, f.growth_rate, 0, None)
         for f in scenario.initial_fires),
        key=lambda x: x.fire_id,
    ))
    vehicles = tuple(sorted(
        (VehicleState(
            vehicle_id=v.vehicle_id,
            label=v.label,
            position=map_.snap(v.start if v.start is not None else map_.center),
            status=VehicleStatus.IDLE,
        ) for v in scenario.vehicles),
        key=lambda x: x.vehicle_id,
    ))
    scheduled = tuple(sorted(
        (ScheduledIgnition(e.event_id, e.tick, e.building_id, e.intensity, e.growth_rate)
         for e in scenario.scheduled_ignitions),
        key=lambda x: (x.tick, x.event_id),
    ))
    public_ids = public_contact_ids(scenario.human_contacts)
    human_contacts = tuple(sorted(
        (materialize_human_contact(c, scenario, map_, effective_seed,
                                   public_ids[c.contact_id])
         for c in scenario.human_contacts),
        key=lambda c: (c.delivered_at, c.contact_id),
    ))

    lifecycle, terminal_reason = _decide_terminal(scenario, 0, bool(fires), scheduled)
    status_map = {b.building_id: b.status for b in buildings}
    observation, _sensor_events = _project_observation(
        run_id, 0, lifecycle, terminal_reason, scenario, map_, vehicles, fires,
        human_contacts, status_map)

    return EpisodeState(
        run_id=run_id,
        scenario_id=scenario.scenario_id,
        schema_revision=scenario.schema_version,
        engine_revision=ENGINE_REVISION,
        rng_revision=rng.RNG_REVISION,
        seed=effective_seed,
        lifecycle=lifecycle,
        terminal_reason=terminal_reason,
        current_tick=0,
        tick_limit=scenario.tick_limit,
        buildings=buildings,
        fires=fires,
        vehicles=vehicles,
        scheduled_ignitions=scheduled,
        human_contacts=human_contacts,
        pending=(),
        command_log=(),
        casualties=0,
        buildings_lost=0,
        observation=observation,
        next_command_seq=1,
        next_fire_seq=1,
    )


def queue_command(state: EpisodeState, scenario: Scenario, map_: Map,
                  vehicle_id: str, requested: Point, incident_id: str,
                  rationale: str) -> tuple[EpisodeState, PendingCommand]:
    """Validate a dispatch, compute its route, and queue it as the effective
    command for `vehicle_id`, superseding any earlier pending command."""
    if state.lifecycle != Lifecycle.RUNNING:
        raise CommandError(f"cannot dispatch in lifecycle {state.lifecycle}")
    try:
        vehicle = state.vehicle(vehicle_id)
    except KeyError:
        raise CommandError(f"unknown vehicle {vehicle_id!r}") from None
    if not (isinstance(incident_id, str) and incident_id.strip()):
        raise CommandError("incident_id must be nonblank")
    if not (isinstance(rationale, str) and rationale.strip()):
        raise CommandError("rationale must be nonblank")

    try:
        route = map_.route(vehicle.position, requested)
    except RoutingError as exc:
        raise CommandError(f"unroutable destination: {exc}") from exc

    snapped = route.polyline[-1] if route.polyline else requested
    destination = Destination(requested=requested, snapped=snapped)
    command_id = f"cmd-{state.next_command_seq}"
    command = PendingCommand(
        command_id=command_id,
        vehicle_id=vehicle_id,
        incident_id=incident_id,
        rationale=rationale,
        destination=destination,
        route=route,
        tick=state.current_tick,
        status=CommandStatus.ACCEPTED,
    )

    # Supersede any earlier pending command for this vehicle.
    new_log = []
    for rec in state.command_log:
        if rec.vehicle_id == vehicle_id and rec.status == CommandStatus.ACCEPTED:
            new_log.append(replace(rec, status=CommandStatus.SUPERSEDED, superseded_by=command_id))
        else:
            new_log.append(rec)
    new_log.append(command)

    new_pending = tuple(sorted(
        [c for c in state.pending if c.vehicle_id != vehicle_id] + [command],
        key=lambda c: c.vehicle_id,
    ))
    new_state = state.with_replacements(
        pending=new_pending,
        command_log=tuple(new_log),
        next_command_seq=state.next_command_seq + 1,
    )
    return new_state, command


def end_tick(state: EpisodeState, scenario: Scenario, map_: Map,
             expected_tick: int) -> tuple[EpisodeState, list[Event]]:
    """Commit interval [t, t+1) and publish stable tick t+1. Pure."""
    if state.lifecycle != Lifecycle.RUNNING:
        raise ValueError(f"end_tick requires RUNNING, got {state.lifecycle}")
    if state.current_tick != expected_tick:
        raise ValueError(f"expected_tick {expected_tick} != current {state.current_tick}")

    t = state.current_tick
    settings = scenario.settings
    speed = settings.truck_speed
    events: list[Event] = []

    vehicles = {v.vehicle_id: _V(v.vehicle_id, v.label, v.position, v.status,
                                 v.route, v.destination, v.incident_id, v.last_rationale)
                for v in state.vehicles}
    fires = {f.fire_id: _F(f.fire_id, f.building_id, f.intensity, f.growth_rate,
                           f.ignited_tick, f.source_event_id)
             for f in state.fires}
    buildings = {b.building_id: _B(b.building_id, b.occupants, b.status, b.casualties,
                                   b.ever_burned)
                 for b in state.buildings}
    casualties = state.casualties
    buildings_lost = state.buildings_lost
    next_fire_seq = state.next_fire_seq

    # -- Phase 2: apply effective orders (vehicle_id order) --
    for cmd in state.pending:  # already sorted by vehicle_id
        v = vehicles[cmd.vehicle_id]
        v.route = Route(cmd.route.polyline, 0.0, cmd.route.total, cmd.route.edges)
        v.destination = cmd.destination
        v.incident_id = cmd.incident_id
        v.last_rationale = cmd.rationale
        v.status = VehicleStatus.MOVING
        events.append(Event(t, "order_applied",
                            {"vehicle_id": v.vehicle_id, "command_id": cmd.command_id}))
        if v.route.total <= EPS:
            # Zero remaining length: resolve arrival immediately before movement.
            v.position = cmd.destination.snapped
            v.route = None
            events.append(Event(t, "arrival", {"vehicle_id": v.vehicle_id}))

    # -- Phase 3: simultaneous movement --
    for vid in sorted(vehicles):
        v = vehicles[vid]
        if v.status != VehicleStatus.MOVING or v.route is None:
            continue
        route = v.route
        new_cursor = route.cursor + speed
        if new_cursor >= route.total - EPS:
            assert v.destination is not None  # a moving vehicle with a route has a destination
            v.position = v.destination.snapped
            v.route = None
            events.append(Event(t, "arrival", {"vehicle_id": vid}))
        else:
            v.route = replace(route, cursor=new_cursor)
            v.position = position_at(route.polyline, new_cursor)
            events.append(Event(t, "movement",
                                {"vehicle_id": vid, "cursor": new_cursor}))

    # -- Phase 4: assign suppression to stationary trucks --
    burning_points = {f.building_id: map_.building_to_coords(f.building_id)
                      for f in fires.values()}
    assigned: dict[str, str] = {}  # vehicle_id -> building_id
    counts: dict[str, int] = {}
    for vid in sorted(vehicles):
        v = vehicles[vid]
        if v.route is not None:  # still moving
            continue
        best: tuple[float, str] | None = None
        for bid in sorted(burning_points):
            dist = _distance(v.position, burning_points[bid])
            if dist <= settings.suppression_radius + EPS:
                cand = (dist, bid)
                if best is None or cand < best:
                    best = cand
        if best is not None:
            bid = best[1]
            assigned[vid] = bid
            counts[bid] = counts.get(bid, 0) + 1
            v.status = VehicleStatus.FIREFIGHTING
            events.append(Event(t, "suppression_contribution",
                                {"vehicle_id": vid, "building_id": bid}))
        else:
            v.status = VehicleStatus.IDLE

    # -- Phase 5 & 6: simultaneous intensity resolution and outcomes --
    for fid in sorted(fires):
        f = fires[fid]
        count = counts.get(f.building_id, 0)
        nxt = f.intensity + f.growth_rate - count * settings.suppression_rate
        events.append(Event(t, "intensity_transition",
                            {"fire_id": fid, "building_id": f.building_id,
                             "from": f.intensity, "to": nxt, "suppressors": count}))
        b = buildings[f.building_id]
        if nxt >= 100.0:
            b.status = BuildingStatus.COLLAPSED
            b.casualties = b.occupants
            casualties += b.occupants
            buildings_lost += 1
            del fires[fid]
            for vid, abid in list(assigned.items()):
                if abid == f.building_id:
                    vehicles[vid].status = VehicleStatus.IDLE
                    del assigned[vid]
            events.append(Event(t, "collapse",
                                {"fire_id": fid, "building_id": f.building_id,
                                 "casualties": b.occupants}))
        elif nxt <= 0.0:
            b.status = BuildingStatus.NORMAL
            del fires[fid]
            for vid, abid in list(assigned.items()):
                if abid == f.building_id:
                    vehicles[vid].status = VehicleStatus.IDLE
                    del assigned[vid]
            events.append(Event(t, "extinguish",
                                {"fire_id": fid, "building_id": f.building_id}))
        else:
            f.intensity = nxt

    # -- Phase 7: optional spread --
    if settings.spread.enabled:
        _apply_spread(state, scenario, map_, t, fires, buildings, events)
        # renumber fire seq for any spread fires created
        next_fire_seq = max([next_fire_seq] + [
            int(fid.rsplit("-", 1)[1]) + 1 for fid in fires
            if fid.startswith("fire-spread-")
        ])

    # -- Phase 8: scheduled ignitions for tick t+1 --
    for e in state.scheduled_ignitions:
        if e.tick != t + 1:
            continue
        b = buildings[e.building_id]
        if b.status == BuildingStatus.COLLAPSED:
            events.append(Event(t, "scheduled_ignition_noop",
                                {"event_id": e.event_id, "building_id": e.building_id,
                                 "reason": "collapsed"}))
        elif b.status == BuildingStatus.BURNING:
            events.append(Event(t, "scheduled_ignition_noop",
                                {"event_id": e.event_id, "building_id": e.building_id,
                                 "reason": "already_burning"}))
        else:
            fid = f"fire-{e.event_id}"
            fires[fid] = _F(fid, e.building_id, e.intensity, e.growth_rate, t + 1, e.event_id)
            b.status = BuildingStatus.BURNING
            b.ever_burned = True
            events.append(Event(t, "scheduled_ignition",
                                {"event_id": e.event_id, "fire_id": fid,
                                 "building_id": e.building_id}))

    # -- Phase 9: advance and decide terminal state --
    new_tick = t + 1
    remaining_scheduled = tuple(e for e in state.scheduled_ignitions if e.tick > new_tick)
    lifecycle, terminal_reason = _decide_terminal_raw(
        scenario, new_tick, bool(fires), remaining_scheduled)

    # -- Phase 10: project next stable state --
    frozen_vehicles = tuple(sorted(
        (VehicleState(v.vehicle_id, v.label, v.position, v.status, v.route,
                      v.destination, v.incident_id, v.last_rationale)
         for v in vehicles.values()),
        key=lambda x: x.vehicle_id,
    ))
    frozen_buildings = tuple(sorted(
        (BuildingTruth(b.building_id, b.occupants, b.status, b.casualties, b.ever_burned)
         for b in buildings.values()),
        key=lambda x: x.building_id,
    ))
    frozen_fires = tuple(sorted(
        (FireTruth(f.fire_id, f.building_id, f.intensity, f.growth_rate,
                   f.ignited_tick, f.source_event_id) for f in fires.values()),
        key=lambda x: x.fire_id,
    ))
    status_map = {b.building_id: b.status for b in frozen_buildings}
    observation, sensor_events = _project_observation(
        state.run_id, new_tick, lifecycle, terminal_reason, scenario, map_,
        frozen_vehicles, frozen_fires, state.human_contacts, status_map)
    events.extend(sensor_events)
    events.append(Event(t, "terminal_decision",
                        {"new_tick": new_tick, "lifecycle": lifecycle.value,
                         "terminal_reason": terminal_reason.value if terminal_reason else None}))

    new_state = state.with_replacements(
        lifecycle=lifecycle,
        terminal_reason=terminal_reason,
        current_tick=new_tick,
        buildings=frozen_buildings,
        fires=frozen_fires,
        vehicles=frozen_vehicles,
        pending=(),
        casualties=casualties,
        buildings_lost=buildings_lost,
        observation=observation,
        next_fire_seq=next_fire_seq,
    )
    return new_state, events


def _project_observation(run_id, tick, lifecycle, terminal_reason, scenario, map_,
                         vehicles, fires, human_contacts, status_map):
    eta_table = fire_eta_table(fires, vehicles, scenario.settings, map_)
    sensor_events: list[Event] = []
    contacts: list[Contact] = []
    for v in vehicles:  # already vehicle_id sorted
        c = truck_vision_contact(v, tick, scenario.settings.truck_vision_radius,
                                 status_map, eta_table, map_)
        if c is not None:
            contacts.append(c)
            sensor_events.append(Event(tick, "sensor_generation",
                                       {"contact_id": c.contact_id, "vehicle_id": v.vehicle_id}))
    contacts.extend(c for c in human_contacts if c.delivered_at == tick)
    contacts.sort(key=lambda c: (c.delivered_at, c.contact_id))
    observation = Observation(
        observation_id=f"{run_id}:obs:{tick}",
        tick=tick,
        lifecycle=lifecycle,
        tick_limit=scenario.tick_limit,
        terminal_reason=terminal_reason,
        contacts=tuple(contacts),
        vehicles=tuple(vehicles),
    )
    return observation, sensor_events


def _decide_terminal_raw(scenario: Scenario, new_tick: int, has_fires: bool,
                         remaining_scheduled) -> tuple[Lifecycle, TerminalReason | None]:
    if not has_fires and not remaining_scheduled:
        return Lifecycle.TERMINAL, TerminalReason.RESOLVED
    if new_tick >= scenario.tick_limit:
        return Lifecycle.TERMINAL, TerminalReason.TICK_LIMIT
    return Lifecycle.RUNNING, None


def _decide_terminal(scenario: Scenario, tick: int, has_fires: bool,
                     scheduled) -> tuple[Lifecycle, TerminalReason | None]:
    """Terminal decision for the initial (tick 0) state."""
    future = tuple(e for e in scheduled if e.tick > tick)
    return _decide_terminal_raw(scenario, tick, has_fires, future)


def _apply_spread(state, scenario, map_, t, fires, buildings, events) -> None:
    spread = scenario.settings.spread
    ignited: set[str] = set()
    # Surviving fires above the threshold, in fire_id order.
    source_ids = sorted(fid for fid in fires
                        if fires[fid].intensity >= spread.threshold)
    for fid in source_ids:
        src = fires[fid]
        src_point = map_.building_to_coords(src.building_id)
        # Sorted adjacency: normal buildings within radius, excluding the source.
        targets = sorted(
            bid for bid, b in buildings.items()
            if b.status == BuildingStatus.NORMAL and bid != src.building_id
            and bid not in ignited
            and _distance(src_point, map_.building_to_coords(bid)) <= spread.radius
        )
        for bid in targets:
            draw = rng.uniform(state.seed, rng.DOMAIN_SPREAD, t,
                               (fid, bid), "spread")
            if draw < spread.probability:
                nfid = f"fire-spread-{state.next_fire_seq + len(ignited)}"
                fires[nfid] = _F(nfid, bid, spread.new_intensity,
                                 spread.new_growth_rate, t + 1, None)
                buildings[bid].status = BuildingStatus.BURNING
                buildings[bid].ever_burned = True
                ignited.add(bid)
                events.append(Event(t, "spread_ignition",
                                    {"fire_id": nfid, "building_id": bid,
                                     "source_fire_id": fid}))
