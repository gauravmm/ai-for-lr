"""Scenario artifact parsing and validation (SCENARIOS.md).

Loads a schema_version 1 scenario dict into frozen dataclasses and runs the
statically checkable validations: referential integrity, numeric bounds,
delivery within horizon, exactly one reported_location per human contact,
red herrings with no linked fire event, and reachability of every used
building from every vehicle start.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..maps.repository import Map
from ..maps.routing import RoutingError
from .model import ExpressedClaim, Point, ReportedLocation

SCHEMA_VERSION = 1

HUMAN_SOURCE_TYPES = {
    "direct_call", "panicked_call", "incomplete_call", "automatic_alarm",
    "responder_update", "false_alarm_report", "red_herring_call",
}
DISPLAY_POLICIES = {"public_only", "full_state"}
INCIDENT_TYPES = {"fire", "none", "unknown"}
PERTURBATIONS = {"none", "coordinate_offset", "building_replacement"}
# Reliable sources whose reported location must not be perturbed.
FORCE_NONE_SOURCES = {"automatic_alarm", "responder_update"}

DEFAULT_SETTINGS = {
    "truck_speed": 30.0,
    "suppression_rate": 12.0,
    "suppression_radius": 25.0,
    "truck_vision_radius": 45.0,
}


class ScenarioError(ValueError):
    """A scenario failed validation and must not run."""


@dataclass(frozen=True)
class LocationPerturbation:
    coordinate_offset_max: float = 0.0
    building_candidates: tuple[str, ...] = ()


@dataclass(frozen=True)
class TimePerturbation:
    max_offset_ticks: int = 0   # public occurred_at drifts by +/- up to this many ticks


@dataclass(frozen=True)
class SpreadSettings:
    enabled: bool = False
    threshold: float = 50.0
    probability: float = 0.0
    radius: float = 0.0
    new_intensity: float = 1.0
    new_growth_rate: float = 0.0


@dataclass(frozen=True)
class Settings:
    truck_speed: float
    suppression_rate: float
    suppression_radius: float
    truck_vision_radius: float
    spread: SpreadSettings
    location_perturbation: LocationPerturbation
    time_perturbation: TimePerturbation = TimePerturbation()


@dataclass(frozen=True)
class ScenarioVehicle:
    vehicle_id: str
    label: str
    start: Point | None  # requested world point; None -> default map centre


@dataclass(frozen=True)
class ScenarioFire:
    fire_id: str
    building_id: str
    intensity: float
    growth_rate: float


@dataclass(frozen=True)
class ScenarioIgnition:
    event_id: str
    tick: int
    building_id: str
    intensity: float
    growth_rate: float


@dataclass(frozen=True)
class ScenarioContact:
    contact_id: str
    source_type: str
    occurred_at: int
    delivered_at: int
    reported_location: ReportedLocation
    claim: ExpressedClaim
    payload_type: str  # "structured_report" | "human_text"
    red_herring: bool = False
    location_perturbation: str = "none"  # none | coordinate_offset | building_replacement
    time_perturbation: str = "none"      # none | tick_offset


@dataclass(frozen=True)
class Scenario:
    schema_version: int
    scenario_id: str
    title: str
    public_description: str
    difficulty_stage: int
    map_id: str
    tick_limit: int
    display_policy: str
    default_seed: int
    settings: Settings
    vehicles: tuple[ScenarioVehicle, ...]
    initial_fires: tuple[ScenarioFire, ...]
    scheduled_ignitions: tuple[ScenarioIgnition, ...]
    human_contacts: tuple[ScenarioContact, ...]


def _require(cond: object, msg: str) -> None:
    if not cond:
        raise ScenarioError(msg)


def _num(v, name: str) -> float:
    _require(isinstance(v, (int, float)) and not isinstance(v, bool), f"{name} must be numeric")
    return float(v)


def _parse_point(raw, name: str) -> Point:
    _require(isinstance(raw, dict) and "x" in raw and "y" in raw,
             f"{name} must be an {{x, y}} object")
    return Point(_num(raw["x"], f"{name}.x"), _num(raw["y"], f"{name}.y"))


def _parse_reported_location(raw, name: str) -> ReportedLocation:
    _require(isinstance(raw, dict) and "kind" in raw, f"{name} must have a kind")
    kind = raw["kind"]
    if kind == "building_id":
        _require("building_id" in raw, f"{name} building report needs building_id")
        return ReportedLocation(kind="building_id", building_id=raw["building_id"])
    if kind == "coordinates":
        return ReportedLocation(kind="coordinates",
                                coordinates=_parse_point(raw["coordinates"], f"{name}.coordinates"))
    raise ScenarioError(f"{name} kind must be building_id or coordinates, got {kind!r}")


def _parse_claim(raw, name: str) -> ExpressedClaim:
    _require(isinstance(raw, dict), f"{name} must be an object")
    itype = raw.get("incident_type")
    _require(
        itype in INCIDENT_TYPES, f"{name}.incident_type must be one of {sorted(INCIDENT_TYPES)}")
    return ExpressedClaim(
        incident_type=itype,
        severity=raw.get("severity"),
        headcount=raw.get("headcount"),
        event_time=raw.get("event_time"),
        source_reliability=raw.get("source_reliability"),
        evidence=tuple(raw.get("evidence", ())),
        negations=tuple(raw.get("negations", ())),
        language_plan=raw.get("language_plan"),
    )


def load_scenario(data: dict, map_: Map) -> Scenario:
    _require(isinstance(data, dict), "scenario must be a JSON object")
    _require(data.get("schema_version") == SCHEMA_VERSION,
             f"schema_version must be {SCHEMA_VERSION}")
    for key in ("scenario_id", "map_id", "tick_limit", "settings", "vehicles"):
        _require(key in data, f"scenario missing required field {key!r}")
    _require(data["map_id"] == map_.map_id,
             f"scenario map_id {data['map_id']!r} != loaded map {map_.map_id!r}")

    tick_limit = data["tick_limit"]
    _require(isinstance(tick_limit, int) and tick_limit > 0, "tick_limit must be a positive int")
    display_policy = data.get("display_policy", "public_only")
    _require(
        display_policy in DISPLAY_POLICIES,
        f"display_policy must be one of {sorted(DISPLAY_POLICIES)}")
    default_seed = data.get("default_seed", 0)
    _require(isinstance(default_seed, int), "default_seed must be an int")

    settings = _parse_settings(data["settings"], map_)
    vehicles = _parse_vehicles(data["vehicles"], map_)
    truth = data.get("truth", {})
    initial_fires = _parse_initial_fires(truth.get("initial_fires", []), map_)
    scheduled = _parse_scheduled(truth.get("scheduled_ignitions", []), map_, tick_limit)
    contacts = _parse_contacts(data.get("human_contacts", []), map_, tick_limit,
                               settings, default_seed)

    _cross_validate(initial_fires, scheduled)
    _check_reachability(vehicles, initial_fires, scheduled, contacts, map_)

    return Scenario(
        schema_version=SCHEMA_VERSION,
        scenario_id=data["scenario_id"],
        title=data.get("title", ""),
        public_description=data.get("public_description", ""),
        difficulty_stage=int(data.get("difficulty_stage", 1)),
        map_id=data["map_id"],
        tick_limit=tick_limit,
        display_policy=display_policy,
        default_seed=default_seed,
        settings=settings,
        vehicles=vehicles,
        initial_fires=initial_fires,
        scheduled_ignitions=scheduled,
        human_contacts=contacts,
    )


def _parse_settings(raw: dict, map_: Map) -> Settings:
    _require(isinstance(raw, dict), "settings must be an object")
    merged = {**DEFAULT_SETTINGS, **{k: raw[k] for k in DEFAULT_SETTINGS if k in raw}}
    speed = _num(merged["truck_speed"], "truck_speed")
    _require(speed > 0, "truck_speed must be positive")
    supp_rate = _num(merged["suppression_rate"], "suppression_rate")
    supp_radius = _num(merged["suppression_radius"], "suppression_radius")
    vision = _num(merged["truck_vision_radius"], "truck_vision_radius")
    _require(supp_rate >= 0 and supp_radius >= 0 and vision >= 0,
             "suppression_rate, suppression_radius, truck_vision_radius must be nonnegative")

    spread_raw = raw.get("spread", {"enabled": False})
    _require(isinstance(spread_raw, dict), "settings.spread must be an object")
    enabled = bool(spread_raw.get("enabled", False))
    spread = SpreadSettings(
        enabled=enabled,
        threshold=_num(spread_raw.get("threshold", 50.0), "spread.threshold"),
        probability=_num(spread_raw.get("probability", 0.0), "spread.probability"),
        radius=_num(spread_raw.get("radius", 0.0), "spread.radius"),
        new_intensity=_num(spread_raw.get("new_intensity", 1.0), "spread.new_intensity"),
        new_growth_rate=_num(spread_raw.get("new_growth_rate", 0.0), "spread.new_growth_rate"),
    )
    if enabled:
        _require(0.0 < spread.new_intensity < 100.0,
                 "spread.new_intensity must be in the open interval (0, 100)")
    if enabled:
        _require(0.0 <= spread.probability <= 1.0, "spread.probability must be in [0, 1]")
        _require(spread.radius > 0, "spread.radius must be positive when spread is enabled")

    pert_raw = raw.get("location_perturbation", {})
    _require(isinstance(pert_raw, dict), "settings.location_perturbation must be an object")
    candidates = tuple(pert_raw.get("building_candidates", ()))
    for cid in candidates:
        _require(map_.has_building(cid), f"perturbation candidate {cid!r} is not a map building")
    _require(list(candidates) == sorted(candidates), "building_candidates must be sorted")
    _require(len(candidates) == len(set(candidates)), "building_candidates must be unique")
    perturbation = LocationPerturbation(
        coordinate_offset_max=_num(
            pert_raw.get("coordinate_offset_max", 0.0), "coordinate_offset_max"),
        building_candidates=candidates,
    )
    _require(perturbation.coordinate_offset_max >= 0, "coordinate_offset_max must be nonnegative")

    time_raw = raw.get("time_perturbation", {})
    _require(isinstance(time_raw, dict), "settings.time_perturbation must be an object")
    time_pert = TimePerturbation(max_offset_ticks=int(time_raw.get("max_offset_ticks", 0)))
    _require(time_pert.max_offset_ticks >= 0, "max_offset_ticks must be nonnegative")

    return Settings(speed, supp_rate, supp_radius, vision, spread, perturbation, time_pert)


def _parse_vehicles(raw, map_: Map) -> tuple[ScenarioVehicle, ...]:
    _require(isinstance(raw, list) and raw, "vehicles must be a non-empty list")
    seen: set[str] = set()
    out: list[ScenarioVehicle] = []
    for v in raw:
        vid = v.get("vehicle_id")
        _require(isinstance(vid, str) and vid, "vehicle_id must be a nonblank string")
        _require(vid not in seen, f"duplicate vehicle_id {vid!r}")
        seen.add(vid)
        start = _parse_point(v["start"], f"vehicle {vid} start") if v.get("start") else None
        target = start if start is not None else map_.center
        try:
            map_.snap(target)
        except RoutingError as exc:
            raise ScenarioError(f"vehicle {vid} start does not snap within bound: {exc}") from exc
        out.append(ScenarioVehicle(vehicle_id=vid, label=v.get("label", vid), start=start))
    return tuple(sorted(out, key=lambda x: x.vehicle_id))


def _parse_initial_fires(raw, map_: Map) -> tuple[ScenarioFire, ...]:
    _require(isinstance(raw, list), "initial_fires must be a list")
    seen_fire, seen_building = set(), set()
    out: list[ScenarioFire] = []
    for i, f in enumerate(raw):
        bid = f.get("building_id")
        _require(map_.has_building(bid), f"initial fire references unknown building {bid!r}")
        _require(bid not in seen_building, f"more than one initial fire on building {bid!r}")
        seen_building.add(bid)
        fid = f.get("fire_id", f"fire-init-{i}")
        _require(fid not in seen_fire, f"duplicate fire_id {fid!r}")
        seen_fire.add(fid)
        intensity = _num(f["intensity"], f"fire {fid} intensity")
        _require(
            0.0 < intensity < 100.0, f"fire {fid} intensity must be in the open interval (0, 100)")
        growth = _num(f.get("growth_rate", 0.0), f"fire {fid} growth_rate")
        _require(growth >= 0, f"fire {fid} growth_rate must be nonnegative")
        out.append(ScenarioFire(fid, bid, intensity, growth))
    return tuple(sorted(out, key=lambda x: x.fire_id))


def _parse_scheduled(raw, map_: Map, tick_limit: int) -> tuple[ScenarioIgnition, ...]:
    _require(isinstance(raw, list), "scheduled_ignitions must be a list")
    seen: set[str] = set()
    out: list[ScenarioIgnition] = []
    for i, e in enumerate(raw):
        eid = e.get("event_id", f"ign-{i}")
        _require(eid not in seen, f"duplicate scheduled event_id {eid!r}")
        seen.add(eid)
        bid = e.get("building_id")
        _require(map_.has_building(bid), f"scheduled ignition references unknown building {bid!r}")
        tick = e.get("tick")
        _require(isinstance(tick, int) and 1 <= tick <= tick_limit,
                 f"scheduled ignition {eid} tick must be an int in [1, {tick_limit}]")
        intensity = _num(e["intensity"], f"ignition {eid} intensity")
        _require(0.0 < intensity < 100.0, f"ignition {eid} intensity must be in (0, 100)")
        growth = _num(e.get("growth_rate", 0.0), f"ignition {eid} growth_rate")
        _require(growth >= 0, f"ignition {eid} growth_rate must be nonnegative")
        out.append(ScenarioIgnition(eid, tick, bid, intensity, growth))
    return tuple(sorted(out, key=lambda x: (x.tick, x.event_id)))


def _parse_contacts(raw, map_: Map, tick_limit: int, settings: Settings,
                    default_seed: int) -> tuple[ScenarioContact, ...]:
    _require(isinstance(raw, list), "human_contacts must be a list")
    seen: set[str] = set()
    out: list[ScenarioContact] = []
    for c in raw:
        cid = c.get("contact_id")
        _require(isinstance(cid, str) and cid, "contact_id must be a nonblank string")
        _require(cid not in seen, f"duplicate contact_id {cid!r}")
        seen.add(cid)
        stype = c.get("source_type")
        _require(stype in HUMAN_SOURCE_TYPES,
                 f"contact {cid} source_type {stype!r} not a human type")
        occurred = c.get("occurred_at")
        delivered = c.get("delivered_at")
        _require(isinstance(occurred, int) and occurred >= 0,
                 f"contact {cid} occurred_at must be a tick >= 0")
        _require(isinstance(delivered, int) and 0 <= delivered <= tick_limit,
                 f"contact {cid} delivered_at must be within [0, {tick_limit}]")
        _require(occurred <= delivered, f"contact {cid} occurred_at must be <= delivered_at")
        _require("reported_location" in c, f"contact {cid} needs exactly one reported_location")
        loc = _parse_reported_location(c["reported_location"], f"contact {cid} reported_location")
        if loc.kind == "building_id":
            assert loc.building_id is not None  # kind == "building_id" implies building_id set
            _require(map_.has_building(loc.building_id),
                     f"contact {cid} reports unknown building {loc.building_id!r}")
        else:
            assert loc.coordinates is not None  # otherwise kind == "coordinates" implies set
            _require(map_.in_world_bounds(loc.coordinates),
                     f"contact {cid} coordinates fall outside map world bounds")
        claim = _parse_claim(c.get("claim", {}), f"contact {cid} claim")
        red_herring = bool(c.get("red_herring", False)) or stype == "red_herring_call"
        if red_herring:
            _require(claim.incident_type == "none" or bool(c.get("ambiguous", False)),
                     f"red herring {cid} must express incident_type none unless flagged ambiguous")
            _require("truth_event" not in c.get("relations", {}),
                     f"red herring {cid} must not link to a fire truth event")
        # Default to the harder modality: a forgotten payload_type should not
        # silently hand the participant a claim that skips their intake model.
        payload_type = c.get("payload_type", "human_text")
        _require(payload_type in ("structured_report", "human_text"),
                 f"contact {cid} payload_type must be structured_report or human_text")
        perturbation = c.get("location_perturbation", "none")
        _require(perturbation in PERTURBATIONS,
                 f"contact {cid} location_perturbation must be one of {sorted(PERTURBATIONS)}")
        time_pert = c.get("time_perturbation", "none")
        _require(time_pert in ("none", "tick_offset"),
                 f"contact {cid} time_perturbation must be 'none' or 'tick_offset'")
        sc = ScenarioContact(cid, stype, occurred, delivered, loc, claim,
                             payload_type, red_herring, perturbation, time_pert)
        _validate_perturbation(sc, settings, map_, default_seed)
        if payload_type == "human_text":
            _validate_renderable(sc, map_, default_seed)
        out.append(sc)
    return tuple(sorted(out, key=lambda x: (x.delivered_at, x.contact_id)))


def _validate_perturbation(sc: ScenarioContact, settings: Settings, map_: Map,
                           seed: int) -> None:
    from .contacts import perturb_location

    policy = sc.location_perturbation
    if sc.source_type in FORCE_NONE_SOURCES:
        _require(policy == "none",
                 f"contact {sc.contact_id}: {sc.source_type} must not be perturbed")
        return
    if policy == "none":
        return
    if policy == "coordinate_offset":
        _require(sc.reported_location.kind == "coordinates",
                 f"contact {sc.contact_id}: coordinate_offset needs a coordinate report")
        _require(settings.location_perturbation.coordinate_offset_max > 0,
                 f"contact {sc.contact_id}: coordinate_offset needs a positive bound")
    elif policy == "building_replacement":
        _require(sc.reported_location.kind == "building_id",
                 f"contact {sc.contact_id}: building_replacement needs a building report")
        eligible = [b for b in settings.location_perturbation.building_candidates
                    if b != sc.reported_location.building_id]
        _require(bool(eligible),
                 f"contact {sc.contact_id}: building_replacement has no eligible candidate")
    # Deterministic dry run: must resolve within bounds for the published seed.
    try:
        result = perturb_location(sc, settings, map_, seed)
    except ValueError as exc:
        raise ScenarioError(str(exc)) from exc
    if result.kind == "building_id":
        _require(result.building_id != sc.reported_location.building_id,
                 f"contact {sc.contact_id}: replacement selected the original building")
    else:
        assert result.coordinates is not None  # kind == "coordinates" implies coordinates set
        _require(map_.in_world_bounds(result.coordinates),
                 f"contact {sc.contact_id}: perturbed coordinates fall outside map bounds")


def _validate_renderable(sc: ScenarioContact, map_: Map, seed: int) -> None:
    from .contacts import public_map_names
    from .language import RenderError, RenderInput, renderer

    ri = RenderInput(
        claim=sc.claim,
        reported_location=sc.reported_location,
        source_type=sc.source_type,
        public_map_names=public_map_names(map_),
        seed_material={"seed": seed, "contact_id": sc.contact_id,
                       "occurred_at": sc.occurred_at, "delivered_at": sc.delivered_at,
                       "occurrence_index": sc.occurred_at},
    )
    try:
        renderer().render(ri)
    except RenderError as exc:
        raise ScenarioError(f"contact {sc.contact_id} is not renderable: {exc}") from exc


def _cross_validate(fires, scheduled) -> None:
    # An ignition of a building that already carries an initial fire is a
    # recorded no-op at runtime, which is allowed. Reject only ambiguous
    # same-building/same-tick scheduled pairs.
    seen: set[tuple[str, int]] = set()
    for e in scheduled:
        key = (e.building_id, e.tick)
        _require(key not in seen,
                 f"two scheduled ignitions target {e.building_id} at tick {e.tick}")
        seen.add(key)


def _check_reachability(vehicles, fires, scheduled, contacts, map_: Map) -> None:
    used = {f.building_id for f in fires}
    used |= {e.building_id for e in scheduled}
    used |= {c.reported_location.building_id for c in contacts
             if c.reported_location.kind == "building_id"}
    if not used:
        return
    for v in vehicles:
        start = v.start if v.start is not None else map_.center
        for bid in sorted(used):
            try:
                map_.route(start, map_.building_to_coords(bid))
            except RoutingError as exc:
                raise ScenarioError(
                    f"building {bid} is unreachable from vehicle {v.vehicle_id} start: {exc}"
                ) from exc
