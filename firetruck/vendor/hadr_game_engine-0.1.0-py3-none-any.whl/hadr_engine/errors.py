"""Typed engine errors carrying a stable machine code from the API.md catalogue.

One exception type. Messages may improve without breaking clients; the code is
the contract. Internal exceptions never leak tracebacks, filesystem paths, run
log contents, or hidden state through the code/message pair.
"""
from __future__ import annotations

from enum import Enum


class ErrorCode(str, Enum):
    INVALID_REQUEST = "INVALID_REQUEST"
    CONTROLLER_DISPLACED = "CONTROLLER_DISPLACED"
    EPISODE_NOT_RUNNING = "EPISODE_NOT_RUNNING"
    TICK_MISMATCH = "TICK_MISMATCH"
    UNKNOWN_VEHICLE = "UNKNOWN_VEHICLE"
    UNKNOWN_BUILDING = "UNKNOWN_BUILDING"
    INVALID_DESTINATION = "INVALID_DESTINATION"
    NO_ROUTE = "NO_ROUTE"
    COMMAND_REJECTED = "COMMAND_REJECTED"
    DATA_INVALID = "DATA_INVALID"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class EngineError(Exception):
    """A control-surface error with a stable machine code and optional safe details."""

    def __init__(self, code: ErrorCode, message: str, details: dict | None = None):
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(f"{code.value}: {message}")
