"""Build-time scenario generation: map-agnostic templates and a deterministic binder.

A template is a map-agnostic recipe expressed as constraints (fire count with
intensity/growth ranges, occupancy preferences, pairwise travel-time separation,
contact scripts with tick offsets, vehicle count, settings). The binder
instantiates a template against a packaged map's manifest into a concrete,
immutable scenario JSON artifact that validates against the runtime scenario
loader (domain/scenario.py). Selection is deterministic for a given
(template, map, binder seed); a template whose constraints cannot be satisfied on
a map raises BindError loudly rather than emitting a degenerate scenario.

This is a build tool, not a runtime product: plain functions, no plugin registry.
Committed packaged scenarios under data/scenarios/ are binder output.
"""
from .binder import BindError, bind, bind_all
from .templates import TEMPLATES

__all__ = ["TEMPLATES", "BindError", "bind", "bind_all"]
