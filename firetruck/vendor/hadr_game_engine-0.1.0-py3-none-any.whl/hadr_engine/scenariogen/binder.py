"""Deterministic template -> scenario binder.

Selects concrete buildings/coords per map satisfying a template's occupancy and
pairwise travel-time separation constraints, materializes contacts with concrete
reported locations and canonical claims, and emits scenario JSON that validates
through domain/scenario.load_scenario. Building selection uses domain-keyed draws
(rng.DOMAIN_BINDER) over (template_id, map_id, binder_seed), so output is stable
for a given (template, map, seed) and byte-identical across runs.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from ..domain.scenario import load_scenario
from ..maps.repository import Map

ID_SEP = "@"  # scenario_id convention: <template_id>@<map_id>


class BindError(ValueError):
    """A template's constraints cannot be satisfied on a map. Raised loudly so a
    degenerate scenario is never emitted."""


@dataclass(frozen=True)
class FireSpec:
    """A fire the template needs, described by occupancy preference and dynamics,
    not by a concrete building ID."""
    key: str                       # logical handle referenced by contacts
    occupancy: str                 # "high" | "medium" | "low" | "empty" | "any"
    intensity: float
    growth_rate: float
    ignition_tick: int = 0         # 0 -> initial fire; >0 -> scheduled ignition


@dataclass(frozen=True)
class ContactSpec:
    """A human contact, timed relative to its fire's ignition tick. When
    ``fire_key`` is None the contact is a decoy (red herring / standalone false
    alarm) placed on an empty building or offset coordinate."""
    key: str
    source_type: str
    incident_type: str             # "fire" | "unknown" | "none"
    occurred_offset: int           # ticks after the fire's ignition (>=0)
    delivered_offset: int          # ticks after ignition when delivered
    fire_key: str | None = None
    severity: str | None = None
    severity_conf: float = 0.7
    headcount: object | None = None  # int, None, or "auto" (real fire occupants)
    headcount_qualifier: str = "possibly_trapped"
    headcount_conf: float = 0.5
    source_reliability: str | None = None
    evidence: tuple[str, ...] = ()
    negations: tuple[str, ...] = ()
    tone: str = "neutral"
    disfluency: str = "none"
    detail_order: tuple[str, ...] = ("location", "incident_type", "evidence", "severity")
    payload_type: str = "structured_report"
    location: str = "fire_building"    # fire_building | coordinate | decoy_building
    location_perturbation: str = "none"
    time_perturbation: str = "none"    # none | tick_offset
    with_event_time: bool = False


@dataclass(frozen=True)
class Template:
    template_id: str
    title: str
    public_description: str
    difficulty_stage: int
    tick_limit: int
    display_policy: str
    default_seed: int
    binder_seed: int
    suppression_rate: float
    suppression_radius: float
    truck_vision_radius: float
    vehicle_count: int
    fires: tuple[FireSpec, ...]
    contacts: tuple[ContactSpec, ...]
    # Truck speed is derived per map so the farthest selected fire sits ~reach_ticks
    # from the map centre; this normalizes travel geometry across maps of very
    # different physical scale, keeping the lesson (which fire is lost) map-stable.
    reach_ticks: int = 6
    min_separation_ticks: int = 0      # min pairwise fire travel-time separation
    max_separation_ticks: int = 10 ** 9
    n_decoys: int = 0                  # empty buildings reserved for decoys/replacement
    spread: dict | None = None
    spread_radius_ticks: float = 4.0   # spread reach in travel-ticks (scaled to speed)
    coordinate_offset_max: float = 0.0
    time_offset_max: int = 0            # public occurred_at drifts +/- up to this many ticks


def _band_predicate(band: str) -> Callable[[int], bool]:
    return {
        "high": lambda o: o >= 30,
        "medium": lambda o: 10 <= o < 30,
        "low": lambda o: 1 <= o < 10,
        "empty": lambda o: o == 0,
        "any": lambda o: True,
    }[band]


# Order candidates so the "most representative" building of a band is preferred
# first: crowded bands prefer the most crowded building, so selection lands on the
# same relative building across maps with parallel occupancy profiles.
def _band_order(band: str):
    if band in ("high", "medium"):
        return lambda b: (-b.occupants, b.building_id)
    if band == "low":
        return lambda b: (b.occupants, b.building_id)
    return lambda b: (b.building_id,)


def _travel_ticks(map_: Map, a_id: str, b_id: str, speed: float) -> int:
    import math

    route = map_.route(map_.building_to_coords(a_id), map_.building_to_coords(b_id))
    return max(1, math.ceil(route.total / speed))


def _derived_speed(tmpl: Template, map_: Map) -> float:
    """Truck speed so the map's farthest occupied building is ~reach_ticks from the
    map centre. Rounded to one decimal so the emitted scenario is stable."""
    center = map_.snap(map_.center)
    far = 0.0
    for b in map_.buildings.values():
        if b.occupants > 0:
            far = max(far, map_.route(center, b.point).total)
    speed = far / max(1, tmpl.reach_ticks)
    return round(max(speed, 1.0), 1)


def _select_fire_buildings(tmpl: Template, map_: Map, speed: float) -> dict[str, str]:
    """Assign each FireSpec a concrete building satisfying occupancy and pairwise
    travel-time separation. Deterministic backtracking over ordered candidates."""
    buildings = sorted(map_.buildings.values(), key=lambda b: b.building_id)
    order = list(tmpl.fires)

    def candidates(spec: FireSpec, used: set[str]) -> list[str]:
        pred = _band_predicate(spec.occupancy)
        elig = [b for b in buildings if pred(b.occupants) and b.building_id not in used]
        elig.sort(key=_band_order(spec.occupancy))
        return [b.building_id for b in elig]

    chosen: dict[str, str] = {}

    def ok_separation(new_id: str) -> bool:
        for other in chosen.values():
            tt = _travel_ticks(map_, new_id, other, speed)
            if tt < tmpl.min_separation_ticks or tt > tmpl.max_separation_ticks:
                return False
        return True

    def recurse(i: int) -> bool:
        if i == len(order):
            return True
        spec = order[i]
        for bid in candidates(spec, set(chosen.values())):
            if ok_separation(bid):
                chosen[spec.key] = bid
                if recurse(i + 1):
                    return True
                del chosen[spec.key]
        return False

    if not recurse(0):
        raise BindError(
            f"template {tmpl.template_id!r} cannot place {len(order)} fires on map "
            f"{map_.map_id!r} within separation [{tmpl.min_separation_ticks}, "
            f"{tmpl.max_separation_ticks}] ticks and the requested occupancy bands")
    return chosen


def _select_decoys(tmpl: Template, map_: Map, fire_ids: set[str], speed: float) -> list[str]:
    """Reserve empty decoy buildings far from the real fires, seeded and stable.

    A decoy that is far from every fire makes a wasted trip to a false alarm or a
    wrong address expensive: the misdirected truck starts any later, correct
    dispatch from a bad position, so the wasted work reliably costs a collapse
    instead of being cheaply recovered."""
    empties = sorted(b.building_id for b in map_.buildings.values()
                     if b.occupants == 0 and b.building_id not in fire_ids)
    if len(empties) < tmpl.n_decoys:
        raise BindError(
            f"template {tmpl.template_id!r} needs {tmpl.n_decoys} empty decoy "
            f"buildings on map {map_.map_id!r} but only {len(empties)} are free")

    def min_fire_ticks(bid: str) -> int:
        if not fire_ids:
            return 0
        return min(_travel_ticks(map_, bid, f, speed) for f in sorted(fire_ids))

    # Farthest-from-fires first; stable tie-break by building_id.
    ranked = sorted(empties, key=lambda b: (-min_fire_ticks(b), b))
    return ranked[:tmpl.n_decoys]


def _claim(spec: ContactSpec, headcount_value: int | None) -> dict:
    claim: dict = {"incident_type": spec.incident_type}
    if spec.severity is not None:
        claim["severity"] = {"value": spec.severity, "confidence": spec.severity_conf}
    if headcount_value is not None:
        claim["headcount"] = {"value": headcount_value, "qualifier": spec.headcount_qualifier,
                              "confidence": spec.headcount_conf}
    if spec.source_reliability is not None:
        claim["source_reliability"] = spec.source_reliability
    if spec.evidence:
        claim["evidence"] = list(spec.evidence)
    if spec.negations:
        claim["negations"] = list(spec.negations)
    if spec.payload_type == "human_text":
        claim["language_plan"] = {"tone": spec.tone,
                                  "detail_order": list(spec.detail_order),
                                  "disfluency": spec.disfluency}
    return claim


def _reported_location(spec: ContactSpec, fire_building: str | None,
                       decoy_building: str | None, map_: Map) -> dict:
    if spec.location == "coordinate":
        bid = fire_building or decoy_building
        assert bid is not None  # a coordinate contact resolves to a fire or decoy building
        p = map_.building_to_coords(bid)
        return {"kind": "coordinates", "coordinates": {"x": round(p.x, 1), "y": round(p.y, 1)}}
    bid = decoy_building if spec.location == "decoy_building" else fire_building
    if bid is None:
        bid = decoy_building
    return {"kind": "building_id", "building_id": bid}


def _spread_settings(tmpl: Template, speed: float) -> dict:
    if not tmpl.spread:
        return {"enabled": False}
    s = dict(tmpl.spread)
    # Scale spread reach to travel-ticks so it is comparable across map scales.
    s["radius"] = round(speed * tmpl.spread_radius_ticks, 1)
    return s


def bind(tmpl: Template, map_: Map) -> dict:
    """Instantiate ``tmpl`` against ``map_`` into a validated scenario dict."""
    speed = _derived_speed(tmpl, map_)
    fire_bids = _select_fire_buildings(tmpl, map_, speed)
    used = set(fire_bids.values())
    decoys = _select_decoys(tmpl, map_, used, speed)
    # Stable per-contact decoy assignment, round-robin over the reserved empties so a
    # template may raise more false calls than there are decoy buildings (repeated or
    # conflicting reports about the same non-fire spot). The first n_decoys decoy
    # contacts still map 1:1 in declaration order, so single-decoy stages are unchanged.
    decoy_contacts = [
        s.key for s in tmpl.contacts
        if s.location == "decoy_building" or (s.fire_key is None and s.location != "coordinate")
    ]
    contact_decoy: dict[str, str] = {
        k: decoys[i % len(decoys)] for i, k in enumerate(decoy_contacts)
    }

    scenario_id = f"{tmpl.template_id}{ID_SEP}{map_.map_id}"

    initial_fires, scheduled = [], []
    for spec in tmpl.fires:
        bid = fire_bids[spec.key]
        if spec.ignition_tick <= 0:
            initial_fires.append({"fire_id": f"fire-{spec.key}", "building_id": bid,
                                  "intensity": spec.intensity, "growth_rate": spec.growth_rate})
        else:
            scheduled.append({"event_id": f"ign-{spec.key}", "tick": spec.ignition_tick,
                              "building_id": bid, "intensity": spec.intensity,
                              "growth_rate": spec.growth_rate})

    human_contacts = []
    replacement_candidates: set[str] = set()
    for spec in tmpl.contacts:
        fire_b = fire_bids.get(spec.fire_key) if spec.fire_key else None
        decoy_b = contact_decoy.get(spec.key)
        ign = 0
        if spec.fire_key is not None:
            ign = next(f.ignition_tick for f in tmpl.fires if f.key == spec.fire_key)
        occurred = max(0, ign + spec.occurred_offset)
        delivered = max(occurred, ign + spec.delivered_offset)
        loc = _reported_location(spec, fire_b, decoy_b, map_)
        headcount_value: int | None = spec.headcount if isinstance(spec.headcount, int) else None
        if spec.headcount == "auto":
            # A truthful headcount for this fire's real occupants, so a people-first
            # policy's priority tracks the actual casualty stakes.
            headcount_value = map_.buildings[fire_b].occupants if fire_b else 0
        claim = _claim(spec, headcount_value)
        if spec.with_event_time:
            claim["event_time"] = {"tick": occurred, "confidence": 0.8}
        contact = {
            "contact_id": spec.key,
            "source_type": spec.source_type,
            "occurred_at": occurred,
            "delivered_at": delivered,
            "reported_location": loc,
            "payload_type": spec.payload_type,
            "claim": claim,
        }
        if spec.location_perturbation != "none":
            contact["location_perturbation"] = spec.location_perturbation
            if spec.location_perturbation == "building_replacement":
                # Replacement draws from the sorted candidate set; include the true
                # fire building and reserved decoys so the perturbed report is a
                # plausible wrong building.
                replacement_candidates.update(decoys)
                if fire_b:
                    replacement_candidates.add(fire_b)
        if spec.time_perturbation != "none":
            contact["time_perturbation"] = spec.time_perturbation
        human_contacts.append(contact)

    scenario = {
        "schema_version": 1,
        "scenario_id": scenario_id,
        "title": tmpl.title,
        "public_description": tmpl.public_description,
        "difficulty_stage": tmpl.difficulty_stage,
        "map_id": map_.map_id,
        "tick_limit": tmpl.tick_limit,
        "display_policy": tmpl.display_policy,
        "default_seed": tmpl.default_seed,
        "settings": {
            "truck_speed": speed,
            "suppression_rate": tmpl.suppression_rate,
            "suppression_radius": tmpl.suppression_radius,
            "truck_vision_radius": tmpl.truck_vision_radius,
            "spread": _spread_settings(tmpl, speed),
            "location_perturbation": {
                "coordinate_offset_max": tmpl.coordinate_offset_max,
                "building_candidates": sorted(replacement_candidates),
            },
            "time_perturbation": {"max_offset_ticks": tmpl.time_offset_max},
        },
        "vehicles": [{"vehicle_id": f"truck-{i + 1}", "label": f"Truck {i + 1}"}
                     for i in range(tmpl.vehicle_count)],
        "truth": {"initial_fires": initial_fires, "scheduled_ignitions": scheduled},
        "human_contacts": human_contacts,
    }

    # Validate through the runtime loader so a template can never emit an artifact
    # the engine would reject at startup.
    try:
        load_scenario(scenario, map_)
    except Exception as exc:
        raise BindError(f"template {tmpl.template_id!r} produced an invalid scenario "
                        f"for map {map_.map_id!r}: {exc}") from exc
    return scenario


def bind_all(maps: list[str] | None = None) -> dict[str, dict]:
    """Bind every template against every packaged map. Returns {scenario_id: dict}."""
    from ..maps import import_map

    map_ids = maps if maps is not None else sorted(import_map.packaged_map_ids())
    out: dict[str, dict] = {}
    for map_id in map_ids:
        map_ = Map.load(map_id)
        for tmpl in TEMPLATES:
            scenario = bind(tmpl, map_)
            out[scenario["scenario_id"]] = scenario
    return out


def default_out_dir() -> Path:
    # Resolve the packaged data dir on the real filesystem (not a MultiplexedPath),
    # so a regen writes back into the source tree that is committed.
    return Path(__file__).resolve().parent.parent / "data" / "scenarios"


def write_all(out_dir: Path | None = None) -> list[str]:
    """Regenerate every packaged scenario JSON (replacing prior binder output).

    Deletes existing ``*.json`` in the target directory (all committed scenarios are
    binder output) and writes one pretty-printed file per (template, map). Returns
    the scenario_ids written, sorted."""
    out_dir = out_dir or default_out_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    for stale in out_dir.glob("*.json"):
        stale.unlink()
    scenarios = bind_all()
    for sid in sorted(scenarios):
        (out_dir / f"{sid}.json").write_text(
            json.dumps(scenarios[sid], indent=2, ensure_ascii=True) + "\n")
    return sorted(scenarios)


from .templates import TEMPLATES  # noqa: E402  (avoid a circular import at module top)
