"""The five packaged stage templates (GAME.md stages 1-5).

Each is a map-agnostic recipe. Numbers here are the tuned knobs the acceptance
harness (tests/acceptance) drives the greedy baseline and the good-policy oracle
against; see spec/ASSUMPTIONS.md for the tuning record. Occupancy is requested by
band, and the three packaged maps carry parallel occupancy profiles, so a band
lands on the same relative building on every map, keeping the lesson stable while
travel geometry varies.
"""
from __future__ import annotations

from .binder import ContactSpec, FireSpec, Template

# Shared physics. Truck speed is derived per map (see binder.reach_ticks) so a
# direct dispatch reaches any fire in ~reach_ticks and saves it, but a detour or
# misprioritization costs a collapse; short fuses make wasted work fatal.
# Suppression is deliberately slow (net -(12-7)=-5/tick) so a truck that reaches a
# real fire stays committed to it for the rest of the episode: it never finishes
# one fire and "swings"/"frees up" to rescue a deprioritized fire before that fire
# collapses (~tick 10). A directly dispatched truck still arrives (<=reach+1 ticks)
# while intensity is well under 100 and saves its fire. So the fire that is lost is
# a function of which one you never committed a truck to - i.e. of prioritization
# and reconciliation - not of map geometry.
_SUPP_RATE = 12.0
_SUPP_RADIUS = 35.0
_VISION = 80.0
_INTENSITY = 35.0        # fuse = (100 - intensity) / growth ~= 9-10 ticks unattended
_GROWTH = 7.0
_TICK_LIMIT = 100        # generous ceiling; every scenario resolves early (see terminal logic)
_REACH = 6               # farthest fire ~6 ticks from centre after speed scaling
_SEP_MIN = 4             # min pairwise fire travel-time separation (ticks)


def _fire(key, occ, sev_growth=_GROWTH, intensity=_INTENSITY, ignition=0):
    return FireSpec(key=key, occupancy=occ, intensity=intensity,
                    growth_rate=sev_growth, ignition_tick=ignition)


STAGE1 = Template(
    template_id="stage1-basic",
    title="Structured reports from the call centre",
    public_description=("The call centre hands you clean, structured reports. Two engines "
                        "are on the board and the shift is yours to run."),
    difficulty_stage=1,
    tick_limit=_TICK_LIMIT,
    display_policy="full_state",
    default_seed=51001,
    binder_seed=1001,
    suppression_rate=_SUPP_RATE, suppression_radius=_SUPP_RADIUS,
    truck_vision_radius=_VISION, reach_ticks=_REACH,
    vehicle_count=2,
    min_separation_ticks=_SEP_MIN,
    fires=(
        _fire("A", "medium"),   # 12-ish occupants, claimed HIGH severity
        _fire("B", "low"),      # 5-8 occupants, claimed HIGH severity
        _fire("C", "high"),     # 40 occupants, claimed only MEDIUM severity
    ),
    contacts=(
        ContactSpec("contact-A", "direct_call", "fire", 0, 1, fire_key="A",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="high",
                    evidence=("flames",)),
        ContactSpec("contact-B", "direct_call", "fire", 0, 1, fire_key="B",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="high",
                    evidence=("flames", "shouting")),
        ContactSpec("contact-C", "direct_call", "fire", 0, 1, fire_key="C",
                    severity="medium", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="confirmed_trapped", source_reliability="high",
                    evidence=("smoke",)),
    ),
)


STAGE2 = Template(
    template_id="stage2-language",
    title="Calls from the public",
    public_description=("The calls arrive as people speak them: free text, in their own "
                        "words. Read what each caller actually claims."),
    difficulty_stage=2,
    tick_limit=_TICK_LIMIT,
    display_policy="full_state",
    default_seed=52002,
    binder_seed=2002,
    suppression_rate=_SUPP_RATE, suppression_radius=_SUPP_RADIUS,
    truck_vision_radius=_VISION, reach_ticks=_REACH,
    vehicle_count=2,
    min_separation_ticks=_SEP_MIN,
    n_decoys=2,
    fires=(
        _fire("A", "medium"),   # ~26 occupants, claimed HIGH severity
        _fire("B", "low"),      # ~5 occupants, claimed HIGH severity
        _fire("C", "high"),     # 40 occupants, claimed only MEDIUM severity
    ),
    contacts=(
        # Loud false alarm, delivered first, claimed high severity -> a naive
        # dispatch-on-smoke burns a truck on it while three real fires compete; a
        # good policy reads bbq smoke + source and drops it.
        ContactSpec("contact-fa", "false_alarm_report", "unknown", 0, 1,
                    severity="high", severity_conf=0.6, source_reliability="medium",
                    evidence=("bbq_smoke", "heavy_smoke"), tone="panicked", disfluency="light",
                    detail_order=("location", "evidence", "severity"),
                    payload_type="human_text", location="decoy_building"),
        ContactSpec("contact-A", "direct_call", "fire", 0, 1, fire_key="A",
                    severity="high", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames", "heavy_smoke"), tone="urgent", with_event_time=True,
                    detail_order=("location", "incident_type", "evidence", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-B", "direct_call", "fire", 0, 1, fire_key="B",
                    severity="high", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames", "shouting"), tone="urgent",
                    detail_order=("location", "incident_type", "evidence", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-C", "direct_call", "fire", 0, 1, fire_key="C",
                    severity="medium", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="confirmed_trapped", source_reliability="medium",
                    evidence=("smoke",), tone="neutral", with_event_time=True,
                    detail_order=("location", "incident_type", "evidence", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-rh", "red_herring_call", "none", 0, 2,
                    source_reliability="medium", evidence=("cat_in_tree",), tone="neutral",
                    detail_order=("location", "incident_type", "evidence"),
                    payload_type="human_text", location="decoy_building"),
    ),
)


STAGE3 = Template(
    template_id="stage3-partial",
    title="Radio, alarms, and passers-by",
    public_description=("Reports reach the desk from automatic alarms and from people who "
                        "happened to be nearby. You see only what is reported."),
    difficulty_stage=3,
    tick_limit=_TICK_LIMIT,
    display_policy="public_only",
    default_seed=53003,
    binder_seed=3003,
    suppression_rate=_SUPP_RATE, suppression_radius=_SUPP_RADIUS,
    truck_vision_radius=_VISION, reach_ticks=_REACH,
    vehicle_count=2,
    min_separation_ticks=_SEP_MIN,
    n_decoys=2,
    fires=(
        _fire("A", "high"),     # 40 occupants; reported twice (alarm + call)
        _fire("B", "medium"),   # ~18 occupants; one delayed call
    ),
    contacts=(
        # Duplicate pair on fire A: an alarm and a smoke call for the same block.
        ContactSpec("contact-A1", "automatic_alarm", "unknown", 0, 1, fire_key="A",
                    source_reliability="high", evidence=("alarm",), tone="flat",
                    detail_order=("location", "evidence"),
                    payload_type="human_text"),
        ContactSpec("contact-A2", "direct_call", "fire", 0, 2, fire_key="A",
                    severity="high", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("heavy_smoke", "flames"), tone="urgent", with_event_time=True,
                    detail_order=("location", "incident_type", "evidence", "severity"),
                    payload_type="human_text"),
        # Wrong address: a caller names the wrong building (replacement perturbation).
        ContactSpec("contact-wrong", "direct_call", "fire", 0, 1, fire_key="A",
                    severity="high", severity_conf=0.6, source_reliability="low",
                    evidence=("smoke",), tone="panicked", disfluency="light",
                    detail_order=("location", "evidence"),
                    payload_type="human_text", location_perturbation="building_replacement"),
        # Incomplete call: something is wrong somewhere, no usable detail.
        ContactSpec("contact-inc", "incomplete_call", "unknown", 0, 2,
                    source_reliability="low", tone="terse",
                    detail_order=("location", "incident_type"),
                    payload_type="human_text", location="decoy_building"),
        # Delayed second fire: reported minutes after it started.
        ContactSpec("contact-B", "direct_call", "fire", 0, 4, fire_key="B",
                    severity="high", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames", "burning_smell"), tone="urgent", with_event_time=True,
                    detail_order=("location", "incident_type", "evidence", "severity"),
                    payload_type="human_text"),
    ),
)


STAGE4 = Template(
    template_id="stage4-replan",
    title="Updates from the field",
    public_description=("Crews on scene report back while the shift is still running. The "
                        "board changes under you."),
    difficulty_stage=4,
    tick_limit=_TICK_LIMIT,
    display_policy="public_only",
    default_seed=54004,
    binder_seed=4004,
    # Even slower suppression here (net -(10-7)=-3/tick): once a truck is on one of
    # the two initial fires it stays committed for the rest of the episode, so a
    # never-redirect baseline can NEVER free a truck to cover the big late fire C.
    # A good policy redirects a committed truck the moment C is reported and saves
    # it (C's low growth gives ample time), sacrificing only the small fire it left.
    suppression_rate=10.0, suppression_radius=_SUPP_RADIUS,
    truck_vision_radius=_VISION, reach_ticks=_REACH,
    vehicle_count=2,
    min_separation_ticks=_SEP_MIN,
    fires=(
        _fire("A", "low"),                                   # ~8 occupants
        _fire("D", "medium"),                                # ~26 occupants
        _fire("C", "high", sev_growth=4.0, ignition=3),      # 40 occupants, big late fire
    ),
    contacts=(
        ContactSpec("contact-A", "direct_call", "fire", 0, 1, fire_key="A",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames",), tone="urgent",
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-D", "direct_call", "fire", 0, 1, fire_key="D",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames", "sparks"), tone="urgent",
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text"),
        # Contradiction on fire A: everyone out vs two still inside (kept, not resolved).
        ContactSpec("contact-A-out", "responder_update", "fire", 1, 2, fire_key="A",
                    severity="medium", severity_conf=0.8, headcount=0,
                    headcount_qualifier="all_out", source_reliability="high",
                    negations=("casualties",), tone="flat",
                    detail_order=("location", "incident_type", "headcount"),
                    payload_type="human_text"),
        # Big late fire near the committed trucks; a responder flags it larger than first thought.
        ContactSpec("contact-C", "responder_update", "fire", 0, 1, fire_key="C",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="confirmed_trapped", source_reliability="high",
                    evidence=("flames", "heavy_smoke"), tone="urgent", with_event_time=True,
                    detail_order=("location", "incident_type", "severity", "headcount"),
                    payload_type="human_text"),
    ),
)


STAGE5 = Template(
    template_id="stage5-triage",
    title="A wall of calls",
    public_description=("A heavy shift across the district: calls arrive faster than the "
                        "fleet can clear them."),
    difficulty_stage=5,
    tick_limit=_TICK_LIMIT,
    display_policy="public_only",
    default_seed=55005,
    binder_seed=5005,
    suppression_rate=_SUPP_RATE, suppression_radius=_SUPP_RADIUS,
    truck_vision_radius=_VISION, reach_ticks=_REACH,
    vehicle_count=2,
    min_separation_ticks=_SEP_MIN,
    n_decoys=3,
    time_offset_max=2,   # callers misremember the fire's start by up to +/- 2 ticks
    # Same trap as stage 1, sharpened and buried in noise: the crowded fire C is only
    # claimed medium severity, so a severity-first baseline leaves it, and C climbs
    # from 40 at +9/tick to collapse (100) in ~7 ticks - too fast for the baseline to
    # free a truck in time. Louder false alarms, a wrong-address call, and misremembered
    # timings pad the queue; a people-first policy that dedupes and drops benign smoke
    # still covers C early and saves the block. (Fire spread is dropped - see spec/TODO.md.)
    fires=(
        _fire("A", "medium"),                                    # claimed HIGH severity
        _fire("B", "low", sev_growth=0.0, intensity=30.0),       # smoulders; stays put
        _fire("C", "high", sev_growth=9.0, intensity=40.0),      # crowded, only MEDIUM claim
    ),
    contacts=(
        ContactSpec("contact-A", "direct_call", "fire", 0, 2, fire_key="A",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="high",
                    evidence=("flames", "heavy_smoke"), tone="urgent", with_event_time=True,
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        ContactSpec("contact-B", "direct_call", "fire", 0, 1, fire_key="B",
                    severity="high", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("flames",), tone="urgent",
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text"),
        # The crowded fire: called in fast (no delay) so it stays winnable, and
        # corroborated by a second, slightly-later caller who misremembers the time.
        ContactSpec("contact-C", "direct_call", "fire", 0, 1, fire_key="C",
                    severity="medium", severity_conf=0.8, headcount="auto",
                    headcount_qualifier="confirmed_trapped", source_reliability="high",
                    evidence=("smoke",), tone="neutral",
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-C2", "direct_call", "fire", 0, 3, fire_key="C",
                    severity="medium", severity_conf=0.7, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("heavy_smoke", "shouting"), tone="panicked", disfluency="light",
                    with_event_time=True,
                    detail_order=("incident_type", "location", "evidence"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        # Wrong address: a caller reports fire A at the wrong building. No headcount and
        # low reliability keep it below the real fires in a people-first ranking, but a
        # severity-first baseline can still chase it.
        ContactSpec("contact-wrong", "direct_call", "fire", 0, 2, fire_key="A",
                    severity="high", severity_conf=0.6, source_reliability="low",
                    evidence=("smoke",), tone="panicked", disfluency="light", with_event_time=True,
                    detail_order=("location", "evidence"),
                    payload_type="human_text", location_perturbation="building_replacement",
                    time_perturbation="tick_offset"),
        # Loud benign false alarm, delivered early: baits a dispatch-on-severity baseline.
        ContactSpec("contact-fa1", "false_alarm_report", "unknown", 0, 1,
                    severity="high", severity_conf=0.6, source_reliability="medium",
                    evidence=("bbq_smoke", "heavy_smoke"), tone="panicked", disfluency="light",
                    detail_order=("location", "evidence", "severity"),
                    payload_type="human_text", location="decoy_building"),
        # A second false alarm, delayed, with a misremembered time.
        ContactSpec("contact-fa2", "false_alarm_report", "unknown", 0, 3,
                    severity="medium", severity_conf=0.5, source_reliability="low",
                    evidence=("burnt_toast", "light_smoke"), tone="neutral",
                    detail_order=("location", "evidence"), with_event_time=True,
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        # Cat in a tree: no incident at all.
        ContactSpec("contact-rh", "red_herring_call", "none", 0, 2,
                    source_reliability="medium", evidence=("cat_in_tree",), tone="neutral",
                    detail_order=("location", "incident_type", "evidence"),
                    payload_type="human_text", location="decoy_building"),

        # ---- Sustained call pressure: 7 more calls corroborating or conflicting on the
        # three real fires, spread over ticks 4-27, meant to bury the signal. Locations
        # are the true fire buildings, so a policy that dedupes by location folds them in;
        # the confusion is in conflicting severity/time/headcount and mixed channels.
        ContactSpec("contact-A2", "automatic_alarm", "fire", 0, 5, fire_key="A",
                    severity="high", severity_conf=0.9, source_reliability="high",
                    evidence=("alarm",), tone="flat",
                    detail_order=("location", "incident_type"), payload_type="human_text"),
        ContactSpec("contact-B2", "panicked_call", "fire", 0, 6, fire_key="B",
                    severity="high", severity_conf=0.7, headcount="auto",
                    headcount_qualifier="possibly_trapped", source_reliability="medium",
                    evidence=("heavy_smoke", "shouting"), tone="panicked", disfluency="light",
                    detail_order=("location", "severity", "evidence"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        ContactSpec("contact-C3", "responder_update", "fire", 0, 8, fire_key="C",
                    severity="high", severity_conf=0.9, headcount="auto",
                    headcount_qualifier="confirmed_trapped", source_reliability="high",
                    evidence=("flames", "shouting"), tone="flat",
                    detail_order=("location", "incident_type", "severity"),
                    payload_type="human_text"),
        ContactSpec("contact-A3", "direct_call", "fire", 0, 12, fire_key="A",
                    severity="medium", severity_conf=0.5, source_reliability="medium",
                    evidence=("smoke",), tone="neutral", detail_order=("location", "evidence"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        ContactSpec("contact-C4", "direct_call", "fire", 0, 18, fire_key="C",
                    severity="high", severity_conf=0.6, headcount=3, headcount_qualifier="all_out",
                    headcount_conf=0.4, source_reliability="low", evidence=("light_smoke",),
                    tone="terse", detail_order=("location", "severity"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        ContactSpec("contact-B3", "incomplete_call", "unknown", 0, 22, fire_key="B",
                    source_reliability="low", evidence=("burning_smell",), tone="panicked",
                    disfluency="heavy", detail_order=("location", "evidence"),
                    payload_type="human_text", time_perturbation="tick_offset"),
        ContactSpec("contact-A4", "automatic_alarm", "fire", 0, 27, fire_key="A",
                    severity="high", severity_conf=0.9, source_reliability="high",
                    evidence=("alarm",), tone="flat",
                    detail_order=("location", "incident_type"), payload_type="human_text"),

        # ---- 9 more noise calls on empty decoy buildings, spread over ticks 4-30. The
        # false alarms and red herrings good policy drops on evidence/incident type; the
        # two false-FIRE calls (n4, n7) carry no headcount and only low severity, so a
        # people-first priority keeps them below every real fire while the greedy baseline
        # still chases them. Round-robin decoy assignment clusters these on the reserved
        # empties, so a decoy fields several conflicting reports.
        ContactSpec("contact-n1", "false_alarm_report", "unknown", 4, 4,
                    severity="high", severity_conf=0.6, source_reliability="medium",
                    evidence=("bbq_smoke", "heavy_smoke"), tone="panicked", disfluency="light",
                    detail_order=("location", "evidence", "severity"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n2", "red_herring_call", "none", 7, 7,
                    source_reliability="medium", evidence=("noise_complaint",), tone="neutral",
                    detail_order=("location", "incident_type", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n3", "false_alarm_report", "unknown", 10, 10,
                    severity="medium", severity_conf=0.5, source_reliability="low",
                    evidence=("burnt_toast",), tone="neutral", disfluency="light",
                    detail_order=("location", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n4", "panicked_call", "fire", 13, 13,
                    severity="low", severity_conf=0.6, source_reliability="low",
                    evidence=("smoke", "shouting"), tone="panicked", disfluency="light",
                    detail_order=("location", "evidence", "severity"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n5", "red_herring_call", "none", 16, 16,
                    source_reliability="medium", evidence=("lockout",), tone="neutral",
                    detail_order=("location", "incident_type", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n6", "false_alarm_report", "unknown", 19, 19,
                    severity="medium", severity_conf=0.5, source_reliability="low",
                    evidence=("steam",), tone="flat", detail_order=("location", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n7", "direct_call", "fire", 24, 24,
                    severity="low", severity_conf=0.5, source_reliability="low",
                    evidence=("burning_smell",), tone="neutral",
                    detail_order=("location", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n8", "red_herring_call", "none", 28, 28,
                    source_reliability="low", evidence=("water_leak",), tone="neutral",
                    detail_order=("location", "incident_type", "evidence"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
        ContactSpec("contact-n9", "false_alarm_report", "unknown", 30, 30,
                    severity="low", severity_conf=0.5, source_reliability="low",
                    evidence=("dust", "light_smoke"), tone="neutral", disfluency="light",
                    detail_order=("location", "evidence", "severity"),
                    payload_type="human_text", location="decoy_building",
                    time_perturbation="tick_offset"),
    ),
)


TEMPLATES = (STAGE1, STAGE2, STAGE3, STAGE4, STAGE5)
