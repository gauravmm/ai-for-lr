"""hadr-engine command-line entry point."""
from __future__ import annotations

import argparse
import sys

from . import __version__
from .maps.import_map import ValidationError, import_map, validate_packaged_data

_HOST = "127.0.0.1"  # loopback only: no remote-serving or bearer-token option
_DEFAULT_PORT = 8000


def _cmd_import_map(args: argparse.Namespace) -> int:
    try:
        dest = import_map(args.source_json, args.source_svg, args.manifest, args.out_dir)
    except ValidationError as exc:
        print("import-map failed:", file=sys.stderr)
        for problem in exc.problems:
            print(f"  - {problem}", file=sys.stderr)
        return 1
    print(f"wrote {dest}")
    return 0


def _cmd_validate_data(_args: argparse.Namespace) -> int:
    report = validate_packaged_data()
    if not report:
        print("no packaged maps found")
        return 1
    ok = True
    for map_id in sorted(report):
        problems = report[map_id]
        if problems:
            ok = False
            print(f"{map_id}: FAIL")
            for problem in problems:
                print(f"  - {problem}")
        else:
            print(f"{map_id}: ok")
    return 0 if ok else 1


def _cmd_serve(args: argparse.Namespace) -> int:
    if args.workers != 1:
        print("serve: exactly one ASGI worker is supported (the in-process lease and "
              "run-log boundary are not shareable); requested workers must be 1",
              file=sys.stderr)
        return 2

    import uvicorn

    from .app import DataInvalidError, create_app
    from .persistence import runlog
    from .transports import mcp

    idle = args.idle_timeout if args.idle_timeout is not None else mcp.DEFAULT_IDLE_TIMEOUT
    try:
        app = create_app(idle_timeout=idle)
    except DataInvalidError as exc:
        print(f"serve: {exc}", file=sys.stderr)
        return 1

    base = f"http://{_HOST}:{args.port}"
    print(f"hadr-engine {__version__} serving (loopback only)")
    print(f"  display:   {base}/")
    print(f"  MCP:       {base}/mcp")
    print(f"  state dir: {runlog.state_dir()}")
    # The display UI polls /api/v1/snapshot every tick; drop its access-log spam.
    import logging
    logging.getLogger("uvicorn.access").addFilter(
        lambda record: "/api/v1/snapshot" not in record.getMessage())
    uvicorn.run(app, host=_HOST, port=args.port, log_level="info")
    return 0


def _cmd_gen_datasets(args: argparse.Namespace) -> int:
    from pathlib import Path

    from . import datasets

    out = Path(args.out)
    manifest = datasets.generate(out, include_labels=args.include_labels)
    counts = ", ".join(f"{k} {v}" for k, v in sorted(manifest["counts"].items()))
    print(f"wrote datasets to {out} (seed {manifest['dataset_seed']}, {counts})")
    return 0


def _cmd_bind_scenarios(args: argparse.Namespace) -> int:
    from pathlib import Path

    from .scenariogen import binder

    out = Path(args.out) if args.out else None
    try:
        written = binder.write_all(out)
    except binder.BindError as exc:
        print(f"bind-scenarios failed: {exc}", file=sys.stderr)
        return 1
    dest = out or binder.default_out_dir()
    print(f"wrote {len(written)} scenarios to {dest}")
    for sid in written:
        print(f"  - {sid}")
    return 0


def _cmd_run_baseline(args: argparse.Namespace) -> int:
    from .domain import baseline

    res = baseline.run_baseline(args.scenario_id, seed=args.seed)
    print(f"scenario:      {res.scenario_id}")
    print(f"seed:          {res.seed}")
    print(f"terminal:      {res.terminal_reason} at tick {res.ticks}")
    print(f"casualties:    {res.casualties}")
    print(f"buildings_lost:{res.buildings_lost}")
    print(f"trace_hash:    {res.trace_hash}")
    return 0


def _cmd_verify_run(args: argparse.Namespace) -> int:
    from .persistence import verify

    try:
        report = verify.verify_run(args.path)
    except (FileNotFoundError, ValueError) as exc:
        print(f"verify-run: {exc}", file=sys.stderr)
        return 1
    if report.ok:
        print(f"verify-run: OK ({report.scenario_id}, seed {report.seed}, "
              f"{report.commands} effective commands)")
        print(f"  trace_hash: {report.recorded_hash}")
        return 0
    print("verify-run: MISMATCH", file=sys.stderr)
    print(f"  recorded: {report.recorded_hash}", file=sys.stderr)
    print(f"  replayed: {report.replayed_hash}", file=sys.stderr)
    for detail in report.diff[:20]:
        print(f"  - {detail}", file=sys.stderr)
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hadr-engine")
    parser.add_argument("--version", action="version", version=f"hadr-engine {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_import = sub.add_parser(
        "import-map", help="validate a source map/manifest and write packaged data"
    )
    p_import.add_argument("source_json")
    p_import.add_argument("source_svg")
    p_import.add_argument("manifest")
    p_import.add_argument("out_dir")
    p_import.set_defaults(func=_cmd_import_map)

    p_validate = sub.add_parser("validate-data", help="validate every packaged map")
    p_validate.set_defaults(func=_cmd_validate_data)

    p_gen = sub.add_parser("gen-datasets",
                           help="generate the deterministic intake datasets under datasets/")
    p_gen.add_argument("--out", default="datasets",
                       help="output directory for the generated datasets (default: datasets)")
    p_gen.add_argument("--include-labels", action="store_true",
                       help="also write the instructor labels, report schema, and example")
    p_gen.set_defaults(func=_cmd_gen_datasets)

    p_serve = sub.add_parser("serve", help="serve the MCP control surface and display on loopback")
    p_serve.add_argument("--port", type=int, default=_DEFAULT_PORT,
                         help=f"loopback port (default {_DEFAULT_PORT})")
    p_serve.add_argument("--workers", type=int, default=1,
                         help="ASGI workers; must be 1 (in-process lease is not shareable)")
    p_serve.add_argument("--idle-timeout", type=float, default=None,
                         help="MCP session inactivity abort backstop in seconds "
                              "(default: engine default; only ends abandoned sessions, "
                              "never resumes)")
    p_serve.set_defaults(func=_cmd_serve)

    p_bind = sub.add_parser("bind-scenarios",
                            help="regenerate all packaged scenarios from the stage templates")
    p_bind.add_argument("--out", default=None,
                        help="output directory (default: the packaged data/scenarios dir)")
    p_bind.set_defaults(func=_cmd_bind_scenarios)

    p_base = sub.add_parser(
        "run-baseline", help="run the greedy baseline headlessly and print outcome"
    )
    p_base.add_argument("scenario_id")
    p_base.add_argument("--seed", type=int, default=None,
                        help="effective seed (default: scenario default_seed)")
    p_base.set_defaults(func=_cmd_run_baseline)

    p_verify = sub.add_parser("verify-run",
                              help="rerun a run log's scenario/seed/commands and diff the trace")
    p_verify.add_argument("path")
    p_verify.set_defaults(func=_cmd_verify_run)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
