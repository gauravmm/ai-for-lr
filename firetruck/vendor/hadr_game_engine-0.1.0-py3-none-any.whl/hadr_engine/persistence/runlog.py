"""Append-only JSONL run log: the only persistence artifact (ENGINE.md, SCENARIOS.md).

One file per run under ${HADR_ENGINE_STATE_DIR:-${XDG_STATE_HOME:-~/.local/state}/hadr-engine}.
Records are canonical JSON (sorted keys, fixed numeric formatting). Buffered
appends, flush on the terminal record. A finalized log (terminal record present)
is immutable. On startup, any log lacking a terminal record is finalized as
`aborted: process_restart`; nothing resumes.

Record types:
- header  : run/scenario/map IDs, engine/api/schema/rng revisions, artifact
            hashes, effective settings, effective seed, wall-clock creation time.
- tick    : tick number + full post-tick state (hidden truth included), delivered
            contacts, observation/display projections, effective commands, events.
- command : one accepted/rejected/superseded dispatch with IDs, incident, rationale.
- terminal: terminal or abort reason, reveal (truth + canonical claims), outcomes.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from collections.abc import Iterable
from enum import Enum
from pathlib import Path
from typing import cast

_FLOAT_PLACES = 6

# Keys that are audit metadata, not part of the canonical simulation trace.
_TRACE_EXCLUDE = frozenset({
    "run_id", "observation_id", "controller_id", "created_at", "wall_clock", "path",
    "display_revision",
})


# --------------------------------------------------------------- json helpers

def to_jsonable(obj: object) -> object:
    """Recursively convert dataclasses/enums/tuples/points to plain JSON types."""
    if obj is None or isinstance(obj, (str, int, bool)):
        return obj
    if isinstance(obj, float):
        v = round(obj, _FLOAT_PLACES)
        return 0.0 if v == 0 else v
    if isinstance(obj, Enum):
        return obj.value
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_jsonable(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    # Fallback: string form keeps the log writable rather than crashing a mutation.
    return str(obj)


def canonical_dumps(obj: object) -> str:
    """Deterministic JSON string: sorted keys, fixed float formatting, no spaces."""
    return json.dumps(to_jsonable(obj), sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ------------------------------------------------------------- state directory

def state_dir() -> Path:
    override = os.environ.get("HADR_ENGINE_STATE_DIR")
    if override:
        base = Path(override)
    else:
        xdg = os.environ.get("XDG_STATE_HOME")
        base = (
            Path(xdg) / "hadr-engine" if xdg
            else Path.home() / ".local" / "state" / "hadr-engine"
        )
    base.mkdir(parents=True, exist_ok=True)
    return base


def _log_path(run_id: str) -> Path:
    return state_dir() / f"{run_id}.jsonl"


# ----------------------------------------------------------------- run log

class RunLog:
    """A single run's append-only JSONL file. Not thread-safe; the caller holds
    the GameService mutation lock."""

    def __init__(self, run_id: str, path: Path):
        self.run_id = run_id
        self.path = path
        self._fh = path.open("a", encoding="utf-8")
        self._finalized = False

    @classmethod
    def create(cls, run_id: str) -> RunLog:
        return cls(run_id, _log_path(run_id))

    def append(self, record: dict) -> None:
        if self._finalized:
            raise RuntimeError("cannot append to a finalized run log")
        self._fh.write(canonical_dumps(record) + "\n")

    def flush(self) -> None:
        self._fh.flush()
        os.fsync(self._fh.fileno())

    def finalize(self, terminal_record: dict) -> None:
        """Append the one terminal record and flush; the log is then immutable."""
        if self._finalized:
            raise RuntimeError("run log already finalized")
        self._fh.write(canonical_dumps(terminal_record) + "\n")
        self._finalized = True
        self.flush()
        self._fh.close()

    @property
    def finalized(self) -> bool:
        return self._finalized


# ------------------------------------------------------------- reading/verify

def read_records(path: str | Path) -> list[dict]:
    records = []
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line:
            records.append(json.loads(line))
    return records


def is_finalized(path: str | Path) -> bool:
    records = read_records(path)
    return bool(records) and records[-1].get("type") == "terminal"


def _strip_trace(obj: object) -> object:
    if isinstance(obj, dict):
        return {k: _strip_trace(v) for k, v in obj.items() if k not in _TRACE_EXCLUDE}
    if isinstance(obj, list):
        return [_strip_trace(v) for v in obj]
    return obj


def simulation_trace(records: Iterable[dict]) -> list[dict]:
    """The canonical simulation content: every record minus audit-only keys
    (run/controller/observation IDs, wall-clock, paths)."""
    # top-level records are dicts, so each stripped result is a dict
    return [cast(dict, _strip_trace(r)) for r in records]


def trace_hash(records: Iterable[dict]) -> str:
    return sha256_text(canonical_dumps(simulation_trace(list(records))))


# --------------------------------------------------------- restart finalize

def finalize_unfinalized_logs(reveal_builder=None) -> list[str]:
    """Finalize any log lacking a terminal record as `aborted: process_restart`.

    `reveal_builder(records) -> dict` may supply reveal/outcome fields from the
    last logged tick; when absent a minimal abort record is appended. Returns the
    run_ids that were finalized.
    """
    finalized: list[str] = []
    for path in sorted(state_dir().glob("*.jsonl")):
        try:
            records = read_records(path)
        except (OSError, ValueError):
            continue
        if not records or records[-1].get("type") == "terminal":
            continue
        run_id = path.stem
        record = {"type": "terminal", "run_id": run_id, "outcome": "aborted",
                  "abort_reason": "process_restart"}
        if reveal_builder is not None:
            extra = reveal_builder(records)
            if extra:
                record.update(extra)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(canonical_dumps(record) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        finalized.append(run_id)
    return finalized
