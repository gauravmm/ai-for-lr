"""verify-run: replay a run log and diff the canonical simulation trace.

A verifier reruns the simulation from the log's scenario, effective seed, and
effective commands, then compares the recomputed canonical trace hash against the
recorded one (SCENARIOS.md "Verification strategy"). The trace excludes
run/controller IDs and wall-clock metadata, so an honest rerun of the same
commands reproduces it byte for byte; any divergence (a tampered log) fails.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from . import runlog


@dataclass
class VerifyReport:
    ok: bool
    scenario_id: str
    seed: int
    commands: int
    recorded_hash: str
    replayed_hash: str
    diff: list[str] = field(default_factory=list)


def _schedule_from_records(records: list[dict]) -> dict[int, list]:
    """Map dispatch tick -> list of Dispatch. A tick record with tick T carries the
    commands applied during interval [T-1, T), i.e. dispatched at expected_tick T-1."""
    from ..domain.baseline import Dispatch
    from ..domain.model import Point

    schedule: dict[int, list] = {}
    for rec in records:
        if rec.get("type") != "tick":
            continue
        t = rec["tick"]
        if t == 0:
            continue
        dispatch_tick = t - 1
        for cmd in rec.get("effective_commands", []):
            dest = cmd["destination"]["requested"]
            schedule.setdefault(dispatch_tick, []).append(Dispatch(
                vehicle_id=cmd["vehicle_id"], incident_id=cmd["incident_id"],
                destination=Point(dest["x"], dest["y"]),
                rationale=cmd.get("rationale", "replay")))
    return schedule


def verify_run(path: str | Path) -> VerifyReport:
    from ..domain import baseline

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"run log not found: {path}")
    records = runlog.read_records(path)
    if not records or records[0].get("type") != "header":
        raise ValueError("run log has no header record")
    header = records[0]
    scenario_id = header["scenario_id"]
    seed = header["seed"]
    recorded_hash = runlog.trace_hash(records)

    schedule = _schedule_from_records(records)
    n_cmds = sum(len(v) for v in schedule.values())

    def policy(ctx):
        return list(schedule.get(ctx.tick, []))

    result = baseline.drive_policy(scenario_id, policy, seed=seed)
    ok = result.trace_hash == recorded_hash
    diff: list[str] = []
    if not ok:
        replay_records = runlog.read_records(runlog.state_dir() / f"{result.run_id}.jsonl")
        diff = _first_diffs(runlog.simulation_trace(records),
                            runlog.simulation_trace(replay_records))
    return VerifyReport(ok=ok, scenario_id=scenario_id, seed=seed, commands=n_cmds,
                        recorded_hash=recorded_hash, replayed_hash=result.trace_hash, diff=diff)


def _first_diffs(a: list, b: list, limit: int = 20) -> list[str]:
    out: list[str] = []
    if len(a) != len(b):
        out.append(f"record count differs: recorded {len(a)} vs replayed {len(b)}")
    for i, (ra, rb) in enumerate(zip(a, b, strict=False)):
        if ra != rb:
            ta = ra.get("type") if isinstance(ra, dict) else "?"
            out.append(f"record {i} ({ta}) differs")
            if len(out) >= limit:
                break
    return out
