// HADR read-only field display. Polls /api/v1/snapshot, renders the map, the
// report feed, and vehicle overlays. Never calls a gameplay endpoint. Untrusted
// strings are inserted with textContent / SVG text nodes only.
"use strict";

const SVGNS = "http://www.w3.org/2000/svg";
const POLL_MS = 1000;
const DISCONNECT_AFTER = 3;      // consecutive poll failures before dimming
const ANIM_MS = 10000;           // vehicle interpolation duration (~10s per update jump)
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// ---- iconography ----------------------------------------------------------
// Map-pin markers use Lucide icons (https://lucide.dev), ISC/MIT licensed.
// Inlined (no CDN or runtime fetch): each entry is the icon's child geometry.
// A filled colored pin silhouette carries a white Lucide glyph in its head.
const LUCIDE = {
  truck: [
    ["path", { d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2" }],
    ["path", { d: "M15 18H9" }],
    ["path", { d: "M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14" }],
    ["circle", { cx: 17, cy: 18, r: 2 }],
    ["circle", { cx: 7, cy: 18, r: 2 }],
  ],
  phone: [
    ["path", { d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384" }],
  ],
  bell: [
    ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0" }],
    ["path", { d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" }],
  ],
  shield: [
    ["path", { d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" }],
  ],
  eye: [
    ["path", { d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" }],
    ["circle", { cx: 12, cy: 12, r: 3 }],
  ],
  flame: [
    ["path", { d: "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" }],
  ],
  clock: [
    ["path", { d: "M12 6v6l4 2" }],
    ["circle", { cx: 12, cy: 12, r: 10 }],
  ],
};
// Closed flame silhouette (filled) for building fire glyphs.
const FLAME_PATH = LUCIDE.flame[0][1].d;

// Marker identity by source CHANNEL: color + Lucide glyph (never color alone;
// the exact source_type is always named in the feed and aria text).
const CAT = {
  call:      { color: "#4ea1ff", glyph: "phone",  label: "human call" },
  alarm:     { color: "#e0a83a", glyph: "bell",   label: "auto alarm" },
  responder: { color: "#3fb27f", glyph: "shield", label: "responder update" },
  truck:     { color: "#14b8a6", glyph: "eye",    label: "truck sensor" },
  fire:      { color: "#f97316", glyph: "flame",  label: "fire" },
  vehicle:   { color: "#ef4444", glyph: "truck",  label: "firetruck" },
};
// Burning-intensity bands (matches engine cut points 33/67) -> flame size + shade.
// color/core/tip are the outer/mid/inner flame-layer fills (see drawFireGlyph).
const BAND = {
  smoldering: { scale: 0.72, color: "#f2b45c", core: "#f7cd7e", tip: "#ffe6a6" },
  burning:    { scale: 0.95, color: "#f97316", core: "#fb923c", tip: "#fdba74" },
  raging:     { scale: 1.25, color: "#ef4444", core: "#f97316", tip: "#fbbf24" },
};
function fireBand(intensity) {
  return intensity < 33 ? "smoldering" : intensity < 67 ? "burning" : "raging";
}

// Pin geometry: Lucide-style teardrop in a 24-box, tip at (12,22), head at (12,9).
const PIN_PATH = "M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z";
const PIN_K = 3.75;                    // base pin scale
const PIN_HEAD_Y = -13 * PIN_K;        // head-center offset from tip (origin)

function srcStyle(t) {
  const label = (t || "report").replace(/_/g, " ");
  if (t === "truck_observation") return { ...CAT.truck };
  if (t === "automatic_alarm") return { ...CAT.alarm, label };
  if (t === "responder_update") return { ...CAT.responder, label };
  return { ...CAT.call, label };
}
function isTruckContact(c) { return c.payload_type === "truck_observation"; }

// Build a filled pin (tip anchored at the group origin) with a white glyph inside.
function buildPin(parent, color, glyph, scale) {
  const k = PIN_K * (scale || 1);
  const g = mk(parent, "g", { class: "pin", transform: `scale(${k}) translate(-12 -22)` });
  mk(g, "path", { class: "pin-body", d: PIN_PATH, fill: color });
  const gg = mk(g, "g", { class: "pin-glyph",
    transform: "translate(12 9) scale(0.42) translate(-12 -12)",
    fill: "none", stroke: "#fff", "stroke-width": 2.6,
    "stroke-linecap": "round", "stroke-linejoin": "round" });
  for (const [tag, attrs] of LUCIDE[glyph] || []) mk(gg, tag, attrs);
  return g;
}
// Top-down fire-truck sprite (assets/firetruck.png, 209x418, cab pointing "up"
// = -y north at rest); the rAF loop rotates the returned `.truck-body` group to
// travel heading. While status != idle a strobe rect overlays the sprite's own
// light bar and flashes red/blue (see .light-bar in app.css).
const TRUCK_K = 5.4;
function buildTruck(parent, strobing) {
  const g = mk(parent, "g", { class: "truck-body" });
  const b = mk(g, "g", { transform: `scale(${TRUCK_K})` });
  mk(b, "image", { href: "assets/firetruck.png", x: -6, y: -12, width: 12, height: 24,
    preserveAspectRatio: "xMidYMid meet" });
  if (strobing)
    mk(b, "rect", { class: "light-bar strobe",
      x: -2.9, y: -9.6, width: 5.8, height: 1.6, rx: 0.7, fill: "#ef4444" });
  return g;
}

// Filled flame glyph centered at the local origin, sized/shaded by band. Three
// superimposed flame layers (outer/mid/inner) flicker via CSS; band drives
// speed/amplitude (see .fire-glyph in app.css). `douse` (or null) marks a fire
// being actively suppressed: damped flicker + opacity weakening by ticks-to-out.
function drawFireGlyph(g, band, douse) {
  const bs = BAND[band] || BAND.burning;
  const k = 5.1 * bs.scale;
  const gg = mk(g, "g", { class: "fire-glyph band-" + band + (douse ? " dousing" : "") });
  if (douse) {
    const t = douse.ttx;
    gg.style.opacity = String(t == null ? 0.85 : Math.max(0.35, Math.min(1, 0.35 + t * 0.09)));
  }
  const sc = mk(gg, "g", { transform: `scale(${k}) translate(-12 -12)` });
  // Layers shrink about the flame base (local 12,24) so the flicker stays anchored.
  for (const [cls, tint, s] of [["f0", bs.color, 1], ["f1", bs.core, 0.8], ["f2", bs.tip, 0.55]]) {
    const w = mk(sc, "g", { transform: `translate(12 24) scale(${s}) translate(-12 -24)` });
    mk(w, "path", { class: "flame " + cls, d: FLAME_PATH, fill: tint });
  }
  return gg;
}
// Black keyline for a building that has ever been on fire.
function drawEverBurned(g, sx, sy) {
  mk(g, "rect", { class: "ever-burned", x: sx - 11, y: sy - 11, width: 22, height: 22 });
}
// Inner group whose content counter-scales with zoom (see --izoom in applyView),
// anchored at (x, y). Put icons and text here; keep world geometry outside.
function anchored(parent, x, y) {
  return mk(mk(parent, "g", { transform: `translate(${x} ${y})` }), "g", { class: "szfix" });
}

const $ = (id) => document.getElementById(id);
const el = {
  lifecycle: $("lifecycle"), tick: $("tick"),
  scenario: $("scenario"), counts: $("counts"), tokens: $("tokens"),
  controller: $("controller"), connection: $("connection"), banner: $("banner"),
  lobby: $("lobby"), lobbyTitle: $("lobby-title"), mapc: $("mapcontainer"),
  fullFlag: $("fullstate-flag"), revealFlag: $("reveal-flag"),
  feed: $("feed"), fHuman: $("f-human"), fTruck: $("f-truck"),
  card: $("hovercard"), cardTitle: $("hovercard-title"), cardBody: $("hovercard-body"),
  legend: $("legend"), live: $("live"), mapwrap: $("mapwrap"), zoomhint: $("zoomhint"),
  uiscale: $("uiscale"),
};

// ---- render state ---------------------------------------------------------
const S = {
  lastRevision: -1,
  lastValid: null,
  mapId: null,
  buildings: {},            // building_id -> {point:{x,y}, name}
  tf: null,                 // {ox, oy, zoom}
  groups: {},               // overlay <g> nodes keyed by role
  svg: null,
  selection: null,          // {kind:'contact'|'vehicle', id}
  hover: null,              // {kind, id} currently in the floating card
  vehAnim: {},              // vehicle_id -> {pos:{x,y}, poly:[{x,y}], raf:id}
  view: { scale: 1, tx: 0, ty: 0 },   // pan/zoom of the map svg
  prevLifecycle: null,
  prevPolicy: null,
  prevTruth: false,
  truthHidden: true,        // local toggle: hide the full-state truth layer on this display (starts hidden)
  dismissed: new Set(),     // contact_ids the operator manually hid from the feed (session-only)
  filters: { human: true, truck: true },
  renderBusy: false,
  pendingSnap: null,
  truthHintSeen: localStorage.getItem("truthHint") === "seen",
  metricPrev: {},           // metric key -> last seen count, to detect a rise
  bumpTick: {},             // metric key -> tick it last rose on (pulses that tick)
  douse: {},                // building_id -> {suppressors, ttx} for the current frame
};

// ---- polling --------------------------------------------------------------
let failures = 0;

async function poll() {
  try {
    const r = await fetch("/api/v1/snapshot", { cache: "no-store" });
    if (!r.ok) throw new Error("http " + r.status);
    const snap = await r.json();
    failures = 0;
    setConnection(true);
    if (!validSnapshot(snap)) { showBanner("Display error: malformed snapshot"); return; }
    clearBanner();
    S.lastValid = snap;
    if (typeof snap.display_revision === "number" && snap.display_revision > S.lastRevision) {
      S.lastRevision = snap.display_revision;
      safeRender(snap);
    }
  } catch (e) {
    failures += 1;
    if (failures >= DISCONNECT_AFTER) setConnection(false);
  }
}

function validSnapshot(s) {
  return s && typeof s === "object"
    && typeof s.display_revision === "number"
    && typeof s.lifecycle === "string"
    && Array.isArray(s.new_contacts) && Array.isArray(s.contact_history)
    && Array.isArray(s.vehicles);
}

function safeRender(snap) {
  // Keep only the highest revision when a render overruns the poll interval.
  if (S.renderBusy) { S.pendingSnap = snap; return; }
  S.renderBusy = true;
  Promise.resolve().then(() => render(snap)).catch((e) => {
    showBanner("Display error while rendering");
    console.error(e);
  }).finally(() => {
    S.renderBusy = false;
    const q = S.pendingSnap; S.pendingSnap = null;
    if (q && q.display_revision > (snap.display_revision || 0)) safeRender(q);
  });
}

// ---- header / connection --------------------------------------------------
function setConnection(ok) {
  el.connection.textContent = ok ? "display connected" : "display disconnected";
  el.connection.className = "badge " + (ok ? "ok" : "bad");
  document.body.classList.toggle("dimmed", !ok);
  if (!ok) showBanner("Disconnected: showing last known state");
  else if (el.banner.textContent.startsWith("Disconnected")) clearBanner();
}
function showBanner(msg) { el.banner.textContent = msg; el.banner.classList.remove("hidden"); }
function clearBanner() { el.banner.classList.add("hidden"); el.banner.textContent = ""; }

function updateHeader(snap) {
  const lc = snap.lifecycle;
  el.lifecycle.textContent = lc;
  el.lifecycle.className = "badge " + lc;
  if (snap.tick == null) el.tick.textContent = "tick --/--";
  else el.tick.textContent = "tick " + pad(snap.tick) + "/" + pad(snap.tick_limit);
  updateScoreboard(snap);
  // Controller presence is inferred from lifecycle: a running episode implies a
  // live controller lease; lobby/terminal do not.
  const connected = lc === "running";
  el.controller.textContent = connected ? "controller connected" : "no controller";
  el.controller.className = "badge " + (connected ? "ok" : "");
}
function pad(n) { return String(n).padStart(2, "0"); }

// Thousands to one decimal once the number is big enough to need it, so a
// casualty count reads "7" while a token total reads "51.9K" in the same row.
function thousands(n) {
  if (typeof n !== "number" || !isFinite(n)) return "--";
  return n < 1000 ? String(n) : (n / 1000).toFixed(1) + "K";
}

// Live scoreboard: scenario, the two safety numbers, and the participant's
// self-reported token bill. Shown on every display policy - the agent never
// reads this surface, so there is nothing here for it to cheat with.
const SKULL = "\u{1F480}";
const BUILDING = "\u{1F3E2}";
function updateScoreboard(snap) {
  el.scenario.textContent = ": " + (snap.scenario_id || "--");
  ensureMetrics();
  const m = snap.metrics || {};
  bumpMetric(el.casualties, "casualties", m.casualties ?? 0, snap.tick);
  bumpMetric(el.buildings, "buildings", m.buildings_lost ?? 0, snap.tick);
  // Per role: the two models are chosen and tuned separately, so one aggregate
  // would hide which of them is actually spending.
  const t = snap.tokens || {};
  el.tokens.textContent =
    role("Intake", t.intake) + "   " + role("Dispatch", t.dispatch);
}

// Each count gets its own span so one icon can pulse without the other. Built
// here rather than in index.html, which the engine reads into memory once at
// startup and so cannot be changed by a browser refresh.
function ensureMetrics() {
  if (el.casualties) return;
  el.counts.innerHTML =
    '<span class="metric" id="casualties"><span class="ico"></span> <span class="val"></span></span>' +
    '  <span class="metric" id="buildings"><span class="ico"></span> <span class="val"></span></span>,';
  el.casualties = $("casualties");
  el.buildings = $("buildings");
  el.casualties.querySelector(".ico").textContent = SKULL;
  el.buildings.querySelector(".ico").textContent = BUILDING;
}

// Pulse a count from the tick it rises on until the tick advances, so a death
// that lands while the room is watching the map is still flagged afterwards.
// A drop means a new episode zeroed the counters: clear rather than pulse.
function bumpMetric(node, key, val, tick) {
  const prev = S.metricPrev[key];
  if (prev == null || val < prev) S.bumpTick[key] = null;
  else if (val > prev) S.bumpTick[key] = tick;
  S.metricPrev[key] = val;
  node.querySelector(".val").textContent = thousands(val);
  node.classList.toggle("bumped", S.bumpTick[key] != null && S.bumpTick[key] === tick);
}

function role(label, u) {
  u = u || {};
  const read = u.read ?? 0;
  // The hit rate, not the fresh-read count: `read` already contains the cached
  // subset, so a raw "N cached" reads as an addition when it is a proportion.
  const pct = read > 0
    ? Math.round((u.cache_read ?? 0) / read * 100) + "% cached"
    : "uncached";
  return label + " " + thousands(read) + "/" + thousands(u.write ?? 0) +
    " (" + pct + ")";
}

// ---- top-level render -----------------------------------------------------
async function render(snap) {
  updateHeader(snap);
  announce(snap);

  const mapBlock = snap.map;
  const nowTruth = snap.lifecycle === "terminal" || snap.includes_truth;

  // Start of a new session (episode enters running): clear all operator-hidden reports.
  if (snap.lifecycle === "running" && S.prevLifecycle !== "running") S.dismissed.clear();

  // Synchronous teardown BEFORE drawing when leaving a truth-bearing view for
  // lobby or a public_only participant view. A stale truth frame is a leak.
  const downgrade = S.prevTruth && !nowTruth;
  const toLobby = snap.lifecycle === "lobby";
  if (downgrade || toLobby) { clearTruth(); S.selection = null; hideCard(); }
  // Drop a selection that no longer exists (e.g. a new run reuses the same map,
  // so there is no map teardown and the snapshot carries no run_id to compare).
  validateSelection(snap);

  if (snap.lifecycle === "lobby" || !mapBlock) {
    teardownMap();
    el.lobby.classList.remove("hidden");
    el.zoomhint.classList.add("hidden");
    el.lobbyTitle.textContent = "Waiting for episode";
    S.selection = null; hideCard(); renderFeed(snap);
    S.prevLifecycle = snap.lifecycle; S.prevPolicy = snap.display_policy; S.prevTruth = false;
    return;
  }
  el.lobby.classList.add("hidden");
  el.zoomhint.classList.remove("hidden");

  // Map replacement: full teardown of overlays/selection on map_id change.
  if (mapBlock.map_id !== S.mapId) {
    teardownMap();
    S.selection = null; hideCard();
    await loadMap(mapBlock);
  }
  computeTransform(mapBlock);

  // Fires under active suppression this frame: building_id -> {suppressors, ttx}.
  // Drives flame damping/weakening and the truck->fire water arcs.
  S.douse = {};
  for (const e of snap.fire_eta || [])
    if (e.suppressors > 0) S.douse[e.building_id] = { suppressors: e.suppressors, ttx: e.ticks_to_extinguish };

  renderTruth(snap);
  renderMarkers(snap);
  renderVehicles(snap);
  renderFeed(snap);
  applySelectionStyles();

  S.prevLifecycle = snap.lifecycle;
  S.prevPolicy = snap.display_policy;
  S.prevTruth = nowTruth;
}

// ---- map loading ----------------------------------------------------------
async function loadMap(mapBlock) {
  const svgText = await (await fetch(`/api/v1/maps/${encodeURIComponent(mapBlock.map_id)}/display.svg`,
    { cache: "force-cache" })).text();
  // Public building directory (id -> point/name) for markers and truth glyphs;
  // it is not present in the snapshot and the SVG carries no building IDs.
  let dir = { buildings: [] };
  try {
    dir = await (await fetch(`/api/v1/maps/${encodeURIComponent(mapBlock.map_id)}/buildings.json`,
      { cache: "force-cache" })).json();
  } catch (e) { /* markers referencing buildings simply skip if absent */ }
  S.buildings = {};
  for (const b of dir.buildings || []) S.buildings[b.building_id] = { point: b.point, name: b.name };

  const doc = new DOMParser().parseFromString(svgText, "image/svg+xml");
  const svg = doc.documentElement;
  if (svg.nodeName.toLowerCase() !== "svg") throw new Error("bad svg");
  svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
  // Accessible name/description for the whole map surface.
  const title = mk(null, "title", {}); title.textContent = "Operational map";
  svg.insertBefore(title, svg.firstChild);
  el.mapc.replaceChildren(document.importNode(svg, true));
  const inlined = el.mapc.querySelector("svg");

  // Overlay groups in fixed paint order (bottom -> top).
  S.groups = {};
  for (const role of ["truth", "uncertainty", "markers", "routes", "vehicles", "labels"]) {
    const g = mk(inlined, "g", { class: "layer-" + role });
    S.groups[role] = g;
  }
  S.svg = inlined;
  S.mapId = mapBlock.map_id;
  resetView();
}

function teardownMap() {
  el.mapc.replaceChildren();
  S.mapId = null; S.groups = {}; S.svg = null; S.buildings = {};
  S.vehAnim = {}; clearTruth();
}
// Local show/hide of the full-state truth layer (does not affect what the server sends).
function applyTruthVisibility() {
  if (S.groups.truth) S.groups.truth.classList.toggle("truth-hidden", S.truthHidden);
  el.fullFlag.textContent = S.truthHidden ? "FULL STATE HIDDEN" : "FULL STATE SHOWN";
  // Armed only while the chip itself is up. At terminal everyone is meant to see
  // the reveal, so the alarm is for truth leaking DURING play, not after it.
  const live = !S.truthHidden && !el.fullFlag.classList.contains("hidden");
  el.fullFlag.classList.toggle("shown", live);
  el.mapc.classList.toggle("truth-live", live);
  ensureTruthHint();
  el.truthHint.classList.toggle(
    "hidden", S.truthHintSeen || el.fullFlag.classList.contains("hidden"));
}
// Coach mark pointing at the flag: the chevron says it is a toggle, this says
// what toggling does. Shown until the operator uses or dismisses it, once ever.
function ensureTruthHint() {
  if (el.truthHint) return;
  const d = document.createElement("div");
  d.id = "truth-hint";
  d.className = "hint hidden";
  d.innerHTML = 'Click the flag to show or hide ground truth here.' +
    '<button class="x" title="Dismiss" aria-label="Dismiss">x</button>';
  el.mapwrap.appendChild(d);
  el.truthHint = d;
  d.querySelector(".x").addEventListener("click", dismissTruthHint);
}
function dismissTruthHint() {
  S.truthHintSeen = true;
  localStorage.setItem("truthHint", "seen");
  if (el.truthHint) el.truthHint.classList.add("hidden");
}
function clearTruth() {
  if (S.groups.truth) S.groups.truth.replaceChildren();
  el.fullFlag.classList.add("hidden");
  el.fullFlag.classList.remove("shown");
  el.mapc.classList.remove("truth-live");
  if (el.truthHint) el.truthHint.classList.add("hidden");
  el.revealFlag.classList.add("hidden");
}

function computeTransform(mapBlock) {
  const vb = (S.svg.getAttribute("viewBox") || "0 0 1 1").split(/\s+/).map(Number);
  const w = vb[2], h = vb[3];
  const wmin = mapBlock.world_min, wmax = mapBlock.world_max;
  const zx = w / (wmax.x - wmin.x), zy = h / (wmax.y - wmin.y);
  S.tf = { ox: wmin.x, oy: wmin.y, zoom: (zx + zy) / 2 };
}
function toScreen(p) {
  return { x: (p.x - S.tf.ox) * S.tf.zoom, y: (p.y - S.tf.oy) * S.tf.zoom };
}

// ---- pan / zoom -----------------------------------------------------------
function applyView() {
  if (!S.svg) return;
  S.svg.style.transform =
    `translate(${S.view.tx}px, ${S.view.ty}px) scale(${S.view.scale})`;
  // Icons/labels hold screen size when zoomed in (never grow when zoomed out).
  el.mapc.style.setProperty("--izoom", String(1 / Math.max(1, S.view.scale)));
}
function resetView() { S.view = { scale: 1, tx: 0, ty: 0 }; applyView(); }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function zoomAt(cx, cy, factor) {
  const ns = clamp(S.view.scale * factor, 0.5, 16);
  const k = ns / S.view.scale;
  // Keep the world point under (cx, cy) fixed on screen.
  S.view.tx = cx - k * (cx - S.view.tx);
  S.view.ty = cy - k * (cy - S.view.ty);
  S.view.scale = ns;
  applyView();
  hideCard();
}
function onWheel(e) {
  if (!S.svg) return;
  e.preventDefault();
  const rect = el.mapc.getBoundingClientRect();
  zoomAt(e.clientX - rect.left, e.clientY - rect.top, Math.exp(-e.deltaY * 0.0015));
}
let panDown = null, panning = false;
function onPointerDown(e) {
  if (!S.svg || e.button !== 0) return;
  panDown = { x: e.clientX, y: e.clientY, tx: S.view.tx, ty: S.view.ty, id: e.pointerId };
}
function onPointerMove(e) {
  if (!panDown) return;
  const dx = e.clientX - panDown.x, dy = e.clientY - panDown.y;
  if (!panning && Math.hypot(dx, dy) > 4) {   // begin panning only past a click threshold
    panning = true;
    el.mapc.setPointerCapture(panDown.id);
    el.mapc.classList.add("panning");
    hideCard();
  }
  if (panning) { S.view.tx = panDown.tx + dx; S.view.ty = panDown.ty + dy; applyView(); }
}
function onPointerUp(e) {
  if (panning && panDown) { try { el.mapc.releasePointerCapture(panDown.id); } catch (_) {} }
  panDown = null; panning = false; el.mapc.classList.remove("panning");
}

// ---- truth overlay (full_state live, terminal reveal) ---------------------
function renderTruth(snap) {
  const g = S.groups.truth; if (!g) return;
  g.replaceChildren();
  const terminal = snap.lifecycle === "terminal";
  const block = terminal ? snap.reveal : (snap.includes_truth ? snap.world_state : null);
  if (!block) { clearTruth(); return; }

  el.fullFlag.classList.toggle("hidden", !(snap.includes_truth && !terminal));
  el.revealFlag.classList.toggle("hidden", !terminal);
  applyTruthVisibility();

  const intensity = {};
  for (const f of block.fires || []) intensity[f.building_id] = f.intensity;

  for (const b of block.buildings || []) {
    const bi = S.buildings[b.building_id]; if (!bi) continue;
    const s = toScreen(bi.point);
    const gg = mk(g, "g", { class: "truth-glyph" });
    // A building that has ever burned: black keyline. Never-burned buildings stay
    // grey (no tint, no ring). Base lots keep their neutral map borders.
    // Ever-burned keyline for burned-out buildings; the flame already marks active fires.
    if (b.ever_burned && b.status !== "burning") drawEverBurned(gg, s.x, s.y);
    // Only abnormal buildings carry a status text label and occupancy count.
    if (b.status === "burning" || b.status === "collapsed") {
      const a = anchored(gg, s.x, s.y);
      if (b.status === "burning") {
        wireFireCard(drawFireGlyph(a, fireBand(intensity[b.building_id] || 0), S.douse[b.building_id]), b.building_id);
      } else {
        const w = mk(a, "text", { x: 0, y: -13, "text-anchor": "middle" });
        w.textContent = b.status;
      }
      const occ = mk(a, "text", { x: 0, y: 90, "text-anchor": "middle" });
      occ.textContent = "\u{1F9D1} " + b.occupants + (b.casualties ? " / cas " + b.casualties : "");
    }
  }
}

// ---- report markers -------------------------------------------------------
function renderMarkers(snap) {
  const g = S.groups.markers; if (!g) return;
  g.replaceChildren();
  const freshIds = new Set((snap.new_contacts || []).map((c) => c.contact_id));
  // Deduplicate truck observations by lot: keep the latest observation per
  // building (latest tick wins) so one glyph per lot replaces per-contact spam.
  const latestObs = {};
  // Delivery order -> logical focus order for keyboard users.
  for (const c of snap.contact_history || []) {
    if (isTruckContact(c)) {
      const p = c.payload;
      for (const ob of p.buildings || []) {
        const prev = latestObs[ob.building_id];
        if (!prev || p.tick >= prev.tick)
          latestObs[ob.building_id] = { status: ob.status, tick: p.tick };
      }
      // Truck-observation sensor pins are not drawn on the map; the observation
      // still feeds the per-lot fire/ever-burned aggregate above (real observed state).
      continue;
    }
    if (S.dismissed.has(c.contact_id)) continue;
    const pt = contactPoint(c);
    if (!pt) continue;
    drawMarker(g, c, pt, freshIds.has(c.contact_id));
  }
  // Per-lot observed status. On full_state/terminal the truth layer already draws
  // fires + ever-burned outlines authoritatively, so only draw these when hidden.
  if (!(snap.includes_truth || snap.lifecycle === "terminal")) {
    for (const bid in latestObs) {
      const ob = latestObs[bid];
      if (ob.status === "normal") continue;   // retired: lot observed no longer on fire
      const bi = S.buildings[bid]; if (!bi) continue;
      const s = toScreen(bi.point);
      const gg = mk(g, "g", { class: "truth-glyph" });
      drawEverBurned(gg, s.x, s.y);           // observed abnormal -> has ever burned
      const a = anchored(gg, s.x, s.y);
      if (ob.status === "burning") wireFireCard(drawFireGlyph(a, "burning", S.douse[bid]), bid);
      else {
        const w = mk(a, "text", { x: 0, y: -13, "text-anchor": "middle" });
        w.textContent = ob.status;
      }
    }
  }
}


function contactPoint(c) {
  const loc = c.reported_location;
  if (!loc) return null;
  if (loc.kind === "coordinates" && loc.coordinates) return loc.coordinates;
  if (loc.building_id && S.buildings[loc.building_id]) return S.buildings[loc.building_id].point;
  return null;
}

function drawMarker(g, c, worldPt, fresh) {
  const s = toScreen(worldPt);
  const st = srcStyle(c.source_type);
  const node = mk(g, "g", {
    class: "marker" + (fresh ? " fresh" : ""), transform: `translate(${s.x} ${s.y})`,
    tabindex: "0", role: "button", "data-cid": c.contact_id,
  });
  const inner = mk(node, "g", { class: "szfix" });
  mk(inner, "circle", { class: "halo", cx: 0, cy: PIN_HEAD_Y, r: 11,
    fill: "none", stroke: "transparent", "stroke-width": 3 });
  buildPin(inner, st.color, st.glyph);
  const desc = mk(node, "title", {});
  desc.textContent = markerText(c);
  node.setAttribute("aria-label", markerText(c));
  wireSelect(node, { kind: "contact", id: c.contact_id });
}

// ---- vehicles + routes + animation ---------------------------------------
function renderVehicles(snap) {
  const gv = S.groups.vehicles, gr = S.groups.routes, gl = S.groups.labels;
  if (!gv || !gr) return;
  gv.replaceChildren(); gr.replaceChildren(); if (gl) gl.replaceChildren();
  const pendingByVeh = {};
  for (const pc of snap.pending || []) (pendingByVeh[pc.vehicle_id] ||= []).push(pc);

  for (const v of snap.vehicles || []) {
    const target = toScreen(v.position);
    // Committed remaining route polyline from the current position (solid).
    if (v.route && v.route.polyline && v.route.polyline.length > 1) {
      const pts = v.route.polyline.map((p) => toScreen(p));
      mk(gr, "polyline", { class: "route", points: ptsStr(pts) });
    }
    if (v.destination) {
      const d = toScreen(v.destination.snapped);
      mk(anchored(gr, d.x, d.y), "rect", { x: -5, y: -5, width: 10, height: 10,
        fill: "none", stroke: "#4ea1ff", "stroke-width": 2, transform: "rotate(45)" });
    }
    // Pending (accepted, not yet committed) command: draw its full route dashed
    // right away, as if the truck were already moving there.
    for (const pc of pendingByVeh[v.vehicle_id] || []) {
      const line = pc.route && pc.route.polyline && pc.route.polyline.length > 1
        ? pc.route.polyline.map((p) => toScreen(p))
        : [target, toScreen(pc.destination.snapped)];
      mk(gr, "polyline", { class: "route pending", points: ptsStr(line) });
    }

    const node = mk(gv, "g", {
      class: "vehicle", tabindex: "0", role: "button", "data-vid": v.vehicle_id,
      transform: `translate(${target.x} ${target.y})`,
    });
    // View-distance ring (world geometry, beneath the pin). Blue; thicker while
    // firefighting. Blue ripple pings outward continuously (2.5s cycle);
    // negative delay keeps the cycle phase-continuous across per-tick recreations.
    const R = (snap.vision_radius || 0) * S.tf.zoom;
    if (R > 0) {
      const fighting = v.status === "firefighting";
      mk(node, "circle", { class: "vision-range" + (fighting ? " active" : ""), r: R });
      const ripple = mk(node, "circle", { class: "vision-ripple", r: R });
      ripple.style.animationDelay = "-" + ((performance.now() % 2500) / 1000) + "s";
    }
    const inner = mk(node, "g", { class: "szfix" });
    mk(inner, "circle", { class: "halo", cx: 0, cy: 0, r: 68,
      fill: "none", stroke: "transparent", "stroke-width": 3 });
    buildTruck(inner, v.status !== "idle");
    // Status by text (never color alone): moving / firefighting / idle.
    // Only surface status as text when idle; moving/firefighting stay unlabeled.
    if (v.status === "idle") {
      const stt = mk(inner, "text", { class: "ovlabel", x: 0, y: -72, "text-anchor": "middle" });
      stt.textContent = v.status;
    }
    const ttl = mk(node, "title", {}); ttl.textContent = vehicleText(v);
    node.setAttribute("aria-label", vehicleText(v));
    wireSelect(node, { kind: "vehicle", id: v.vehicle_id });

    animateVehicle(v.vehicle_id, node, target, v.route);
  }
  // Arcs go in the labels layer so the water reads as spraying OVER the truck.
  drawDousingArcs(gl || gr, snap);
  // Drop animation state for vehicles no longer present.
  for (const id of Object.keys(S.vehAnim))
    if (!(snap.vehicles || []).some((v) => v.vehicle_id === id)) delete S.vehAnim[id];
}

// Pulsing water arcs from each suppressing truck to the fire it is dousing.
// Matches firefighting trucks to a doused fire by proximity (within vision), up
// to its suppressor count; the flowing look is an animated stroke-dashoffset.
function drawDousingArcs(gr, snap) {
  const bids = Object.keys(S.douse || {});
  if (!bids.length) return;
  const fighters = (snap.vehicles || []).filter((v) => v.status === "firefighting");
  if (!fighters.length) return;
  const R = (snap.vision_radius || 0) * S.tf.zoom;
  for (const bid of bids) {
    const bi = S.buildings[bid]; if (!bi) continue;
    const f = toScreen(bi.point);
    const near = fighters
      .map((v) => { const s = toScreen(v.position); return { s, d: Math.hypot(s.x - f.x, s.y - f.y) }; })
      .filter((o) => R <= 0 || o.d <= R * 1.2)
      .sort((a, b) => a.d - b.d)
      .slice(0, Math.max(1, S.douse[bid].suppressors));
    for (const o of near) {
      // Each truck sprays a fan of jets from one nozzle point onto spread-out
      // targets around the fire base (offsets counter-scale like the glyph).
      const iz = 1 / Math.max(1, S.view.scale);
      const targets = [[-11, 2], [0, 0], [11, 2]];
      for (let j = 0; j < targets.length; j++) {
        const tx = f.x + targets[j][0] * iz, ty = f.y + targets[j][1] * iz;
        const lift0 = Math.max(o.d * (0.25 + 0.07 * j), 20);
        // Bow the jet up; keep a floor so it still reads when the truck parks on
        // the fire. dx sweeps the tip sideways for the hose-waving animation.
        const arc = (dx) => {
          const mx = (o.s.x + tx + dx) / 2, my = (o.s.y + ty) / 2;
          return `M${o.s.x} ${o.s.y} Q${mx} ${my - lift0} ${tx + dx} ${ty}`;
        };
        const p = mk(gr, "path", { class: "water-arc", d: arc(0) });
        // Native SMIL sweep of the path itself; phase-offset so jets desync.
        if (!reduceMotion) {
          const sw = 2 * iz;
          mk(p, "animate", { attributeName: "d", dur: "1.7s", repeatCount: "indefinite",
            calcMode: "spline", keySplines: "0.45 0 0.55 1;0.45 0 0.55 1",
            values: [arc(-sw), arc(sw), arc(-sw)].join(";"),
            begin: (-0.57 * j) + "s" });
        }
      }
    }
  }
}

function animateVehicle(id, node, target, route) {
  const prev = S.vehAnim[id];
  const state = { pos: target, poly: (route && route.polyline) ? route.polyline.map(toScreen) : [], raf: 0 };
  if (prev && prev.raf) cancelAnimationFrame(prev.raf);
  // Snap when no history, reduced motion, or geometry is unavailable.
  if (!prev || reduceMotion || !prev.poly.length || sameXY(prev.pos, target)) {
    node.setAttribute("transform", `translate(${target.x} ${target.y})`);
    S.vehAnim[id] = state;
    return;
  }
  // route.polyline is the FULL journey from origin (the truck advances a cursor
  // along it, never trimmed), so trace the road between the PREVIOUS position and
  // the new one -- slicing from poly[0] would re-animate from the journey start.
  const poly = prev.poly;
  const nearest = (pt) => {
    let idx = 0, best = Infinity;
    for (let i = 0; i < poly.length; i++) { const dd = dist2(poly[i], pt); if (dd < best) { best = dd; idx = i; } }
    return idx;
  };
  const from = nearest(prev.pos), to = nearest(target);
  const path = [prev.pos, ...(to > from ? poly.slice(from + 1, to + 1) : []), target];
  if (path.length < 2) { node.setAttribute("transform", `translate(${target.x} ${target.y})`); S.vehAnim[id] = state; return; }

  const segLen = [], cum = [0];
  let total = 0;
  for (let i = 1; i < path.length; i++) { const l = Math.hypot(path[i].x - path[i-1].x, path[i].y - path[i-1].y); segLen.push(l); total += l; cum.push(total); }
  if (total === 0) { node.setAttribute("transform", `translate(${target.x} ${target.y})`); S.vehAnim[id] = state; return; }

  // Rotate the truck glyph (not the whole node, so ring/label/halo stay upright)
  // to the current segment heading: 0deg = north (-y), +90 = travelling east.
  const body = node.querySelector(".truck-body");
  const t0 = performance.now();
  const step = (now) => {
    const u = Math.min(1, (now - t0) / ANIM_MS);
    const d = u * total;
    let i = 1; while (i < cum.length - 1 && cum[i] < d) i++;
    const segStart = cum[i - 1], seg = segLen[i - 1] || 1;
    const f = (d - segStart) / seg;
    const a = path[i - 1], b = path[i];
    const x = a.x + (b.x - a.x) * f, y = a.y + (b.y - a.y) * f;
    node.setAttribute("transform", `translate(${x} ${y})`);
    if (body && (b.x !== a.x || b.y !== a.y))
      body.setAttribute("transform", `rotate(${Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI + 90})`);
    state.pos = { x, y };
    if (u < 1) state.raf = requestAnimationFrame(step);
  };
  state.raf = requestAnimationFrame(step);
  S.vehAnim[id] = state;
}

// ---- feed -----------------------------------------------------------------
function renderFeed(snap) {
  el.feed.replaceChildren();
  const freshIds = new Set((snap.new_contacts || []).map((c) => c.contact_id));
  // Newest first, keeping stable delivery order as the tiebreak.
  const items = (snap.contact_history || []).slice().reverse();
  // Latest observation tick per building, to drop superseded truck observations:
  // an observation is superseded once every building it reported has a later look.
  const maxObsTick = {};
  for (const c of snap.contact_history || []) {
    if (!isTruckContact(c)) continue;
    for (const b of c.payload.buildings || [])
      maxObsTick[b.building_id] = Math.max(maxObsTick[b.building_id] ?? -Infinity, c.payload.tick);
  }
  for (const c of items) {
    if (S.dismissed.has(c.contact_id)) continue;
    if (isTruckContact(c)) {
      if (!S.filters.truck) continue;
      // Keep only while it still holds the latest observation of some building.
      if (!(c.payload.buildings || []).some((b) => c.payload.tick >= (maxObsTick[b.building_id] ?? -Infinity))) continue;
    } else if (!S.filters.human) continue;
    el.feed.appendChild(feedItem(c, freshIds.has(c.contact_id)));
  }
  if (!el.feed.children.length) {
    const li = document.createElement("li");
    li.className = "report muted"; li.textContent = "No reports yet.";
    el.feed.appendChild(li);
  }
}

function feedItem(c, fresh) {
  const st = srcStyle(c.source_type);
  const li = document.createElement("li");
  li.className = "report" + (fresh ? " fresh" : "") +
    (S.selection && S.selection.kind === "contact" && S.selection.id === c.contact_id ? " selected" : "");
  li.tabIndex = 0; li.setAttribute("role", "button"); li.dataset.cid = c.contact_id;

  const head = document.createElement("div"); head.className = "rhead";
  const glyph = document.createElement("span"); glyph.className = "glyph";
  glyph.style.color = st.color;
  glyph.append(htmlIcon(st.glyph, 14));
  const src = document.createElement("span"); src.className = "src";
  src.textContent = c.source_type; // typed enum, safe
  const times = document.createElement("span"); times.className = "times";
  const delay = c.delivered_at - c.occurred_at;
  times.append(`occurred ${c.occurred_at} / delivered ${c.delivered_at}`);
  if (delay > 0) {
    // Delivery delay: clock glyph + (+N), titled so the meaning is explicit.
    const d = document.createElement("span"); d.className = "delay";
    d.title = `delivered ${delay} ${delay === 1 ? "tick" : "ticks"} after it occurred`;
    d.append(htmlIcon("clock", 11), `(+${delay})`);
    times.append(" ", d);
  }
  const dismiss = document.createElement("button");
  dismiss.className = "dismiss"; dismiss.type = "button";
  dismiss.textContent = "x";
  dismiss.title = "Hide this report from the feed";
  dismiss.setAttribute("aria-label", "Hide this report");
  dismiss.addEventListener("click", (e) => {
    e.stopPropagation();
    S.dismissed.add(c.contact_id);
    if (S.lastValid) { renderFeed(S.lastValid); renderMarkers(S.lastValid); }
  });
  head.append(glyph, src, times, dismiss);
  li.append(head);

  const body = document.createElement("div"); body.className = "body";
  renderPayload(body, c);
  li.append(body);

  li.addEventListener("click", () => select({ kind: "contact", id: c.contact_id }));
  li.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select({ kind: "contact", id: c.contact_id }); } });
  return li;
}

// An inline HTML (non-map) Lucide glyph for the feed and legend.
function htmlIcon(name, size) {
  const svg = document.createElementNS(SVGNS, "svg");
  svg.setAttribute("width", size); svg.setAttribute("height", size);
  svg.setAttribute("viewBox", "0 0 24 24"); svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor"); svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round"); svg.setAttribute("stroke-linejoin", "round");
  for (const [tag, attrs] of LUCIDE[name] || []) mk(svg, tag, attrs);
  return svg;
}

function renderPayload(container, c) {
  if (c.payload_type === "human_text") {
    const q = document.createElement("div"); q.className = "quote";
    q.textContent = "\"" + (c.payload.text || "") + "\"";
    container.append(q);
  } else if (c.payload_type === "structured_report") {
    const claim = c.payload.claim || {};
    const dl = document.createElement("dl"); dl.className = "fields";
    field(dl, "incident", claim.incident_type);
    if (claim.severity) field(dl, "severity", `${claim.severity.value} (conf ${claim.severity.confidence})`);
    if (claim.headcount) field(dl, "headcount", `${claim.headcount.value} ${claim.headcount.qualifier || ""}`.trim());
    if (claim.source_reliability) field(dl, "reliability", claim.source_reliability);
    if (claim.evidence && claim.evidence.length) field(dl, "evidence", claim.evidence.join(", "));
    if (claim.negations && claim.negations.length) field(dl, "negations", claim.negations.join(", "));
    container.append(dl);
  } else if (c.payload_type === "truck_observation") {
    const p = c.payload;
    const dl = document.createElement("dl"); dl.className = "fields";
    field(dl, "observer", p.observer_id);
    field(dl, "at tick", String(p.tick));
    field(dl, "radius", String(p.radius));
    const obs = (p.buildings || []).map((b) =>
      `${b.building_id}:${b.status}`).join(", ") || "none";
    field(dl, "observed", obs);
    container.append(dl);
  }
  const loc = locText(c);
  if (loc) { const l = document.createElement("div"); l.className = "muted"; l.textContent = loc; container.append(l); }
}

function field(dl, k, v) {
  if (v == null || v === "") return;
  const dt = document.createElement("dt"); dt.textContent = k;
  const dd = document.createElement("dd"); dd.textContent = String(v);
  dl.append(dt, dd);
}

function locText(c) {
  const loc = c.reported_location; if (!loc) return "";
  if (loc.building_id) {
    const bi = S.buildings[loc.building_id];
    return "location: " + loc.building_id + (bi && bi.name ? ` (${bi.name})` : "");
  }
  if (loc.coordinates) return `location: (${round(loc.coordinates.x)}, ${round(loc.coordinates.y)})`;
  return "";
}

// ---- text equivalents -----------------------------------------------------
function markerText(c) {
  const st = srcStyle(c.source_type);
  let base = `${st.label} ${c.contact_id}, occurred ${c.occurred_at} delivered ${c.delivered_at}`;
  const loc = locText(c); if (loc) base += ", " + loc;
  return base;
}
function vehicleText(v) {
  let t = `${v.label}, status ${v.status}, at (${round(v.position.x)}, ${round(v.position.y)})`;
  if (v.route) t += `, ETA ${v.route.eta_ticks} ticks`;
  if (v.incident_id) t += `, incident ${v.incident_id}`;
  return t;
}

// ---- selection + floating details card ------------------------------------
function wireSelect(node, sel) {
  node.addEventListener("click", () => select(sel));
  node.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select(sel); } });
  // Floating details card on hover and on keyboard focus (Escape/blur dismiss).
  node.addEventListener("mouseenter", (e) => showCard(sel, e));
  node.addEventListener("mouseleave", hideCard);
  node.addEventListener("focus", () => showCard(sel, null));
  node.addEventListener("blur", hideCard);
  node.addEventListener("keydown", (e) => { if (e.key === "Escape") hideCard(); });
}
// Fires aren't selectable; hover/focus only surfaces the ETA card (like vehicles/contacts).
function wireFireCard(node, bid) {
  node.style.cursor = "pointer";
  node.addEventListener("mouseenter", (e) => showCard({ kind: "fire", id: bid }, e));
  node.addEventListener("mouseleave", hideCard);
}
function select(sel) {
  S.selection = sel;
  applySelectionStyles();
  if (S.lastValid) renderFeed(S.lastValid);
  // Scroll matching feed item into view for report selection.
  if (sel.kind === "contact") {
    const li = el.feed.querySelector(`.report[data-cid="${cssEsc(sel.id)}"]`);
    if (li) li.scrollIntoView({ block: "nearest" });
  }
}
function validateSelection(snap) {
  if (!S.selection) return;
  const present = S.selection.kind === "vehicle"
    ? (snap.vehicles || []).some((v) => v.vehicle_id === S.selection.id)
    : (snap.contact_history || []).some((c) => c.contact_id === S.selection.id);
  if (!present) S.selection = null;
}
function applySelectionStyles() {
  for (const n of el.mapc.querySelectorAll(".marker, .vehicle")) n.classList.remove("selected");
  if (!S.selection || !S.svg) return;
  const attr = S.selection.kind === "contact" ? "data-cid" : "data-vid";
  const n = el.mapc.querySelector(`[${attr}="${cssEsc(S.selection.id)}"]`);
  if (n) n.classList.add("selected");
}

function showCard(sel, e) {
  if (!S.lastValid) return;
  S.hover = sel;
  el.cardBody.replaceChildren();
  const dl = document.createElement("dl"); dl.className = "kv";
  if (sel.kind === "vehicle") {
    const v = (S.lastValid.vehicles || []).find((x) => x.vehicle_id === sel.id);
    if (!v) return;
    el.cardTitle.textContent = v.label;
    kv(dl, "status", v.status);
    kv(dl, "position", `(${round(v.position.x)}, ${round(v.position.y)})`);
    if (v.destination) kv(dl, "destination", `(${round(v.destination.snapped.x)}, ${round(v.destination.snapped.y)})`);
    if (v.route) { kv(dl, "ETA", v.route.eta_ticks + " ticks"); kv(dl, "remaining", round(v.route.remaining)); }
    if (v.incident_id) kv(dl, "incident_id", v.incident_id);
    if (v.last_rationale) kv(dl, "rationale", v.last_rationale);
    el.cardBody.append(dl);
  } else if (sel.kind === "fire") {
    el.cardTitle.textContent = "fire " + sel.id;
    const eta = (S.lastValid.fire_eta || []).find((x) => x.building_id === sel.id);
    if (eta) {
      kv(dl, "ticks to extinguish", eta.ticks_to_extinguish == null ? "--" : eta.ticks_to_extinguish);
      kv(dl, "ticks to collapse", eta.ticks_to_collapse == null ? "--" : eta.ticks_to_collapse);
      kv(dl, "firetrucks", eta.suppressors);
    } else {
      kv(dl, "estimate", "no truck in view");
    }
    el.cardBody.append(dl);
  } else {
    const c = (S.lastValid.contact_history || []).find((x) => x.contact_id === sel.id);
    if (!c) return;
    el.cardTitle.textContent = c.source_type + " " + c.contact_id;
    kv(dl, "occurred", String(c.occurred_at));
    kv(dl, "delivered", String(c.delivered_at));
    const delay = c.delivered_at - c.occurred_at;
    if (delay > 0) kv(dl, "delay", "+" + delay + " ticks");
    const loc = locText(c); if (loc) kv(dl, "location", loc.replace(/^location: /, ""));
    const payloadBox = document.createElement("div");
    renderPayload(payloadBox, c);
    el.cardBody.append(dl, payloadBox);
  }
  el.card.classList.remove("hidden");
  positionCard(sel, e);
}
function positionCard(sel, e) {
  const wrap = el.mapwrap.getBoundingClientRect();
  let x, y;
  if (e) { x = e.clientX - wrap.left + 14; y = e.clientY - wrap.top + 14; }
  else {
    const attr = sel.kind === "contact" ? "data-cid" : "data-vid";
    const n = el.mapc.querySelector(`[${attr}="${cssEsc(sel.id)}"]`);
    const r = n ? n.getBoundingClientRect() : null;
    if (r) { x = r.right - wrap.left + 10; y = r.top - wrap.top; }
    else { x = 20; y = 20; }
  }
  const cw = el.card.offsetWidth, ch = el.card.offsetHeight;
  x = clamp(x, 6, Math.max(6, wrap.width - cw - 6));
  y = clamp(y, 6, Math.max(6, wrap.height - ch - 6));
  el.card.style.left = x + "px";
  el.card.style.top = y + "px";
}
function hideCard() { S.hover = null; el.card.classList.add("hidden"); }
function kv(dl, k, v) {
  const dt = document.createElement("dt"); dt.textContent = k;
  const dd = document.createElement("dd"); dd.textContent = String(v);
  dl.append(dt, dd);
}

// ---- aria-live announcements ---------------------------------------------
function announce(snap) {
  const msgs = [];
  if (snap.lifecycle !== S.prevLifecycle) {
    let m = "Lifecycle " + snap.lifecycle;
    if (snap.lifecycle === "terminal" && snap.terminal_reason) m += ": " + snap.terminal_reason;
    msgs.push(m);
  }
  const n = (snap.new_contacts || []).length;
  if (n) msgs.push(n + (n === 1 ? " new report" : " new reports"));
  if (msgs.length) el.live.textContent = msgs.join(". ");
}

// ---- helpers --------------------------------------------------------------
function mk(parent, tag, attrs) {
  const n = document.createElementNS(SVGNS, tag);
  for (const k in attrs) n.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(n);
  return n;
}
function ptsStr(pts) { return pts.map((p) => `${p.x},${p.y}`).join(" "); }
function sameXY(a, b) { return a && b && Math.abs(a.x - b.x) < 0.01 && Math.abs(a.y - b.y) < 0.01; }
function dist2(a, b) { return (a.x - b.x) ** 2 + (a.y - b.y) ** 2; }
function round(n) { return Math.round(n * 10) / 10; }
function cssEsc(s) { return window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/["\\]/g, "\\$&"); }

// ---- legend ---------------------------------------------------------------
function legPin(color, glyph) {
  const svg = document.createElementNS(SVGNS, "svg");
  svg.setAttribute("class", "legpin"); svg.setAttribute("viewBox", "-9 -25 18 26");
  buildPin(svg, color, glyph);
  return svg;
}
function legTruck() {
  const svg = document.createElementNS(SVGNS, "svg");
  // viewBox scales with TRUCK_K so the legend glyph keeps its on-screen size.
  svg.setAttribute("class", "legtruck"); svg.setAttribute("viewBox", "-54 -72 108 144");
  buildTruck(svg, false);
  return svg;
}
function buildLegend() {
  const pins = [
    [CAT.call, "human call"], [CAT.alarm, "auto alarm"],
    [CAT.responder, "responder update"],
  ];
  for (const [cat, text] of pins) {
    const span = document.createElement("span"); span.className = "leg";
    span.append(legPin(cat.color, cat.glyph));
    const t = document.createElement("span"); t.textContent = text;
    span.append(t); el.legend.append(span);
  }
  const truck = document.createElement("span"); truck.className = "leg";
  truck.append(legTruck());
  const tt = document.createElement("span"); tt.textContent = "firetruck (heading)";
  truck.append(tt); el.legend.append(truck);
  const others = [
    { color: "#f97316", glyph: "flame", text: "fire (band = intensity)" },
    { color: "#4ea1ff", glyph: null, text: "committed route" },
    { color: "#b98be0", glyph: null, text: "pending route" },
    { color: "#7cc4ff", glyph: null, text: "water (dousing)" },
  ];
  for (const it of others) {
    const span = document.createElement("span"); span.className = "leg";
    if (it.glyph) { const g = htmlIcon(it.glyph, 14); g.style.color = it.color; span.append(g); }
    else {
      const line = document.createElementNS(SVGNS, "svg");
      line.setAttribute("width", 22); line.setAttribute("height", 10);
      const l = mk(line, "line", { x1: 1, y1: 5, x2: 21, y2: 5, stroke: it.color, "stroke-width": 3 });
      if (it.text === "pending route") l.setAttribute("stroke-dasharray", "5 4");
      if (it.text === "water (dousing)") l.setAttribute("stroke-dasharray", "3 4");
      span.append(line);
    }
    const t = document.createElement("span"); t.textContent = it.text;
    span.append(t); el.legend.append(span);
  }
  // Ever-burned keyline swatch.
  const eb = document.createElement("span"); eb.className = "leg";
  const sv = document.createElementNS(SVGNS, "svg");
  sv.setAttribute("width", 16); sv.setAttribute("height", 16);
  mk(sv, "rect", { x: 2, y: 2, width: 12, height: 12, rx: 2, fill: "none", stroke: "#111", "stroke-width": 2 });
  eb.append(sv);
  const et = document.createElement("span"); et.textContent = "ever on fire";
  eb.append(et); el.legend.append(eb);
}

// ---- boot -----------------------------------------------------------------
el.fHuman.addEventListener("change", () => { S.filters.human = el.fHuman.checked; if (S.lastValid) renderFeed(S.lastValid); });
el.fTruck.addEventListener("change", () => { S.filters.truck = el.fTruck.checked; if (S.lastValid) renderFeed(S.lastValid); });
el.fullFlag.title = "Full state: this display is revealing hidden ground truth -- real building " +
  "status, occupancy, and active fires that players cannot normally see. Click to hide or show it here.";
el.fullFlag.addEventListener("click", () => {
  dismissTruthHint();
  S.truthHidden = !S.truthHidden;
  applyTruthVisibility();
});
el.mapc.addEventListener("wheel", onWheel, { passive: false });
el.mapc.addEventListener("pointerdown", onPointerDown);
el.mapc.addEventListener("pointermove", onPointerMove);
el.mapc.addEventListener("pointerup", onPointerUp);
el.mapc.addEventListener("pointercancel", onPointerUp);
window.addEventListener("keydown", (e) => {
  if (!S.svg) return;
  const r = el.mapc.getBoundingClientRect();
  if (e.key === "+" || e.key === "=") zoomAt(r.width / 2, r.height / 2, 1.2);
  else if (e.key === "-" || e.key === "_") zoomAt(r.width / 2, r.height / 2, 1 / 1.2);
  else if (e.key === "0") resetView();
});
// Motion override: a projector is often driven by a machine with "reduce
// motion" set system-wide, which would silently kill the animations this
// display uses to convey state. Load once with ?motion=force to override it
// (?motion=auto to hand control back); the choice sticks, like uiscale.
const motionPref = new URLSearchParams(location.search).get("motion");
if (motionPref) localStorage.setItem("motion", motionPref);
document.documentElement.classList.toggle(
  "force-motion", localStorage.getItem("motion") === "force");

// UI scale: user-controlled multiplier on the counter-scaled overlay (icons + labels).
function setUiScale(v) {
  document.documentElement.style.setProperty("--uiscale", String(v));
  localStorage.setItem("uiscale", String(v));
}
setUiScale(localStorage.getItem("uiscale") || "1");
if (el.uiscale) {
  el.uiscale.value = localStorage.getItem("uiscale") || "1";
  el.uiscale.addEventListener("input", () => setUiScale(el.uiscale.value));
}

buildLegend();
poll();
setInterval(poll, POLL_MS);
