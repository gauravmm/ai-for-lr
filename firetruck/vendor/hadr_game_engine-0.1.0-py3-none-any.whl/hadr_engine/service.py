"""GameService: the one authoritative, transport-neutral application facade.

All mutation enters here under a single asyncio.Lock and follows the six-step
shape from ENGINE.md: validate controller/lifecycle/expected_tick -> compute the
new immutable state via domain functions -> append to the run log -> publish in
memory -> store the redacted display snapshot -> return. Display polling reads
the stored snapshot and never takes the lock.

Redaction is structural: control results are built from the public schemas
(schemas.py), which have no field for hidden truth. Run-log tick records carry
the full post-tick state including hidden truth, which makes the log the debug
interface. Errors are EngineError with stable codes from the API.md catalogue.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

from . import catalogue, schemas
from .domain import rng, tick
from .domain.contacts import public_contact_ids
from .domain.model import Contact, EpisodeState, Lifecycle
from .domain.scenario import Scenario, ScenarioError
from .errors import EngineError, ErrorCode
from .maps.repository import Map
from .maps.routing import RoutingError
from .persistence import runlog
from .session import ControllerLease
from .transports import display

log = logging.getLogger("hadr_engine.service")

_PUBLIC_EVENT_TYPES = frozenset({"order_applied", "movement", "arrival"})


@dataclass
class _Episode:
    state: EpisodeState
    scenario: Scenario
    map_: Map
    raw: dict
    run_log: runlog.RunLog
    controller_id: str
    contact_history: list[Contact] = field(default_factory=list)
    seen_contacts: set = field(default_factory=set)


def _zero_tokens() -> dict:
    """A fresh scoreboard: both roles at zero, matching schemas.TokenReport."""
    return {"intake": {"read": 0, "write": 0, "cache_read": 0},
            "dispatch": {"read": 0, "write": 0, "cache_read": 0}}


def _restart_reveal(records: list[dict]) -> dict:
    ticks = [r for r in records if r.get("type") == "tick"]
    if not ticks:
        return {}
    st = ticks[-1].get("state", {})
    return {
        "reveal": {"buildings": st.get("buildings"), "fires": st.get("fires")},
        "metrics": {"casualties": st.get("casualties"),
                    "buildings_lost": st.get("buildings_lost"), "tokens": None},
    }


class GameService:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._lease = ControllerLease()
        self._episode: _Episode | None = None
        self._display_revision = 0
        self._run_seq = 0
        self._snapshot: dict = {}
        # Participant-reported token totals for the display scoreboard, split by
        # role. The engine measures nothing: it stores what next_tick carries and
        # echoes it back. It does reach the run log, because a tick record embeds
        # the whole display snapshot - so a run log carries the per-tick
        # self-reported totals. It never reaches `outcome.tokens`, which stays
        # null, and the agent can never read it back. Reset when an episode starts.
        self._tokens: dict = _zero_tokens()
        # Startup: finalize any interrupted run log before accepting a controller.
        finalized = runlog.finalize_unfinalized_logs(_restart_reveal)
        for run_id in finalized:
            log.info("recovery: finalized interrupted run as process_restart run_id=%s", run_id)
        self._store_lobby()

    # ------------------------------------------------------------- snapshots

    # The display keeps the last frame (usually the terminal reveal) after the
    # controller disconnects; the lobby appears only before the first episode.
    def _store_lobby(self) -> None:
        self._display_revision += 1
        self._snapshot = display.lobby_snapshot(self._display_revision)
        self._snapshot["tokens"] = self._tokens

    def _store_snapshot(self, ep: _Episode) -> None:
        self._display_revision += 1
        self._snapshot = display.build_snapshot(
            ep.state, ep.scenario, ep.map_, self._display_revision, ep.contact_history)
        self._snapshot["tokens"] = self._tokens

    def snapshot(self) -> dict:
        """Current poll response. Never takes the mutation lock."""
        return self._snapshot

    # ------------------------------------------------------------- controller

    async def acquire_controller(self, controller_id: str | None = None) -> str:
        """Acquire the lease, displacing any previous holder. Returns the id."""
        async with self._lock:
            cid = controller_id or self._lease.new_controller_id()
            displaced = self._lease.acquire(cid)
            if displaced is not None:
                log.info("controller displaced old=%s new=%s", displaced, cid)
                self._archive("displaced")
            log.info("controller acquired controller_id=%s", cid)
            return cid

    async def release_controller(self, controller_id: str) -> None:
        """Session termination: archive an active run and free the lease."""
        async with self._lock:
            if not self._lease.is_current(controller_id):
                return
            self._archive("disconnected")
            self._lease.release(controller_id)
            log.info("controller released controller_id=%s", controller_id)

    def _check_controller(self, controller_id: str) -> None:
        if not self._lease.is_current(controller_id):
            raise EngineError(ErrorCode.CONTROLLER_DISPLACED,
                              "a newer session holds the controller lease")

    # --------------------------------------------------------------- archive

    def _archive(self, abort_reason: str) -> None:
        ep = self._episode
        if ep is None:
            return
        if not ep.run_log.finalized:
            record = self._terminal_record(ep, outcome="aborted", abort_reason=abort_reason)
            ep.run_log.finalize(record)
            log.info("run archived aborted:%s run_id=%s tick=%s",
                     abort_reason, ep.state.run_id, ep.state.current_tick)
        self._episode = None

    # ----------------------------------------------------------- run records

    def _header_record(self, ep: _Episode, effective_seed: int) -> dict:
        scenario = ep.scenario
        map_json, _svg, _manifest = _load_map_artifact(scenario.map_id)
        return {
            "type": "header",
            "run_id": ep.state.run_id,
            "scenario_id": scenario.scenario_id,
            "map_id": scenario.map_id,
            "engine_revision": tick.ENGINE_REVISION,
            "api_version": schemas.API_VERSION,
            "schema_revision": scenario.schema_version,
            "rng_revision": rng.RNG_REVISION,
            "artifact_hashes": {
                "scenario": runlog.sha256_text(runlog.canonical_dumps(ep.raw)),
                "map": runlog.sha256_text(runlog.canonical_dumps(map_json)),
            },
            "settings": runlog.to_jsonable(scenario.settings),
            "seed": effective_seed,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

    def _tick_record(self, ep: _Episode, events, applied) -> dict:
        return {
            "type": "tick",
            "run_id": ep.state.run_id,
            "tick": ep.state.current_tick,
            "state": runlog.to_jsonable(ep.state),
            "events": [runlog.to_jsonable(e) for e in events],
            "effective_commands": [runlog.to_jsonable(c) for c in applied],
            "display": self._snapshot,
        }

    def _terminal_record(self, ep: _Episode, outcome: str,
                         abort_reason: str | None = None) -> dict:
        state = ep.state
        # Public (materialized) location + render trace by contact for the reveal.
        # state.human_contacts carry opaque public ids; join via the authored->public map.
        public = {c.contact_id: c for c in state.human_contacts}
        pub_ids = public_contact_ids(ep.scenario.human_contacts)

        def _claim_entry(c):
            pc = public.get(pub_ids[c.contact_id])
            return {
                "contact_id": c.contact_id,
                "public_contact_id": pub_ids[c.contact_id],
                "source_type": c.source_type,
                "base_reported_location": runlog.to_jsonable(c.reported_location),
                "public_reported_location": (
                    runlog.to_jsonable(pc.reported_location) if pc else None),
                "location_perturbation": c.location_perturbation,
                "red_herring": c.red_herring,
                "claim": runlog.to_jsonable(c.claim),
                "render_trace": getattr(pc.payload, "trace", None) if pc else None,
            }

        reveal = {
            "buildings": [runlog.to_jsonable(b) for b in state.buildings],
            "fires": [runlog.to_jsonable(f) for f in state.fires],
            "canonical_claims": [_claim_entry(c) for c in ep.scenario.human_contacts],
        }
        record: dict[str, object] = {
            "type": "terminal",
            "run_id": state.run_id,
            "tick": state.current_tick,
            "outcome": outcome,
            "reveal": reveal,
            "metrics": {"casualties": state.casualties,
                        "buildings_lost": state.buildings_lost, "tokens": None},
        }
        if outcome == "terminal":
            record["terminal_reason"] = (
                state.terminal_reason.value if state.terminal_reason else None)
        else:
            record["abort_reason"] = abort_reason
        return record

    # ---------------------------------------------------- contact accounting

    def _record_new_contacts(self, ep: _Episode) -> None:
        for c in ep.state.observation.contacts:
            if c.contact_id not in ep.seen_contacts:
                ep.seen_contacts.add(c.contact_id)
                ep.contact_history.append(c)

    # --------------------------------------------------------------- helpers

    def _require_run(self, terminal_ok: bool = False) -> _Episode:
        ep = self._episode
        if ep is None:
            raise EngineError(ErrorCode.EPISODE_NOT_RUNNING, "no episode is running")
        if ep.state.lifecycle == Lifecycle.RUNNING:
            return ep
        if terminal_ok and ep.state.lifecycle == Lifecycle.TERMINAL:
            return ep
        raise EngineError(ErrorCode.EPISODE_NOT_RUNNING,
                          f"episode is {ep.state.lifecycle.value}, not running")

    def _base_fields(self) -> dict:
        ep = self._episode
        if ep is None:
            return {"lifecycle": Lifecycle.LOBBY.value, "run_id": None, "tick": None}
        return {"lifecycle": ep.state.lifecycle.value, "run_id": ep.state.run_id,
                "tick": ep.state.current_tick}

    # ------------------------------------------------------------ operations

    async def list_scenarios(self, controller_id: str) -> schemas.ListScenariosResult:
        async with self._lock:
            self._check_controller(controller_id)
            entries = [schemas.ScenarioCatalogueEntry(**e) for e in catalogue.public_entries()]
            return schemas.ListScenariosResult(scenarios=entries, **self._base_fields())

    async def start_episode(self, controller_id: str,
                            req: schemas.StartEpisodeRequest) -> schemas.StartEpisodeResult:
        async with self._lock:
            self._check_controller(controller_id)
            # 1. validate: load and validate the scenario artifact.
            try:
                scenario, map_, raw = catalogue.load(req.scenario_id)
            except (FileNotFoundError, KeyError):
                raise EngineError(ErrorCode.INVALID_REQUEST,
                                  f"unknown scenario {req.scenario_id!r}") from None
            except ScenarioError as exc:
                raise EngineError(ErrorCode.DATA_INVALID,
                                  "packaged scenario failed validation",
                                  {"detail": str(exc)}) from None

            # A live run is archived as replaced before the new one starts.
            if self._episode is not None and not self._episode.run_log.finalized:
                self._archive("replaced")

            effective_seed = scenario.default_seed if req.seed is None else req.seed
            self._run_seq += 1
            run_id = f"run-{self._run_seq:04d}-{self._lease.new_controller_id()[5:13]}"

            # 2. compute the tick-0 immutable state.
            state = tick.create_episode(scenario, map_, run_id, seed=effective_seed)
            ep = _Episode(state=state, scenario=scenario, map_=map_, raw=raw,
                          run_log=runlog.RunLog.create(run_id), controller_id=controller_id)

            # 3. append: header + tick-0 record.
            self._tokens = _zero_tokens()  # new run, new scoreboard
            ep.run_log.append(self._header_record(ep, effective_seed))
            self._episode = ep  # publish early so snapshot builders see it
            self._record_new_contacts(ep)
            self._store_snapshot(ep)
            ep.run_log.append(self._tick_record(ep, events=[], applied=[]))
            ep.run_log.flush()

            log.info("episode started run_id=%s scenario=%s seed=%s tick=0",
                     run_id, scenario.scenario_id, effective_seed)

            if state.lifecycle == Lifecycle.TERMINAL:
                # A scenario with no fires resolves at tick 0.
                self._finalize_terminal(ep)
            return schemas.StartEpisodeResult(
                observation=schemas.ObservationPublic.of(state.observation,
                                                         scenario.settings.truck_speed),
                **self._base_fields())

    async def status(self, controller_id: str) -> schemas.StatusResult:
        async with self._lock:
            self._check_controller(controller_id)
            ep = self._episode
            if ep is None:
                return schemas.StatusResult(**self._base_fields())
            state = ep.state
            speed = ep.scenario.settings.truck_speed
            observation = None
            outcome = None
            if state.lifecycle in (Lifecycle.RUNNING, Lifecycle.TERMINAL):
                observation = schemas.ObservationPublic.of(state.observation, speed)
            if state.lifecycle == Lifecycle.TERMINAL:
                outcome = schemas.TerminalOutcome.of(state)
            return schemas.StatusResult(
                scenario_id=state.scenario_id,
                map_id=ep.scenario.map_id,
                tick_limit=state.tick_limit,
                terminal_reason=state.terminal_reason.value if state.terminal_reason else None,
                observation=observation,
                pending=[schemas.PendingCommandSummary.of(c, speed) for c in state.pending],
                outcome=outcome,
                **self._base_fields())

    async def building_to_coords(
        self, controller_id: str, req: schemas.BuildingToCoordsRequest
    ) -> schemas.BuildingToCoordsResult:
        async with self._lock:
            self._check_controller(controller_id)
            ep = self._require_run(terminal_ok=True)
            if not ep.map_.has_building(req.building_id):
                raise EngineError(ErrorCode.UNKNOWN_BUILDING,
                                  f"unknown building {req.building_id!r}")
            point = ep.map_.building_to_coords(req.building_id)
            return schemas.BuildingToCoordsResult(
                building_id=req.building_id, point=schemas.PointModel.of(point),
                **self._base_fields())

    async def travel_time(self, controller_id: str,
                          req: schemas.TravelTimeRequest) -> schemas.TravelTimeResult:
        async with self._lock:
            self._check_controller(controller_id)
            ep = self._require_run(terminal_ok=True)
            src = self._resolve_endpoint(ep, req.from_)
            dst = self._resolve_endpoint(ep, req.to)
            route = self._route_or_error(ep, src, dst)
            summary = schemas.RouteSummary.of(route, ep.scenario.settings.truck_speed)
            return schemas.TravelTimeResult(
                distance=route.total, eta_ticks=summary.eta_ticks, edges=summary.edges,
                polyline=summary.polyline, **self._base_fields())

    async def dispatch(self, controller_id: str,
                       req: schemas.DispatchRequest) -> schemas.DispatchResult:
        async with self._lock:
            self._check_controller(controller_id)
            ep = self._require_run()
            state = ep.state
            if state.current_tick != req.expected_tick:
                raise EngineError(ErrorCode.TICK_MISMATCH,
                                  "expected_tick does not match current tick",
                                  {"current_tick": state.current_tick})
            if not any(v.vehicle_id == req.vehicle_id for v in state.vehicles):
                self._log_rejected(ep, req, ErrorCode.UNKNOWN_VEHICLE)
                raise EngineError(ErrorCode.UNKNOWN_VEHICLE,
                                  f"unknown vehicle {req.vehicle_id!r}")

            requested = _point(req.destination)
            self._validate_destination(ep, requested)
            self._route_or_error(ep, state.vehicle(req.vehicle_id).position, requested)

            prior = [c.command_id for c in state.pending if c.vehicle_id == req.vehicle_id]
            try:
                new_state, command = tick.queue_command(
                    state, ep.scenario, ep.map_, req.vehicle_id, requested,
                    req.incident_id, req.rationale)
            except tick.CommandError as exc:
                self._log_rejected(ep, req, ErrorCode.COMMAND_REJECTED, str(exc))
                raise EngineError(ErrorCode.COMMAND_REJECTED, "dispatch rejected") from None

            ep.state = new_state
            speed = ep.scenario.settings.truck_speed
            ep.run_log.append({
                "type": "command",
                "run_id": new_state.run_id,
                "tick": new_state.current_tick,
                "command_id": command.command_id,
                "vehicle_id": command.vehicle_id,
                "incident_id": command.incident_id,
                "rationale": command.rationale,
                "requested": runlog.to_jsonable(command.destination.requested),
                "snapped": runlog.to_jsonable(command.destination.snapped),
                "status": "accepted",
                "superseded": prior,
            })
            self._store_snapshot(ep)
            ep.run_log.flush()
            log.info("dispatch accepted run_id=%s tick=%s command_id=%s vehicle=%s",
                     new_state.run_id, new_state.current_tick, command.command_id,
                     command.vehicle_id)
            return schemas.DispatchResult(
                accepted=True,
                command=schemas.DispatchCommand(
                    command_id=command.command_id, vehicle_id=command.vehicle_id,
                    incident_id=command.incident_id, rationale=command.rationale,
                    requested=schemas.PointModel.of(command.destination.requested),
                    snapped=schemas.PointModel.of(command.destination.snapped),
                    route=schemas.RouteSummary.of(command.route, speed)),
                pending=[schemas.PendingCommandSummary.of(c, speed) for c in new_state.pending],
                superseded=prior,
                **self._base_fields())

    async def end_tick(self, controller_id: str,
                       req: schemas.EndTickRequest) -> schemas.EndTickResult:
        async with self._lock:
            self._check_controller(controller_id)
            ep = self._require_run()
            state = ep.state
            if state.current_tick != req.expected_tick:
                # Stale/future tick: never advance; return the current tick.
                raise EngineError(ErrorCode.TICK_MISMATCH,
                                  "expected_tick does not match current tick",
                                  {"current_tick": state.current_tick})

            applied = list(state.pending)
            new_state, events = tick.end_tick(state, ep.scenario, ep.map_, req.expected_tick)
            ep.state = new_state
            self._record_new_contacts(ep)
            # Stored before the snapshot so the tick record carries the totals
            # the runner reported for the tick it just finished.
            if req.tokens is not None:
                self._tokens = req.tokens.model_dump()
            self._store_snapshot(ep)
            ep.run_log.append(self._tick_record(ep, events, applied))
            ep.run_log.flush()

            speed = ep.scenario.settings.truck_speed
            log.info("tick committed run_id=%s tick=%s->%s lifecycle=%s",
                     new_state.run_id, req.expected_tick, new_state.current_tick,
                     new_state.lifecycle.value)

            outcome = None
            if new_state.lifecycle == Lifecycle.TERMINAL:
                outcome = schemas.TerminalOutcome.of(new_state)
                self._finalize_terminal(ep)

            return schemas.EndTickResult(
                committed_commands=[schemas.PendingCommandSummary.of(c, speed) for c in applied],
                events=self._public_events(events),
                observation=schemas.ObservationPublic.of(new_state.observation, speed),
                terminal_reason=(
                    new_state.terminal_reason.value if new_state.terminal_reason else None),
                outcome=outcome,
                **self._base_fields())

    # ----------------------------------------------------------- internals

    def _finalize_terminal(self, ep: _Episode) -> None:
        if ep.run_log.finalized:
            return
        record = self._terminal_record(ep, outcome="terminal")
        ep.run_log.finalize(record)
        log.info("terminal run_id=%s reason=%s casualties=%s buildings_lost=%s",
                 ep.state.run_id,
                 ep.state.terminal_reason.value if ep.state.terminal_reason else None,
                 ep.state.casualties, ep.state.buildings_lost)

    def _public_events(self, events) -> list[schemas.PublicEventModel]:
        out = []
        for e in events:
            if e.type in _PUBLIC_EVENT_TYPES:
                out.append(
                    schemas.PublicEventModel(type=e.type, vehicle_id=e.data.get("vehicle_id")))
        return out

    def _resolve_endpoint(self, ep: _Episode, endpoint: schemas.TravelEndpoint):
        if endpoint.vehicle_id is not None:
            try:
                return ep.state.vehicle(endpoint.vehicle_id).position
            except KeyError:
                raise EngineError(ErrorCode.UNKNOWN_VEHICLE,
                                  f"unknown vehicle {endpoint.vehicle_id!r}") from None
        # TravelEndpoint validates exactly one of vehicle_id/point
        assert endpoint.point is not None
        return _point(endpoint.point)

    def _validate_destination(self, ep: _Episode, dst) -> None:
        if not ep.map_.in_world_bounds(dst):
            raise EngineError(ErrorCode.INVALID_DESTINATION,
                              "destination is outside the map world bounds")
        if ep.map_.snap_distance(dst) > ep.map_.snap_bound:
            raise EngineError(ErrorCode.INVALID_DESTINATION,
                              "destination is beyond the snap distance")

    def _route_or_error(self, ep: _Episode, src, dst):
        self._validate_destination(ep, dst)
        try:
            return ep.map_.route(src, dst)
        except RoutingError:
            raise EngineError(ErrorCode.NO_ROUTE,
                              "no route between the endpoints") from None

    def _log_rejected(self, ep: _Episode, req: schemas.DispatchRequest,
                      code: ErrorCode, reason: str = "") -> None:
        ep.run_log.append({
            "type": "command",
            "run_id": ep.state.run_id,
            "tick": ep.state.current_tick,
            "vehicle_id": req.vehicle_id,
            "incident_id": req.incident_id,
            "status": "rejected",
            "code": code.value,
            "reason": reason[:200],
        })
        ep.run_log.flush()


def _point(pm: schemas.PointModel):
    from .domain.model import Point
    return Point(pm.x, pm.y)


def _load_map_artifact(map_id: str):
    from .maps import import_map
    return import_map.load_packaged_map(map_id)
