"""Packaged scenario catalogue: load and validate scenario artifacts.

Scenarios live in `hadr_engine/data/scenarios/*.json` and load through the
scenario module against their referenced packaged map. The public catalogue
projection excludes truth events, occupants, contact labels, and tuning
internals.
"""
from __future__ import annotations

import json
from functools import cache
from importlib import resources

from .domain.scenario import Scenario, load_scenario
from .maps.repository import Map


def scenario_ids() -> list[str]:
    root = resources.files("hadr_engine.data.scenarios")
    return sorted(p.name[:-5] for p in root.iterdir()
                  if p.name.endswith(".json"))


def load_raw(scenario_id: str) -> dict:
    root = resources.files("hadr_engine.data.scenarios")
    return json.loads(root.joinpath(f"{scenario_id}.json").read_text())


@cache
def _map_cached(map_id: str) -> Map:
    return Map.load(map_id)


def load(scenario_id: str) -> tuple[Scenario, Map, dict]:
    """Return the validated scenario, its map, and the raw scenario dict."""
    raw = load_raw(scenario_id)
    map_ = _map_cached(raw["map_id"])
    scenario = load_scenario(raw, map_)
    return scenario, map_, raw


def public_entries() -> list[dict]:
    entries = []
    for sid in scenario_ids():
        scenario, _map, _raw = load(sid)
        entries.append({
            "scenario_id": scenario.scenario_id,
            "title": scenario.title,
            "difficulty_stage": scenario.difficulty_stage,
            "map_id": scenario.map_id,
            "tick_limit": scenario.tick_limit,
            "default_seed": scenario.default_seed,
            "public_description": scenario.public_description,
        })
    return entries
