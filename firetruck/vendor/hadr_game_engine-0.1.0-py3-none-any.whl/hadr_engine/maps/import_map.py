"""Build-time map importer and packaged-data validator.

Takes a shortlisted mapgen SVG/JSON pair plus a hand-authored enrichment
manifest, validates them against the rules in spec/engine/MAPS.md, sanitizes
the SVG for the browser, and writes the packaged map.json/display.svg/
manifest.json triple. The same validation runs over already-packaged data.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import xml.etree.ElementTree as ET
from importlib import resources
from pathlib import Path
from typing import Any

from shapely.geometry import Point, Polygon

from .routing import MapEngine

SVG_NS = "http://www.w3.org/2000/svg"
SVG = f"{{{SVG_NS}}}"
METADATA_ID = "mapgen-data"
OVERLAY_ID = "mapgen-graph"

# World-unit tolerances (documented per MAPS.md).
SNAP_TOLERANCE = 40.0  # max distance a public point may sit from a routable edge
LOT_TOLERANCE = 1.5    # slack allowed when testing a point lies in its lot

BUILDING_ID_RE = re.compile(r"^l[0-9]+$")


class ValidationError(Exception):
    """Raised with one or more actionable validation problems."""

    def __init__(self, problems: list[str]):
        self.problems = problems
        super().__init__("; ".join(problems))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_alias(alias: str) -> str:
    return re.sub(r"\s+", " ", alias.strip().lower())


def _water_polygons(map_json: dict[str, Any]) -> list[Polygon]:
    polys: list[Polygon] = []
    water = map_json.get("water") or {}
    rings: list[list] = []
    for key in ("sea", "river", "secondaryRiver"):
        v = water.get(key)
        if isinstance(v, list) and v and isinstance(v[0], list) and not isinstance(v[0][0], list):
            rings.append(v)
    for key in ("rivers", "secondaryRivers"):
        v = water.get(key)
        if isinstance(v, list):
            for ring in v:
                if isinstance(ring, list) and ring and isinstance(ring[0], list):
                    rings.append(ring)
    for ring in rings:
        if len(ring) >= 4:
            try:
                p = Polygon(ring)
                if not p.is_valid:
                    p = p.buffer(0)
                if not p.is_empty and p.area > 0:
                    polys.append(p)
            except Exception:
                pass
    return polys


def _svg_root(svg_text: str) -> ET.Element:
    return ET.fromstring(svg_text)


def _svg_dimensions(root: ET.Element) -> tuple[float | None, float | None, tuple | None]:
    def num(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return None
    w = num(root.get("width"))
    h = num(root.get("height"))
    vb = root.get("viewBox")
    box = None
    if vb:
        parts = vb.replace(",", " ").split()
        if len(parts) == 4:
            try:
                box = tuple(float(p) for p in parts)
            except ValueError:
                box = None
    return w, h, box


def embedded_metadata(svg_text: str) -> dict[str, Any] | None:
    for _ev, el in ET.iterparse(_StringSource(svg_text), events=("end",)):
        if el.tag == f"{SVG}metadata" and el.get("id") == METADATA_ID and el.text:
            return json.loads(el.text)
    return None


class _StringSource:
    """Minimal file-like wrapper so ET.iterparse can read an in-memory string."""

    def __init__(self, text: str):
        self._data = text.encode("utf-8")
        self._pos = 0

    def read(self, n: int = -1) -> bytes:
        if n is None or n < 0:
            chunk = self._data[self._pos:]
            self._pos = len(self._data)
            return chunk
        chunk = self._data[self._pos:self._pos + n]
        self._pos += len(chunk)
        return chunk


_EXTERNAL_URL_RE = re.compile(r"(?i)\b(?:https?:|ftp:|javascript:|data:)")
_ACTIVE_TAGS = {"script", "foreignObject", "a", "animate", "animateTransform",
                "animateMotion", "set", "use"}
# Active content that a curated mapgen SVG must not carry; its presence is
# treated as corruption/tampering and rejected rather than silently stripped.
_REJECT_TAGS = {"script", "foreignObject"}


def active_content_problems(svg_text: str) -> list[str]:
    """Report unsupported active content in a source SVG (empty means clean)."""
    problems: list[str] = []
    try:
        root = _svg_root(svg_text)
    except ET.ParseError as exc:
        return [f"could not parse SVG: {exc}"]
    for el in root.iter():
        name = el.tag.split("}", 1)[-1]
        if name in _REJECT_TAGS:
            problems.append(f"SVG contains unsupported active element <{name}>")
        for attr, value in el.attrib.items():
            aname = attr.split("}", 1)[-1]
            if aname.lower().startswith("on"):
                problems.append(f"SVG contains event-handler attribute {aname}")
            elif (
                aname == "href" or attr == "{http://www.w3.org/1999/xlink}href"
            ) and _EXTERNAL_URL_RE.search(value):
                problems.append(f"SVG contains active/external link {value[:40]!r}")
    return problems


def sanitize_svg(svg_text: str) -> str:
    """Produce a display SVG with no active content or embedded map metadata."""
    ET.register_namespace("", SVG_NS)
    root = _svg_root(svg_text)

    def local(tag: str) -> str:
        return tag.split("}", 1)[-1]

    def clean(el: ET.Element) -> None:
        for child in list(el):
            name = local(child.tag)
            if name in ("metadata",) and child.get("id") == METADATA_ID:
                el.remove(child)
                continue
            if name == "g" and child.get("id") == OVERLAY_ID:
                el.remove(child)
                continue
            if name in _ACTIVE_TAGS:
                el.remove(child)
                continue
            clean(child)
        # Strip event handlers and external references from surviving attributes.
        for attr in list(el.attrib):
            aname = attr.split("}", 1)[-1]
            if (
                aname.lower().startswith("on")
                or aname == "href"
                or attr == "{http://www.w3.org/1999/xlink}href"
                or _EXTERNAL_URL_RE.search(el.attrib.get(attr, ""))
            ):
                del el.attrib[attr]

    clean(root)
    body = ET.tostring(root, encoding="unicode")
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + body


def validate_map(
    map_json: dict[str, Any],
    svg_text: str,
    manifest: dict[str, Any],
    *,
    json_bytes: bytes | None = None,
    svg_bytes: bytes | None = None,
    allow_water_park: bool = False,
    check_source: bool = True,
) -> list[str]:
    """Return a list of validation problems (empty means valid).

    check_source covers the raw-source-only rules (SVG embedded metadata match,
    viewport agreement, source hashes). It is disabled when re-validating
    already-packaged data, whose display SVG is deliberately sanitized.
    """
    problems: list[str] = []

    meta = map_json.get("meta", {})
    if meta.get("format") != 1:
        problems.append(f"meta.format must be 1, got {meta.get('format')!r}")
    for key in ("origin", "zoom", "screen"):
        val = meta.get(key)
        flat = val if isinstance(val, (list, tuple)) else [val]
        if any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in flat):
            problems.append(f"meta.{key} must be finite, got {val!r}")

    graph = map_json.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    node_ids = [n["id"] for n in nodes]
    node_id_set = set(node_ids)
    if len(node_ids) != len(node_id_set):
        problems.append("duplicate graph node ids")

    edge_ids = [e["id"] for e in edges]
    if len(edge_ids) != len(set(edge_ids)):
        problems.append("duplicate graph edge ids")

    lots = map_json.get("lots", [])
    lot_index = {lot["id"]: lot for lot in lots}
    for coll in ("lots", "blocks", "parks"):
        ids = [p["id"] for p in map_json.get(coll, [])]
        if len(ids) != len(set(ids)):
            problems.append(f"duplicate {coll} ids")

    # Edge referential integrity + duplicate unordered endpoint pairs.
    seen_pairs: set[frozenset] = set()
    for e in edges:
        a, b = f"n{e['a']}", f"n{e['b']}"
        if a not in node_id_set or b not in node_id_set:
            problems.append(f"edge {e['id']} references missing node ({a} or {b})")
            continue
        pair = frozenset((a, b))
        if len(pair) == 1:
            problems.append(f"edge {e['id']} is a self-loop")
            continue
        if pair in seen_pairs:
            problems.append(f"duplicate unordered edge endpoint pair for {e['id']}: {a},{b}")
        seen_pairs.add(pair)

    source = manifest.get("source", {})
    if source.get("mapgen_format") != 1:
        problems.append("manifest source.mapgen_format must be 1")

    if check_source:
        problems.extend(active_content_problems(svg_text))

        # SVG embedded metadata must correspond to the supplied JSON, not just filename.
        try:
            embedded = embedded_metadata(svg_text)
        except (ET.ParseError, json.JSONDecodeError) as exc:
            embedded = None
            problems.append(f"could not parse SVG embedded metadata: {exc}")
        if embedded is None:
            problems.append("SVG has no <metadata id=mapgen-data> block")
        elif embedded != map_json:
            problems.append("SVG embedded metadata does not match supplied JSON content")

        # SVG viewport dimensions must agree with JSON screen metadata.
        screen = meta.get("screen")
        if isinstance(screen, (list, tuple)) and len(screen) == 2:
            try:
                root = _svg_root(svg_text)
                w, h, box = _svg_dimensions(root)
                sw, sh = float(screen[0]), float(screen[1])
                if w is not None and abs(w - sw) > 0.5:
                    problems.append(f"SVG width {w} != screen {sw}")
                if h is not None and abs(h - sh) > 0.5:
                    problems.append(f"SVG height {h} != screen {sh}")
                if box is not None and (abs(box[2] - sw) > 0.5 or abs(box[3] - sh) > 0.5):
                    problems.append(f"SVG viewBox {box} disagrees with screen {screen}")
            except ET.ParseError as exc:
                problems.append(f"could not parse SVG: {exc}")

        # Source hashes.
        if json_bytes is not None and source.get("json_sha256") != sha256_bytes(json_bytes):
            problems.append("manifest source.json_sha256 does not match source JSON")
        if svg_bytes is not None and source.get("svg_sha256") != sha256_bytes(svg_bytes):
            problems.append("manifest source.svg_sha256 does not match source SVG")

    # Enrichment buildings. Need routing geometry; build the engine once.
    engine: MapEngine | None = None
    largest: set[str] = set()
    if not any(p.startswith("meta.format") for p in problems):
        try:
            engine = MapEngine(map_json)
            import networkx as nx
            comps = list(nx.connected_components(engine.graph))
            if comps:
                largest = max(comps, key=len)
        except Exception as exc:  # pragma: no cover - defensive
            problems.append(f"could not build routing engine: {exc}")

    water_polys = _water_polygons(map_json) if not allow_water_park else []
    park_polys = (
        [] if allow_water_park else [Polygon(p["polygon"]) for p in map_json.get("parks", [])]
    )

    seen_building_ids: set[str] = set()
    seen_aliases: set[str] = set()
    for b in manifest.get("buildings", []):
        bid = b.get("building_id")
        if not isinstance(bid, str) or not BUILDING_ID_RE.match(bid):
            problems.append(f"building_id {bid!r} must match l<integer>")
            continue
        if bid in seen_building_ids:
            problems.append(f"duplicate building_id {bid}")
        seen_building_ids.add(bid)
        if bid not in lot_index:
            problems.append(f"building_id {bid} has no matching lot polygon")
            continue

        for alias in b.get("aliases", []):
            na = normalize_alias(alias)
            if na in seen_aliases:
                problems.append(f"duplicate normalized alias {na!r}")
            seen_aliases.add(na)

        occ = b.get("occupants")
        if not isinstance(occ, int) or isinstance(occ, bool) or occ < 0:
            problems.append(f"building {bid} occupants must be a nonnegative integer, got {occ!r}")

        pt = b.get("point")
        if not (
            isinstance(pt, dict)
            and isinstance(pt.get("x"), (int, float))
            and isinstance(pt.get("y"), (int, float))
        ):
            problems.append(f"building {bid} point must be {{x, y}}")
            continue
        p = Point(pt["x"], pt["y"])

        lot_poly = Polygon(lot_index[bid]["polygon"])
        if not lot_poly.is_valid:
            lot_poly = lot_poly.buffer(0)
        if not (lot_poly.contains(p) or lot_poly.distance(p) <= LOT_TOLERANCE):
            problems.append(
                f"building {bid} point not inside its lot (dist {lot_poly.distance(p):.2f})")

        if engine is not None:
            eid, _t, dist = engine.nearest_edge((p.x, p.y))
            if dist > SNAP_TOLERANCE:
                problems.append(
                    f"building {bid} point snaps {dist:.1f} > {SNAP_TOLERANCE} from any edge")
            else:
                e = engine.edges[eid]
                if largest and e.a not in largest and e.b not in largest:
                    problems.append(f"building {bid} not on the largest road component")

        if not allow_water_park:
            if any(wp.contains(p) for wp in water_polys):
                problems.append(f"building {bid} point lies in water")
            if any(pp.contains(p) for pp in park_polys):
                problems.append(f"building {bid} point lies in a park")

    for lm in manifest.get("landmarks", []):
        lid = lm.get("id")
        if lid in seen_building_ids:
            problems.append(f"landmark id {lid} collides with a building id")

    return problems


def import_map(source_json: str, source_svg: str, manifest_path: str, out_dir: str) -> Path:
    """Validate the triple and write packaged artifacts to out_dir/<map_id>/."""
    json_bytes = Path(source_json).read_bytes()
    svg_bytes = Path(source_svg).read_bytes()
    manifest = json.loads(Path(manifest_path).read_text())
    map_json = json.loads(json_bytes)
    svg_text = svg_bytes.decode("utf-8")

    problems = validate_map(
        map_json, svg_text, manifest,
        json_bytes=json_bytes, svg_bytes=svg_bytes,
        allow_water_park=bool(manifest.get("allow_water_park")),
    )
    if problems:
        raise ValidationError(problems)

    map_id = manifest["map_id"]
    dest = Path(out_dir) / map_id
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "map.json").write_bytes(json_bytes)
    (dest / "display.svg").write_text(sanitize_svg(svg_text), encoding="utf-8")
    (dest / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return dest


def _maps_root():
    return resources.files("hadr_engine") / "data" / "maps"


def packaged_map_ids() -> list[str]:
    root = _maps_root()
    ids = [entry.name for entry in root.iterdir() if entry.is_dir()]
    return sorted(ids)


def load_packaged_map(map_id: str) -> tuple[dict[str, Any], str, dict[str, Any]]:
    root = _maps_root() / map_id
    map_json = json.loads((root / "map.json").read_text(encoding="utf-8"))
    svg_text = (root / "display.svg").read_text(encoding="utf-8")
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    return map_json, svg_text, manifest


def validate_packaged_data() -> dict[str, list[str]]:
    """Validate every packaged map. Returns map_id -> problems (empty = ok).

    Packaged display SVGs are sanitized, so embedded-metadata and source-hash
    checks that only apply to raw source inputs are skipped here; geometry,
    referential integrity, and enrichment rules are fully re-checked.
    """
    report: dict[str, list[str]] = {}
    for map_id in packaged_map_ids():
        map_json, svg_text, manifest = load_packaged_map(map_id)
        report[map_id] = validate_map(map_json, svg_text, manifest, check_source=False)
    return report
