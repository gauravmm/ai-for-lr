"""MapEngine: routable graph over instrumented MapGenerator exports.

The single runtime source of truth for routing, over instrumented MapGenerator
(ProbableTrain fork) exports; the engine wheel carries no repository dependency.

The exported JSON (embedded in the SVG as <metadata id="mapgen-data">, or
standalone) contains a world-space road graph noded at every intersection,
with stable ids shared with the SVG overlay: nodes n{i}, edges e{i},
blocks b{i}, lots l{i}, parks p{i}, roads r-{cls}-{i}.

Route endpoints ("specs") may be:
  - a node id            "n123"
  - an edge id           "e45"     (enters the edge at its midpoint)
  - a block/lot/park id  "b67"     (snaps the polygon centroid to the nearest edge)
  - a world-space point  (x, y)    (snaps to the nearest edge)

Routes are returned as ordered id lists so the UI can highlight them via the
SVG overlay elements of the same ids.
"""
from __future__ import annotations

import itertools
import json
import math
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from typing import Any

import networkx as nx
from shapely.geometry import LineString, Point, Polygon
from shapely.strtree import STRtree

SVG_NS = "{http://www.w3.org/2000/svg}"
METADATA_ID = "mapgen-data"

ROAD_CLASSES = ("main", "major", "minor", "coast")

PointLike = tuple[float, float]
Spec = str | PointLike


class RoutingError(Exception):
    """Raised when a route cannot be computed (bad spec or no path)."""


@dataclass
class Edge:
    id: str
    a: str  # node id
    b: str  # node id
    cls: str
    road: str  # parent road (streamline) id
    length: float  # world units


@dataclass
class RouteResult:
    src: str
    dst: str
    edges: list[str]  # ordered real edge ids (match SVG overlay)
    nodes: list[str]  # ordered real node ids
    length: float  # geometric length travelled, world units (incl. partial end segments)
    cost: float  # weighted cost (class factors applied)
    coords: list[PointLike] | None = None  # world-space polyline, if requested

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if self.coords is None:
            d.pop("coords")
        return d


class MapEngine:
    def __init__(self, data: dict[str, Any], class_factors: dict[str, float] | None = None):
        fmt = data.get("meta", {}).get("format")
        if fmt != 1:
            raise ValueError(f"unsupported map format: {fmt!r} (expected 1)")
        self.data = data
        self.meta = data["meta"]

        self.class_factors: dict[str, float] = dict.fromkeys(ROAD_CLASSES, 1.0)
        if class_factors:
            unknown = set(class_factors) - set(ROAD_CLASSES)
            if unknown:
                raise ValueError(f"unknown road classes in class_factors: {unknown}")
            self.class_factors.update(class_factors)
        self._min_factor = min(self.class_factors.values())

        # Nodes / edges
        self.nodes: dict[str, PointLike] = {
            n["id"]: (n["pos"][0], n["pos"][1]) for n in data["graph"]["nodes"]
        }
        self.edges: dict[str, Edge] = {}
        self.graph = nx.Graph()
        for nid, (x, y) in self.nodes.items():
            self.graph.add_node(nid, pos=(x, y))
        for e in data["graph"]["edges"]:
            edge = Edge(id=e["id"], a=f"n{e['a']}", b=f"n{e['b']}", cls=e["cls"],
                        road=e["road"], length=e["length"])
            self.edges[e["id"]] = edge
            self.graph.add_edge(
                edge.a, edge.b, id=edge.id, cls=edge.cls, road=edge.road,
                length=edge.length, weight=edge.length * self.class_factors[edge.cls],
            )

        # Roads (classed centerlines)
        self.roads: dict[str, tuple[str, LineString]] = {}
        for cls, roads in data["roads"].items():
            for r in roads:
                self.roads[r["id"]] = (cls, LineString(r["points"]))

        # Polygons
        self.blocks = {b["id"]: Polygon(b["polygon"]) for b in data.get("blocks", [])}
        self.lots = {lot["id"]: Polygon(lot["polygon"]) for lot in data.get("lots", [])}
        self.parks = {p["id"]: Polygon(p["polygon"]) for p in data.get("parks", [])}
        self.water = data.get("water", {})

        # Spatial index (shapely 2: tree result is the index into the input list)
        self._edge_ids: list[str] = list(self.edges)
        self._edge_lines: list[LineString] = [
            LineString([self.nodes[e.a], self.nodes[e.b]]) for e in self.edges.values()
        ]
        self._edge_tree = STRtree(self._edge_lines) if self._edge_ids else None
        self._snap_polygons: dict[str, Polygon] = {**self.blocks, **self.lots, **self.parks}

    @classmethod
    def from_json(cls, path: str, **kwargs) -> MapEngine:
        with open(path) as f:
            return cls(json.load(f), **kwargs)

    @classmethod
    def from_svg(cls, path: str, **kwargs) -> MapEngine:
        """Load from an instrumented SVG (JSON in <metadata id="mapgen-data">)."""
        for _event, el in ET.iterparse(path, events=("end",)):
            if el.tag == f"{SVG_NS}metadata" and el.get("id") == METADATA_ID:
                if not el.text:
                    raise ValueError(f"empty <metadata id=\"{METADATA_ID}\"> in {path}")
                return cls(json.loads(el.text), **kwargs)
        raise ValueError(f"no <metadata id=\"{METADATA_ID}\"> found in {path} "
                         "(was it exported by the instrumented generator?)")

    def world_to_screen(self, p: PointLike) -> PointLike:
        ox, oy = self.meta["origin"]
        z = self.meta["zoom"]
        return ((p[0] - ox) * z, (p[1] - oy) * z)

    def screen_to_world(self, p: PointLike) -> PointLike:
        ox, oy = self.meta["origin"]
        z = self.meta["zoom"]
        return (p[0] / z + ox, p[1] / z + oy)

    def nearest_edge(self, point: PointLike) -> tuple[str, float, float]:
        """Nearest edge to a world-space point. Returns (edge id, t along edge, distance)."""
        if self._edge_tree is None:
            raise RoutingError("map has no edges")
        pt = Point(point)
        idx = self._edge_tree.nearest(pt)
        line = self._edge_lines[idx]
        t = line.project(pt) / line.length if line.length > 0 else 0.0
        return self._edge_ids[idx], t, pt.distance(line)

    def polygon_at(self, point: PointLike) -> str | None:
        """Id of the block/lot/park polygon containing the point, if any."""
        pt = Point(point)
        for pid, poly in self._snap_polygons.items():
            if poly.contains(pt):
                return pid
        return None

    def edge_geometry(self, edge_id: str) -> LineString:
        e = self.edges[edge_id]
        return LineString([self.nodes[e.a], self.nodes[e.b]])

    def _site(self, spec: Spec) -> tuple[str, Any]:
        """Resolve a route endpoint spec to ('node', node_id) or ('edge', (edge_id, t))."""
        if isinstance(spec, (tuple, list)):
            if len(spec) != 2:
                raise RoutingError(f"point spec must be (x, y), got {spec!r}")
            eid, t, _dist = self.nearest_edge((float(spec[0]), float(spec[1])))
            return ("edge", (eid, t))
        if not isinstance(spec, str) or len(spec) < 2:
            raise RoutingError(f"unrecognised spec: {spec!r}")
        prefix = spec[0]
        if prefix == "n":
            if spec not in self.nodes:
                raise RoutingError(f"unknown node id: {spec}")
            return ("node", spec)
        if prefix == "e":
            if spec not in self.edges:
                raise RoutingError(f"unknown edge id: {spec}")
            return ("edge", (spec, 0.5))
        if prefix in ("b", "l", "p"):
            poly = self._snap_polygons.get(spec)
            if poly is None:
                raise RoutingError(f"unknown polygon id: {spec}")
            c = poly.centroid
            eid, t, _dist = self.nearest_edge((c.x, c.y))
            return ("edge", (eid, t))
        raise RoutingError(f"unrecognised spec: {spec!r}")

    def _attach_virtual(self, G: nx.Graph, name: str, site: tuple[str, Any]) -> str:
        """Attach a virtual endpoint for an edge site; returns the node to route from."""
        kind, payload = site
        if kind == "node":
            return payload
        eid, t = payload
        e = self.edges[eid]
        pa, pb = self.nodes[e.a], self.nodes[e.b]
        pos = (pa[0] + t * (pb[0] - pa[0]), pa[1] + t * (pb[1] - pa[1]))
        w = e.length * self.class_factors[e.cls]
        G.add_node(name, pos=pos)
        G.add_edge(name, e.a, id=None, length=t * e.length, weight=t * w)
        G.add_edge(name, e.b, id=None, length=(1 - t) * e.length, weight=(1 - t) * w)
        return name

    def route(self, src: Spec, dst: Spec, include_coords: bool = False) -> RouteResult:
        """Shortest route between two specs. Returned ids match the SVG overlay."""
        s_site, d_site = self._site(src), self._site(dst)
        simple = s_site[0] == d_site[0] == "node"
        G = self.graph if simple else self.graph.copy()
        s = self._attach_virtual(G, "__src__", s_site)
        d = self._attach_virtual(G, "__dst__", d_site)

        # Two virtual endpoints on the same edge must be joined by the direct
        # partial-edge segment; otherwise the only paths run through the edge's
        # real endpoints and the route detours around the true separation.
        if (not simple and s_site[0] == "edge" and d_site[0] == "edge"
                and s_site[1][0] == d_site[1][0]):
            eid = s_site[1][0]
            ts, td = s_site[1][1], d_site[1][1]
            e = self.edges[eid]
            seg = abs(ts - td) * e.length
            w = abs(ts - td) * e.length * self.class_factors[e.cls]
            G.add_edge(s, d, id=None, length=seg, weight=w)

        min_f = self._min_factor

        def heuristic(u: str, v: str) -> float:
            pu, pv = G.nodes[u]["pos"], G.nodes[v]["pos"]
            return math.hypot(pu[0] - pv[0], pu[1] - pv[1]) * min_f

        try:
            path = nx.astar_path(G, s, d, heuristic=heuristic, weight="weight")
        except nx.NetworkXNoPath as exc:
            raise RoutingError(f"no path between {src!r} and {dst!r}") from exc

        edge_ids: list[str] = []
        length = 0.0
        cost = 0.0
        for u, v in itertools.pairwise(path):
            data = G[u][v]
            length += data["length"]
            cost += data["weight"]
            if data["id"] is not None:
                edge_ids.append(data["id"])
        real_nodes = [n for n in path if not n.startswith("__")]
        coords = [tuple(G.nodes[n]["pos"]) for n in path] if include_coords else None
        return RouteResult(src=str(src), dst=str(dst), edges=edge_ids, nodes=real_nodes,
                           length=length, cost=cost, coords=coords)

    def component_report(self) -> dict[str, Any]:
        comps = sorted((len(c) for c in nx.connected_components(self.graph)), reverse=True)
        return {
            "components": len(comps),
            "largest_component_nodes": comps[0] if comps else 0,
            "largest_component_fraction": (comps[0] / len(self.nodes)) if self.nodes else 0.0,
        }

    def stats(self) -> dict[str, Any]:
        by_cls: dict[str, int] = {}
        for e in self.edges.values():
            by_cls[e.cls] = by_cls.get(e.cls, 0) + 1
        return {
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "edges_by_class": by_cls,
            "roads": {cls: len(v) for cls, v in self.data["roads"].items()},
            "blocks": len(self.blocks),
            "lots": len(self.lots),
            "parks": len(self.parks),
            **self.component_report(),
        }
