"""Curated map artifacts plus building-to-point lookup, routing, and snapping.

Wraps the routing MapEngine with the enrichment manifest (occupants, public
points) so the domain core has one place to resolve buildings, snap
destinations, and compute routes. Packaged maps load through importlib.resources
so the wheel carries no repository dependency.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources

from ..domain.model import Point, Route
from .routing import MapEngine, RoutingError

# Import snap tolerance (ASSUMPTIONS.md): public points/destinations snap within
# this many world units of a routable edge.
DEFAULT_SNAP_BOUND = 40.0


@dataclass(frozen=True)
class Building:
    building_id: str
    name: str
    address: str
    aliases: tuple[str, ...]
    occupants: int
    point: Point


class Map:
    def __init__(self, map_id: str, map_data: dict, manifest: dict,
                 snap_bound: float = DEFAULT_SNAP_BOUND):
        self.map_id = map_id
        self.engine = MapEngine(map_data)
        self.snap_bound = snap_bound
        self.buildings: dict[str, Building] = {}
        for b in manifest["buildings"]:
            self.buildings[b["building_id"]] = Building(
                building_id=b["building_id"],
                name=b.get("name", ""),
                address=b.get("address", ""),
                aliases=tuple(b.get("aliases", ())),
                occupants=int(b["occupants"]),
                point=Point(b["point"]["x"], b["point"]["y"]),
            )
        # World bounds from the display transform (screen = (world-origin)*zoom).
        ox, oy = self.engine.meta["origin"]
        sw, sh = self.engine.meta["screen"]
        z = self.engine.meta["zoom"]
        self.world_min = Point(ox, oy)
        self.world_max = Point(ox + sw / z, oy + sh / z)

    @classmethod
    def load(cls, map_id: str, snap_bound: float = DEFAULT_SNAP_BOUND) -> Map:
        base = resources.files("hadr_engine.data.maps").joinpath(map_id)
        map_data = json.loads(base.joinpath("map.json").read_text())
        manifest = json.loads(base.joinpath("manifest.json").read_text())
        return cls(map_id, map_data, manifest, snap_bound=snap_bound)

    def building_to_coords(self, building_id: str) -> Point:
        return self.buildings[building_id].point

    def has_building(self, building_id: str) -> bool:
        return building_id in self.buildings

    @property
    def center(self) -> Point:
        return Point((self.world_min.x + self.world_max.x) / 2,
                     (self.world_min.y + self.world_max.y) / 2)

    def in_world_bounds(self, p: Point) -> bool:
        return (self.world_min.x <= p.x <= self.world_max.x
                and self.world_min.y <= p.y <= self.world_max.y)

    def snap(self, p: Point) -> Point:
        """Snap a world point to its nearest routable edge, respecting the bound."""
        eid, t, dist = self.engine.nearest_edge(p.as_tuple())
        if dist > self.snap_bound:
            raise RoutingError(
                f"point {p.as_tuple()} is {dist:.2f} units from the nearest edge "
                f"(bound {self.snap_bound})")
        e = self.engine.edges[eid]
        a, b = self.engine.nodes[e.a], self.engine.nodes[e.b]
        return Point(a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))

    def snap_distance(self, p: Point) -> float:
        return self.engine.nearest_edge(p.as_tuple())[2]

    def route(self, src: Point, dst: Point) -> Route:
        """Route from an exact current point to a destination point, snapping the
        destination to the nearest routable edge. Raises RoutingError if either
        endpoint is beyond the snap bound or no path exists."""
        if self.snap_distance(dst) > self.snap_bound:
            raise RoutingError(f"destination {dst.as_tuple()} beyond snap bound")
        result = self.engine.route(src.as_tuple(), dst.as_tuple(), include_coords=True)
        assert result.coords is not None  # include_coords=True guarantees a polyline
        polyline = tuple(Point(x, y) for (x, y) in result.coords)
        return Route(polyline=polyline, cursor=0.0, total=result.length,
                     edges=tuple(result.edges))
