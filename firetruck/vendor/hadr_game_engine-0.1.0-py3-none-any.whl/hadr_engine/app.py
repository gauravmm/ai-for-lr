"""FastAPI assembly and lifespan (ENGINE.md, API.md, DISTRIBUTION.md).

Startup constructs the single authoritative GameService (whose __init__ runs
restart-finalization of any interrupted run log) after validating packaged data,
mounts the stateful MCP app at /mcp, and serves the ordinary HTTP surface: the
static display shell, static assets, curated display SVGs, /healthz, and the
read-only display snapshot. The snapshot route reads the stored poll response and
never takes the mutation lock. Binds to loopback only.
"""
from __future__ import annotations

import contextlib
from importlib import resources

from fastapi import FastAPI, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.routing import Mount

from . import __version__
from .domain import tick
from .maps import import_map
from .schemas import API_VERSION
from .service import GameService
from .transports import mcp

_SVG_CACHE = "public, max-age=31536000, immutable"


class DataInvalidError(RuntimeError):
    """Packaged data failed validation at startup; do not accept connections."""


def _static_dir() -> str:
    return str(resources.files("hadr_engine") / "static")


def _validate_packaged_data() -> None:
    report = import_map.validate_packaged_data()
    problems = {mid: probs for mid, probs in report.items() if probs}
    if not report:
        raise DataInvalidError("no packaged maps found")
    if problems:
        lines = [f"{mid}: {'; '.join(probs)}" for mid, probs in sorted(problems.items())]
        raise DataInvalidError("packaged map validation failed: " + " | ".join(lines))


def create_app(*, idle_timeout: float | None = mcp.DEFAULT_IDLE_TIMEOUT,
               validate: bool = True) -> FastAPI:
    if validate:
        _validate_packaged_data()

    service = GameService()
    manager = mcp.build_manager(service, idle_timeout=idle_timeout)

    @contextlib.asynccontextmanager
    async def lifespan(_app: FastAPI):
        async with manager.run():
            yield

    app = FastAPI(title="HADR engine", version=__version__, lifespan=lifespan)
    app.state.service = service

    static_dir = _static_dir()
    index_html = (resources.files("hadr_engine.static") / "index.html").read_text(encoding="utf-8")

    # API: display_shell - documented at webpage/src/game/01-api/
    @app.get("/", response_class=HTMLResponse)
    async def index() -> HTMLResponse:
        return HTMLResponse(index_html)

    # API: healthz - documented at webpage/src/game/01-api/
    @app.get("/healthz")
    async def healthz() -> JSONResponse:
        # Liveness and engine revision only; no episode details.
        return JSONResponse({
            "status": "ok",
            "version": __version__,
            "engine_revision": tick.ENGINE_REVISION,
            "api_version": API_VERSION,
        })

    # API: snapshot - documented at webpage/src/game/01-api/
    @app.get("/api/v1/snapshot")
    async def snapshot() -> JSONResponse:
        # Read-only display projection; never acquires the mutation lock.
        return JSONResponse(service.snapshot())

    # API: display_svg - documented at webpage/src/game/01-api/
    @app.get("/api/v1/maps/{map_id}/display.svg")
    async def display_svg(map_id: str) -> Response:
        if map_id not in import_map.packaged_map_ids():
            return Response("unknown map", status_code=404, media_type="text/plain")
        _map_json, svg_text, _manifest = import_map.load_packaged_map(map_id)
        return Response(svg_text, media_type="image/svg+xml",
                        headers={"Cache-Control": _SVG_CACHE})

    # Public building directory (id -> public point + display name) for the
    # display. Building points are absent from the redacted snapshot and the
    # sanitized SVG carries no building IDs, so the browser needs this to place
    # report markers and truth glyphs. Public geometry only, like display.svg:
    # occupants and any hidden fields are never included.
    @app.get("/api/v1/maps/{map_id}/buildings.json")
    async def buildings_json(map_id: str) -> JSONResponse:
        if map_id not in import_map.packaged_map_ids():
            return JSONResponse({"error": "unknown map"}, status_code=404)
        _map_json, _svg_text, manifest = import_map.load_packaged_map(map_id)
        pub = [{"building_id": b["building_id"], "name": b.get("name", ""),
                "point": {"x": b["point"]["x"], "y": b["point"]["y"]}}
               for b in manifest.get("buildings", [])]
        return JSONResponse({"map_id": map_id, "buildings": pub},
                            headers={"Cache-Control": _SVG_CACHE})

    app.mount("/assets", StaticFiles(directory=static_dir), name="assets")

    # Stateful MCP Streamable HTTP transport. Mount strips the /mcp prefix; the
    # transport dispatches purely on HTTP method, so the prefix is irrelevant.
    # API: mcp - documented at webpage/src/game/01-api/
    app.router.routes.append(Mount("/mcp", app=manager.handle_request))

    return app
