"""HTTP and MCP transports."""
