"""MCP control surface over the official SDK's stateful Streamable HTTP transport.

One low-level `Server` is shared across sessions; the SDK enters its `lifespan`
once per MCP session (once per `Server.run`), which is the one-controller hook:
lifespan-enter acquires the ControllerLease (newest wins, displacing and
archiving any prior holder), lifespan-exit archives an active run as aborted and
releases the lease. Every HTTP request inside one MCP session shares that single
session lifespan, so it is one controller regardless of request count. Abrupt
transport loss that leaves no clean session-DELETE is caught by the SDK's
`session_idle_timeout`, whose only role is to end the session so the same
lifespan-exit aborts the run; there is no resume.

Tool input/output schemas are generated from the public Pydantic models in
schemas.py. Tool results carry the JSON result as structuredContent plus a
concise text rendering built solely from that same result. EngineError maps to a
tool error carrying the stable machine code + message; unexpected exceptions
surface as INTERNAL_ERROR with no traceback or path leakage.
"""
from __future__ import annotations

import contextlib
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from mcp import types
from mcp.server.lowlevel import Server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from pydantic import BaseModel, ValidationError

from .. import schemas
from ..errors import EngineError, ErrorCode
from ..service import GameService

log = logging.getLogger("hadr_engine.mcp")

# Shortest practical inactivity backstop for abrupt transport loss: any tool call
# pushes the deadline forward, so lockstep play never trips it; it exists only to
# end an abandoned session so its run aborts. Never a resume mechanism.
DEFAULT_IDLE_TIMEOUT = 300.0


# --------------------------------------------------------------- operation set

@dataclass(frozen=True)
class _Op:
    name: str
    request_model: type[BaseModel]
    result_model: type[BaseModel]
    description: str
    # request_model.model_validate produces each handler's own request subtype at dispatch time,
    # so the shared signature accepts Any request rather than a single BaseModel supertype.
    call: Callable[[GameService, str, Any], Awaitable[BaseModel]]


_END_TICK_NOTE = (
    " ONLY the participant's outer runner calls this tool. Intake, reconciliation, "
    "and any inner model/tool loop MUST NOT call next_tick; the server cannot "
    "distinguish callers, so this ownership is enforced by the participant "
    "architecture and tests."
    " The optional `tokens` field is for an automated runner reporting its own "
    "provider-reported usage to the wall display; it does not affect the tick. "
    "If you are playing by hand you do not have those numbers: OMIT `tokens` "
    "entirely rather than estimating or inventing a value."
)

# API: list_scenarios - documented at webpage/src/game/01-api/
# API: start_episode - documented at webpage/src/game/01-api/
# API: status - documented at webpage/src/game/01-api/
# API: building_to_coords - documented at webpage/src/game/01-api/
# API: travel_time - documented at webpage/src/game/01-api/
# API: dispatch - documented at webpage/src/game/01-api/
# API: next_tick - documented at webpage/src/game/01-api/
OPERATIONS: dict[str, _Op] = {
    op.name: op
    for op in [
        _Op("list_scenarios", schemas.ListScenariosRequest, schemas.ListScenariosResult,
            "List the available scenarios as public catalogue entries (scenario ID, "
            "title, difficulty stage, map ID, tick limit, default seed, description). "
            "Available after connection; reveals no truth, occupants, or tuning.",
            lambda svc, cid, req: svc.list_scenarios(cid)),
        _Op("start_episode", schemas.StartEpisodeRequest, schemas.StartEpisodeResult,
            "Start a new episode of a scenario (optional seed; omit for the scenario "
            "default). Any live run is first archived as aborted:replaced. Returns a "
            "new run_id and the frozen tick-0 observation. Safe to retry: a lost "
            "response is recovered by calling status or start_episode again.",
            lambda svc, cid, req: svc.start_episode(cid, req)),
        _Op("status", schemas.StatusRequest, schemas.StatusResult,
            "Report lifecycle, run/scenario/map IDs when public, current tick and tick "
            "limit, pending command summaries, and the current frozen observation when "
            "running or terminal. Repeated reads within a tick are identical. While "
            "running it omits score, hidden state, canonical claims, and the schedule.",
            lambda svc, cid, req: svc.status(cid)),
        _Op("building_to_coords", schemas.BuildingToCoordsRequest, schemas.BuildingToCoordsResult,
            "Convert one public building ID (l<integer>, learned only from contacts) to "
            "its exact public point. Unknown IDs return UNKNOWN_BUILDING. One-way: no "
            "operation resolves coordinates back to a building. Running or terminal.",
            lambda svc, cid, req: svc.building_to_coords(cid, req)),
        _Op("travel_time", schemas.TravelTimeRequest, schemas.TravelTimeResult,
            "Compute distance, eta_ticks, ordered edge IDs, and route polyline between "
            "two endpoints, each exactly one of {vehicle_id} or {point}. A point snaps "
            "to the nearest routable edge; building points come from building_to_coords "
            "first. Read-only: it reserves no route and queues no command.",
            lambda svc, cid, req: svc.travel_time(cid, req)),
        _Op("dispatch", schemas.DispatchRequest, schemas.DispatchResult,
            "Queue a dispatch of one vehicle to a world-coordinate destination "
            "(convert building reports via building_to_coords first), carrying an "
            "opaque incident_id and a rationale that are logged and echoed but never "
            "checked against engine state. Requires expected_tick. Takes effect at "
            "next_tick; a later command for the same vehicle this tick supersedes it. "
            "Running only.",
            lambda svc, cid, req: svc.dispatch(cid, req)),
        _Op("next_tick", schemas.EndTickRequest, schemas.EndTickResult,
            "Apply pending commands and advance the simulation exactly one tick, "
            "returning committed commands, ordered public events, and the new frozen "
            "observation. A stale expected_tick returns TICK_MISMATCH with the current "
            "tick and never advances. Running only." + _END_TICK_NOTE,
            lambda svc, cid, req: svc.end_tick(cid, req)),
    ]
}


# --------------------------------------------------------------- shared invoke

def _error(code: ErrorCode, message: str, details: dict | None = None) -> dict:
    return {"ok": False,
            "error": {"code": code.value, "message": message, "details": details or {}}}


def _safe_validation_message(exc: ValidationError) -> str:
    parts = []
    for err in exc.errors():
        loc = ".".join(str(p) for p in err.get("loc", ())) or "(root)"
        parts.append(f"{loc}: {err.get('msg', 'invalid')}")
    return "; ".join(parts[:8]) or "invalid request"


async def invoke(service: GameService, controller_id: str, op_name: str,
                 arguments: dict | None) -> dict:
    """Shared operation dispatch used by both the MCP tool handler and the
    in-process contract-test adapter. Returns an envelope:
    `{"ok": True, "result": <public dict>}` or
    `{"ok": False, "error": {"code", "message", "details"}}`.
    """
    op = OPERATIONS.get(op_name)
    if op is None:
        return _error(ErrorCode.INVALID_REQUEST, f"unknown operation {op_name!r}")
    try:
        req = op.request_model.model_validate(arguments or {})
    except ValidationError as exc:
        return _error(ErrorCode.INVALID_REQUEST, _safe_validation_message(exc))
    try:
        result = await op.call(service, controller_id, req)
    except EngineError as exc:
        return _error(exc.code, exc.message, exc.details)
    except Exception:  # unexpected: never leak traceback/path through the result
        log.exception("internal error in operation %s", op_name)
        return _error(ErrorCode.INTERNAL_ERROR, "internal server error")
    return {"ok": True, "result": result.model_dump(mode="json")}


# ----------------------------------------------------------- text rendering

def render_text(op_name: str, result: dict) -> str:
    """A concise, harness-friendly text rendering built solely from the public
    result, never adding hidden data."""
    life = result.get("lifecycle")
    tick = result.get("tick")
    head = f"{op_name}: lifecycle={life} tick={tick}"
    if op_name == "list_scenarios":
        ids = ", ".join(s["scenario_id"] for s in result.get("scenarios", []))
        return f"{head} scenarios=[{ids}]"
    if op_name == "building_to_coords":
        p = result.get("point", {})
        return f"{head} building={result.get('building_id')} point=({p.get('x')},{p.get('y')})"
    if op_name == "travel_time":
        return f"{head} distance={result.get('distance')} eta_ticks={result.get('eta_ticks')}"
    if op_name == "dispatch":
        cmd = result.get("command", {})
        return (f"{head} accepted={result.get('accepted')} command_id={cmd.get('command_id')} "
                f"vehicle={cmd.get('vehicle_id')} superseded={result.get('superseded')}")
    if op_name in ("start_episode", "status", "next_tick"):
        obs = result.get("observation")
        reason = result.get("terminal_reason")
        extra = f" terminal_reason={reason}" if reason else ""
        if obs:
            extra += (
                f" contacts={len(obs.get('contacts', []))}"
                f" vehicles={len(obs.get('vehicles', []))}"
            )
        return head + extra
    return head


# --------------------------------------------------------------- MCP server

def build_server(service: GameService) -> Server:
    @contextlib.asynccontextmanager
    async def _session_lifespan(_server: Server):
        # One MCP session = one controller. Acquire on session start (newest wins,
        # displacing and archiving any prior holder); release on session end,
        # which archives an active run as aborted:disconnected.
        controller_id = await service.acquire_controller()
        try:
            yield {"controller_id": controller_id}
        finally:
            await service.release_controller(controller_id)

    server: Server = Server("hadr-engine", lifespan=_session_lifespan)

    @server.list_tools()
    async def _list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name=op.name,
                description=op.description,
                inputSchema=op.request_model.model_json_schema(by_alias=True),
                outputSchema=op.result_model.model_json_schema(),
            )
            for op in OPERATIONS.values()
        ]

    # validate_input=False: request parsing/validation happens in `invoke` against
    # the shared Pydantic models so the MCP and in-process error shapes are identical.
    @server.call_tool(validate_input=False)
    async def _call_tool(name: str, arguments: dict):
        controller_id = server.request_context.lifespan_context["controller_id"]
        envelope = await invoke(service, controller_id, name, arguments)
        if envelope["ok"]:
            result = envelope["result"]
            return [types.TextContent(type="text", text=render_text(name, result))], result
        error = envelope["error"]
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=f"{error['code']}: {error['message']}")],
            structuredContent={"error": error},
            isError=True,
        )

    return server


def build_manager(
    service: GameService, idle_timeout: float | None = DEFAULT_IDLE_TIMEOUT
) -> StreamableHTTPSessionManager:
    """Build the stateful Streamable HTTP session manager for `/mcp`.

    The returned manager's `.handle_request` is the ASGI callable; its `.run()`
    async context manager must wrap serving (call it in the app lifespan).
    """
    return StreamableHTTPSessionManager(
        app=build_server(service),
        event_store=None,       # no resumability: V1 has no resume
        json_response=False,
        stateless=False,        # stateful: one MCP session identity spans requests
        session_idle_timeout=idle_timeout,
    )
