"""Read-only display snapshot projection (FRONTEND.md, API.md).

Built after every committed mutation and stored as the current poll response.
Polling never takes the mutation lock and never reaches GameService mutation
methods. The immutable scenario `display_policy` selects the schema:

- `public_only` carries public facts only: lifecycle, tick, vehicles with routes
  and pending commands, delivered contacts. It redacts the hidden truth block.
- `full_state` additionally carries current building/fire/occupant/casualty truth,
  tagged with `includes_truth: true`.

Reveal (the truth block) is otherwise present only at terminal. Live `metrics`
and participant-reported `tokens` ride on every policy: they are scoreboard for
the room, not something the agent can read.
"""
from __future__ import annotations

import math

from ..domain.fire_eta import fire_eta_table
from ..domain.model import Contact, EpisodeState, Lifecycle
from ..schemas import ContactPublic, PendingCommandSummary, RouteSummary, VehiclePublic


def _contact_dict(c: Contact) -> dict:
    return ContactPublic.of(c).model_dump()


def _public_vehicles(state: EpisodeState, speed: float) -> list[dict]:
    return [VehiclePublic.of(v, speed).model_dump() for v in state.vehicles]


def _pending_dict(c, speed: float) -> dict:
    # Display-route enrichment: carry the accepted-but-not-committed command's full
    # route polyline so the display can draw its path dashed before next_tick. Public
    # routing geometry only, like VehiclePublic.route; the participant-facing
    # PendingCommandSummary stays unchanged.
    d = PendingCommandSummary.of(c, speed).model_dump()
    d["route"] = RouteSummary.of(c.route, speed).model_dump()
    return d


def _truth_block(state: EpisodeState) -> dict:
    return {
        "buildings": [
            {"building_id": b.building_id, "status": b.status.value,
             "occupants": b.occupants, "casualties": b.casualties,
             "ever_burned": b.ever_burned}
            for b in state.buildings
        ],
        "fires": [
            {"fire_id": f.fire_id, "building_id": f.building_id,
             "intensity": f.intensity, "growth_rate": f.growth_rate,
             "ignited_tick": f.ignited_tick}
            for f in state.fires
        ],
        "metrics": {"casualties": state.casualties, "buildings_lost": state.buildings_lost},
    }


def _fire_eta_block(state: EpisodeState, scenario, map_) -> list[dict]:
    """Per-fire tick countdowns for fires currently within a truck's vision.

    Player-facing on any policy: a fire is included iff its building sits within
    truck_vision_radius of some vehicle. Shares fire_eta_table with the truck
    observation; the only display-specific step is the vision filter.
    """
    vision = scenario.settings.truck_vision_radius
    table = fire_eta_table(state.fires, state.vehicles, scenario.settings, map_)

    def in_vision(building_id: str) -> bool:
        pt = map_.building_to_coords(building_id)
        return any(math.hypot(v.position.x - pt.x, v.position.y - pt.y) <= vision
                   for v in state.vehicles)

    out = []
    for f in state.fires:
        if not in_vision(f.building_id):
            continue
        eta = table[f.building_id]
        out.append({
            "building_id": f.building_id,
            "suppressors": eta.suppressors,
            "ticks_to_extinguish": eta.ticks_to_extinguish,
            "ticks_to_collapse": eta.ticks_to_collapse,
        })
    return out


def build_snapshot(state: EpisodeState, scenario, map_, display_revision: int,
                   contact_history: list[Contact]) -> dict:
    """Assemble the redacted display snapshot for the current stable tick.

    `new_contacts` are the current stable tick's contacts (stable within a tick);
    `contact_history` is the accumulated delivered contacts across the run.
    """
    speed = scenario.settings.truck_speed
    new_contacts = list(state.observation.contacts)
    terminal = state.lifecycle == Lifecycle.TERMINAL
    snapshot = {
        "display_revision": display_revision,
        "lifecycle": state.lifecycle.value,
        "display_policy": scenario.display_policy,
        "scenario_id": scenario.scenario_id,
        # Live score, on every policy. The display is a spectator surface the
        # participant's agent never reads, so showing it here does not leak
        # anything into play; `public_only` still redacts the world_state truth
        # block that says WHICH building is burning.
        "metrics": {"casualties": state.casualties,
                    "buildings_lost": state.buildings_lost},
        "map": {
            "map_id": map_.map_id,
            "world_min": {"x": map_.world_min.x, "y": map_.world_min.y},
            "world_max": {"x": map_.world_max.x, "y": map_.world_max.y},
        },
        "tick": state.current_tick,
        "tick_limit": state.tick_limit,
        "terminal_reason": state.terminal_reason.value if state.terminal_reason else None,
        "new_contacts": [_contact_dict(c) for c in new_contacts],
        "contact_history": [_contact_dict(c) for c in contact_history],
        "vehicles": _public_vehicles(state, speed),
        "pending": [_pending_dict(c, speed) for c in state.pending],
        "fire_eta": _fire_eta_block(state, scenario, map_),
        "vision_radius": scenario.settings.truck_vision_radius,
        "includes_truth": scenario.display_policy == "full_state",
    }
    if scenario.display_policy == "full_state":
        snapshot["world_state"] = _truth_block(state)
    if terminal:
        # Terminal reveal is permitted on any policy once the episode ends.
        snapshot["reveal"] = _truth_block(state)
    return snapshot


def lobby_snapshot(display_revision: int) -> dict:
    """The static lobby screen: no episode running."""
    return {
        "display_revision": display_revision,
        "lifecycle": Lifecycle.LOBBY.value,
        "display_policy": None,
        "scenario_id": None,
        "metrics": {"casualties": 0, "buildings_lost": 0},
        # `tokens` is stamped by GameService, which owns the scoreboard.
        "tick": None,
        "tick_limit": None,
        "new_contacts": [],
        "contact_history": [],
        "vehicles": [],
        "pending": [],
        "includes_truth": False,
    }
