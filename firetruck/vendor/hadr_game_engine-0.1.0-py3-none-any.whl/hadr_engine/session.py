"""One process-wide controller lease: newest connection wins (API.md).

The lease is a bare token holder. A successful acquire displaces the previous
holder and returns their id so GameService can archive their active run as
`aborted: displaced`. A displaced session's calls fail the current-holder check
and GameService raises CONTROLLER_DISPLACED. There is no busy rejection and no
resume; releasing frees the lease. Side effects (archiving) live in GameService,
under its mutation lock; this object only tracks identity.
"""
from __future__ import annotations

import secrets


class ControllerLease:
    def __init__(self) -> None:
        self._holder: str | None = None

    def new_controller_id(self) -> str:
        return "ctrl-" + secrets.token_hex(8)

    def acquire(self, controller_id: str) -> str | None:
        """Take the lease for `controller_id`, returning the displaced holder (or None)."""
        previous = self._holder
        self._holder = controller_id
        return previous if previous != controller_id else None

    def is_current(self, controller_id: str) -> bool:
        return self._holder is not None and controller_id == self._holder

    def release(self, controller_id: str) -> bool:
        """Free the lease if `controller_id` still holds it. Returns whether it did."""
        if self._holder == controller_id:
            self._holder = None
            return True
        return False
